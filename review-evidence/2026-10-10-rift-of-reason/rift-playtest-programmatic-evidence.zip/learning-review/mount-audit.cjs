const fs=require('node:fs'), vm=require('node:vm'), path=require('node:path');
function load(p) { vm.runInThisContext(fs.readFileSync(path.join(__dirname,p),'utf8'),{filename:p}); }
class Classes {
 constructor(n){this.n=n;this.s=new Set();}
 add(...cs){cs.forEach(c=>this.s.add(c));}
 remove(...cs){cs.forEach(c=>this.s.delete(c));}
 contains(c){return this.s.has(c);}
 toggle(c,want){want=want===undefined?!this.s.has(c):want; want?this.s.add(c):this.s.delete(c);return want;}
}
class Node {
 constructor(tag='div'){this.tagName=tag.toUpperCase();this.classList=new Classes(this);this.children=[];this.parentNode=null;this.events={};this.disabled=false;this.style={setProperty(){}};this.dataset={};this.attrs={};this._text='';this.offsetWidth=0;}
 appendChild(n){this.children.push(n);n.parentNode=this;return n;}
 append(...ns){ns.forEach(n=>this.appendChild(n));}
 get firstChild(){return this.children[0];}
 set textContent(s){this._text=String(s);this.children=[];}
 get textContent(){return this._text+this.children.map(n=>n.textContent||'').join('');}
 set innerHTML(s){this.children=[];this._html=String(s);}
 get innerHTML(){return this._html||'';}
 addEventListener(e,f){(this.events[e]??=[]).push(f);}
 removeEventListener(e,f){this.events[e]=(this.events[e]||[]).filter(x=>x!==f);}
 setAttribute(k,v){this.attrs[k]=v;}
 remove(){if(this.parentNode){const p=this.parentNode;p.children=p.children.filter(n=>n!==this);this.parentNode=null;}}
 replaceWith(n){const p=this.parentNode;const i=p.children.indexOf(this);p.children[i]=n;n.parentNode=p;this.parentNode=null;}
 matches(sel){const tag=/^[a-z]+/i.exec(sel);if(tag&&this.tagName!==tag[0].toUpperCase())return false;return [...sel.matchAll(/\.([\w-]+)/g)].every(m=>this.classList.contains(m[1]));}
 querySelectorAll(sel){let out=[];for(const n of this.children){if(n.matches(sel))out.push(n);out.push(...n.querySelectorAll(sel));}return out;}
 querySelector(sel){return this.querySelectorAll(sel)[0]||null;}
 click(){if(this.disabled)return;for(const f of this.events.click||[])f({target:this,detail:0});}
}
global.document={createElement:t=>new Node(t),createTextNode:s=>{const n=new Node('text');n.textContent=s;return n;}};
load('js/core/rift.js');
Rift.Puzzles={defs:{},register(p){this.defs[p.id]=p;}};
load('data/creatures.js');load('js/puzzles/rule-hunter.js');load('js/puzzles/river-crossing.js');
const p=Rift.Puzzles.defs['rule-hunter'];
async function testPattern(){
 const data=p.generate(Rift.makeRng('critic-mount-pattern'),3,{mode:'pattern',sequence:'moser'});
 const c=new Node('div'), submissions=[];
 p.mount(c,data,{el:Rift.el,submit:a=>{const r=p.check(data,a);submissions.push({a,r});return r;},sfx(){}});
 c.querySelectorAll('.rh-plank')[data.correct].click();
 const lessons=c.querySelectorAll('.rh-plank.wide');
 const wrong=(data.lesson.correct+1)%lessons.length;
 lessons[wrong].click();await Promise.resolve();await Promise.resolve();
 const before=submissions.length;lessons[data.lesson.correct].click();await Promise.resolve();
 console.log(JSON.stringify({test:'Pattern Breaker wrong reflection',data:{seq:data.seq,correctLesson:data.lesson.correct,wrongLesson:wrong},submissions,allLessonControlsDisabled:lessons.every(b=>b.disabled),attemptedCorrectRetryAddedSubmission:submissions.length>before,resultText:c.querySelector('.rh-result').textContent}));
}
async function testRules(){
 const data=p.generate(Rift.makeRng('critic-mount-rules'),1,{mode:'rules'});
 const c=new Node('div'),submissions=[];
 p.mount(c,data,{el:Rift.el,submit:a=>{const r=p.check(data,a);submissions.push({a,r});return r;},sfx(){}});
 c.querySelector('.rh-name-btn').click();
 c.querySelectorAll('.rh-cand')[(data.correct+1)%data.candidates.length].click();
 const confirm=c.querySelectorAll('button').find(b=>b.textContent==='This is the rule');confirm.click();
 await Promise.resolve();await Promise.resolve();
 const before=submissions.length;c.querySelector('.rh-name-btn').click();
 console.log(JSON.stringify({test:'Rule Hunter wrong rule',submissions,mainControls:{nameDisabled:c.querySelector('.rh-name-btn').disabled,clearDisabled:c.querySelector('.rh-build-btns').querySelectorAll('button')[1].disabled,testDisabled:c.querySelector('.rh-test').disabled},retryAddedSubmission:submissions.length>before,resultText:c.querySelector('.rh-result').textContent}));
}
function testRiverMessage(){
 const p=Rift.Puzzles.defs['river-crossing'], data=p.generate(Rift.makeRng('critic-river-message'),1);
 const c=new Node('div'), submissions=[];
 p.mount(c,data,{el:Rift.el,submit:a=>{const r=p.check(data,a);submissions.push({a,r});return r;},sfx(){}});
 c.querySelector('.rc-row').click();
 console.log(JSON.stringify({test:'River unsafe crossing recovery message',submissions,visibleInfoAfterError:c.querySelector('.rc-info').textContent,recoveryMessageVisible:c.querySelector('.rc-info').textContent.includes('Trip undone')}));
}
testPattern().then(testRules).then(testRiverMessage);
