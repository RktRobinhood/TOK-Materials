/*
 * Battle screen (Card Arena rules, design/card-arena-2026-10-07.md).
 *
 * Rift.Router.go('battle', {
 *   mode: 'practice' | 'trainer' | 'boss' | 'ghost',
 *   opponent: { name, shortName?, team: [instances], ai?: 'normal'|'competent'|'expert', tactics?, axioms?, art?, stake?, type?, hearts? },
 *             (ai defaults by mode: practice and trainer Normal, ghost Competent, boss Expert; 'easy'/'hard' still work)
 *   seed,
 *   player?: { name, team, tactics, axioms, items, consumables, bag?, art?, hearts? },  // default: the save's deck
 *                           bag: item ids brought into the battle (the Bag; at most two, one per turn)
 *                           ownAxioms?: own rule cards in the opening hand (Granny's Spare Axiom; js/ui/battles.js)
 *   axiomDeck?, battleOptions?, lesson?: 1-4 (which lesson board; default: the save's current chapter),
 *   initialState?,          // a prepared engine state (screen tests and the bench); else one is created
 *   story?: true,           // a safe story match (Syllo's practice match): its end screen says so
 *   guide?: { steps: [{ title, text, label, expect, replies, compare? }], create?() → state, coach? },
 *   onEnd(result),
 * });
 *
 * result = { mode, outcome: 'won'|'lost'|'draw', turns, rounds, endReason,
 *            fate: Fate.roll(...) | null, ante, settlement: Ante.settle(...) | null,
 *            itemsUsed: { id: n } }   // bag items used in this match (the caller removes only those)
 * endReason: 'hearts' | 'reverse-hearts' | 'cannot-act' | 'turn-limit' | 'both-zero'.
 * In guide mode "Leave lesson", and in a match with nothing at stake (practice or story) "Leave match"
 * (after a confirm step), end with outcome 'left': no win or loss is counted.
 * The screen never writes to the save itself: the caller applies the result.
 *
 * The human is always player 0 ("You"); the AI is player 1 (Rift.Battle.AI.choose).
 * Controls: drag (Pointer Events) a ready creature onto a glowing target to attack, or a
 * hand card onto your side / onto its target to play it. Click-click works everywhere:
 * click a creature or card, then a glowing target or a button in the centre lane.
 * Any card (hand, board, opponent) and any active rule chip shows a big readable preview on
 * hover, keyboard focus or long-press (touch). The draw choice is docked in the centre lane so
 * both boards stay visible, and "Your turn" fades in briefly when a turn of yours starts.
 *
 * The opponent's portrait and the log use the short name (before " · "); the full title is the tooltip.
 * The instruction bar follows the card being dragged or chosen; in guide mode it repeats the step's label.
 * Pointing at (or dragging over) a target with an attacker chosen shows the predicted fight.
 *
 * Guide mode: only steps[i].expect is allowed (highlighted with a gold pointer); after it,
 * steps[i].replies run one by one with a visible pause, then the next step starts.
 *
 * Optional art (each falls back to CSS): ui/card-<colour>, ui/card-axiom, ui/card-tactic,
 * ui/card-tactic-<colour> (colour tactics; else the CSS frame tinted), ui/icon-<colour> (their emblem),
 * tactic/<id>, ui/card-back, ui/axiom-back, ui/axiom-<id>, ui/stat-attack, ui/stat-health,
 * ui/stat-cost, ui/energy-full, ui/energy-empty, ui/kw-<keyword>, ui/state-sleeping,
 * ui/state-frozen, ui/ab-entrance, ui/ab-lastword, ui/ab-activate, ui/spark, ui/end-turn,
 * ui/hero-frame, ui/heart-full, ui/fate-track, ui/fate-marker, ui/fate-flip, ui/fate-reset,
 * scene/arena-l<lesson> (each lesson has its own board; else scene/arena, else scene/battle-table),
 * npc/rival (opponent portrait fallback). The lesson is params.lesson, else the save's current chapter.
 * The Bag: a Bag button by the energy (art ui/bag, else 🎒) opens a small tray of the items brought
 * (art item/<id>). Click an item, then a glowing target (or press Use); targeted items can also be
 * dragged onto their target. Items that can't be used now are dimmed with a short reason.
 * Picture buttons (draw choice, side, guide, Bag, Spark) show their name in a small tooltip on
 * hover, keyboard focus or long-press (art ui/btn-draw-deck, ui/btn-draw-axiom, ui/btn-fate-forward,
 * ui/btn-fate-rewind, ui/btn-rules, ui/btn-help, ui/btn-leave, ui/btn-replay; else inline SVG).
 * Hero power (design/AVATARS.md 1.6; engine powerStatus): a round button by each hero (art ui/power-<id>,
 * else a symbol from js/ui/powers.js) with its cost in an energy gem (a heart with Blood price), the
 * turns left over a dimmed button while it rests, and "Used" in the turn it was used. Mine is clicked
 * (a power with a target then waits for a glowing target, like an ability); the opponent's only shows
 * its state, and its use is shown big first. No button when a side has no power; in Granny's lesson the learner's button shows but stays unused (a Your power step).
 * Cards the engine lets me know (Night Sight) lie face up in the opponent's hand, tagged "Seen".
 */
(function (root) {
    'use strict';

    const Rift = root.Rift;
    const ME = 0;
    const OPP = 1;
    // Pacing (the teacher found the opponent's turn too fast to follow): each opponent move waits
    // AI_DELAY, an attack shows its arrow for PREVIEW first, and a card the opponent plays is shown
    // big for REVEAL before it lands. A rule change shows its card for RULE_SHOW.
    const AI_DELAY = 1250;
    const REPLY_DELAY = 1300;
    const PREVIEW = 1000;
    const REVEAL = 1500;
    const RULE_SHOW = 2600;
    const DRAG_START = 7;
    const HOVER_DELAY = 220;    // ms before the big preview opens under a resting mouse
    const SETTLE = 170;         // ms for hand cards to slide into their new places

    const el = (...a) => Rift.el(...a);
    const put = (parent, ...kids) => { kids.forEach(k => { if (k != null && k !== false) parent.appendChild(typeof k === 'string' ? root.document.createTextNode(k) : k); }); return parent; };
    const B = () => Rift.Battle;
    // Opponent AI level when the caller gives none (design/card-arena-expansion-2026-10-07.md section 8).
    const DEFAULT_AI = { practice: 'normal', trainer: 'normal', ghost: 'competent', boss: 'expert' };
    const species = id => (Rift.data.creatures || {})[id] || { name: id, colour: 'memory' };
    const sfx = name => { try { if (Rift.Audio) Rift.Audio.sfx(name); } catch (e) { /* no audio */ } };
    const has = id => !!(Rift.Assets && Rift.Assets.has && Rift.Assets.has(id));
    const artUrl = id => (has(id) && Rift.Assets.url ? Rift.Assets.url(id) : null);
    const bg = id => { const u = artUrl(id); return u ? { backgroundImage: 'url("' + u + '")' } : null; };

    const KW_ICON = { guard: '🛡️', swift: '💨', shield: '🫧', elusive: '🌫️' };
    const KW_NAME = { guard: 'Guard', swift: 'Swift', shield: 'Shield', elusive: 'Elusive' };
    const AB_KIND = { entrance: 'Entrance', lastword: 'Last Word', activate: 'Activate', passive: '' };
    // One plain line per keyword and ability timing (Rules now panel; the same words are in How to play).
    const KEYWORD_LINES = [
        ['Guard', 'Enemies must attack a Guard creature first.'],
        ['Swift', 'It can attack on the turn it arrives.'],
        ['Shield', 'The first damage it takes is ignored.'],
        ['Elusive', "Enemy tactics and abilities can't target it."],
        ['Spark', 'Once per match: +1 energy (for the player who goes second).'],
        ['Entrance', 'It works when you play the card.'],
        ['Last Word', 'It works when the creature is defeated.'],
        ['Activate', "Pay the energy (⚡) to use it. It uses the creature's attack this turn."],
    ];
    // The rule tiles ("Rules in play"): the four core rules always show (their basic value, or the
    // axiom that changed them); any other changed category adds a tile. [category, label, basic words,
    // basic card art (a "back to normal" axiom), the basic rule in one sentence].
    const CORE_RULES = [
        ['victory', 'Win', 'Enemy hero to 0 ❤ wins', 'normal-hearts', 'Take the enemy hero to zero hearts to win.'],
        ['combat', 'Fights', 'Both creatures hit', null, 'In a fight both creatures deal damage equal to their attack. Damage stays.'],
        ['plays', 'Card plays', '2 per turn', 'two-plays', 'You may play 2 cards per turn: creatures, tactics and rule cards together. Attacking is free.'],
        ['attacks', 'Attacks', 'Each creature attacks once', 'three-actions', 'Each ready creature may attack once per turn. New creatures wait a turn (unless Swift).'],
        ['energy', 'Energy', '+1 each turn', null, 'Your energy grows by 1 each turn (up to 10) and refills. Cards and abilities cost energy.'],
    ];
    const RULE_LABEL = {
        victory: 'Win', combat: 'Fights', attacks: 'Attacks', energy: 'Energy', cost: 'Card costs', draw: 'Drawing', healing: 'Healing',
        arrival: 'New creatures', targeting: 'Guard', defeat: 'Defeat', power: 'Power', colour: 'Colours', abilities: 'Abilities',
        growth: 'Growth', damage: 'Hero hits', plays: 'Card plays', hand: 'Hand limit', bonus: 'Bonus', reset: 'Reset',
    };
    // The basic rule of the other categories, in a few words (what a new rule card replaces).
    const BASIC_WORDS = {
        cost: 'cards cost what they show', draw: 'draw 1 card', healing: 'damage stays', arrival: 'new creatures wait a turn',
        targeting: 'attack Guard first', defeat: 'defeated creatures go to the discard pile', power: 'no extra attack',
        colour: 'the normal colour wheel', abilities: 'abilities work', growth: 'no growth', damage: 'a hit takes hearts equal to its attack',
        hand: 'no hand limit', bonus: 'no bonus',
    };
    const RULE_GLYPH = { victory: '🏆', combat: '⚔', attacks: '➶', energy: '⚡', plays: '🂠', hand: '✋', bonus: '🎁' };
    const TACTIC_ICON = {
        counterexample: '✗', 'pep-talk': '📣', 'stand-firm': '🛡️', eureka: '💡', 'second-wind': '❤', 'occams-razor': '🪒',
        rethink: '↺', 'big-claims': '⚖️', clockwork: '⏱', 'look-it-up': '🔎', 'peer-review': '👥', recall: '📜',
        'pause-for-thought': '⏸', 'safety-net': '🕸️', lemma: '📐',
        // colour tactics
        'proof-by-contradiction': '⊥', 'step-by-step': '👣', 'rally-cry': '📯', 'gut-reaction': '⚡', 'look-closer': '🔍',
        'field-notes': '📓', 'label-it': '🏷️', 'rousing-speech': '🎤', 'imagine-otherwise': '🔄', daydream: '☁️',
        'remember-when': '📷', nostalgia: '🕰️',
        qed: '∎', 'wave-of-feeling': '🌊', 'clear-view': '🔭', persuasion: '🤝', 'dream-big': '🌈', 'total-recall': '🧠',
    };
    const DRAW_TEXT = {
        deck: ['Draw from your deck', 'A creature or tactic card'],
        axiom: ['Take a rule card', 'A rule card for your hand'],
        forward: ['Fate sooner', 'No card. Every Fate event comes 1 turn sooner'],
        rewind: ['Fate later', 'No card. Every Fate event comes 1 turn later'],
    };
    // Picture buttons: optional art, else a small inline SVG in the game's palette.
    const TIP_DELAY = 250;      // ms before a button's name shows under a resting mouse
    const TIP_PRESS = 450;      // ms of touch long-press before it shows (it then stays until the next tap)
    const HOURGLASS = '<path d="M5 3.5h14M5 28.5h14" stroke="#f2b632" stroke-width="2.6" stroke-linecap="round"/>'
        + '<path d="M7 4.5c0 7 4 8.5 5 11.5c-1 3-5 4.5-5 11.5h10c0-7-4-8.5-5-11.5c1-3 5-4.5 5-11.5z" fill="#3a2550" stroke="#f2b632" stroke-width="1.8" stroke-linejoin="round"/>'
        + '<path d="M9.3 26c0-2.2 1.6-3.6 2.7-4.6c1.1 1 2.7 2.4 2.7 4.6z" fill="#efe3c8"/>'
        + '<path d="M20 16h5" stroke="#3fe0d0" stroke-width="3" stroke-linecap="round"/><path d="M23.5 10l7 6-7 6z" fill="#3fe0d0"/>';
    const svg = body => '<svg viewBox="0 0 32 32" focusable="false" aria-hidden="true">' + body + '</svg>';
    const CTRL_SVG = {
        deck: svg('<rect x="4" y="2.5" width="16" height="22" rx="2.5" fill="#3a2550" stroke="#f2b632" stroke-width="2"/>'
            + '<path d="M12 8l-3.5 5.5 3.5 5.5 3.5-5.5z" fill="#f2b632"/>'
            + '<path d="M21.5 12.5c4.5 1 6 5 4.6 9.5" fill="none" stroke="#3fe0d0" stroke-width="2.8" stroke-linecap="round"/><path d="M21.6 21l4.2 7.5 4.4-7.4z" fill="#3fe0d0"/>'),
        axiom: svg('<rect x="6.5" y="2.5" width="19" height="27" rx="2.5" fill="#e2cf9c" stroke="#6a4f1f" stroke-width="2"/>'
            + '<path d="M16 8v15M10 11h12M11.5 24h9M10 11l-2.4 6M10 11l2.4 6M22 11l-2.4 6M22 11l2.4 6" stroke="#4a3210" stroke-width="1.8" stroke-linecap="round" fill="none"/>'
            + '<path d="M7 17h6a3 3 0 0 1-6 0zM19 17h6a3 3 0 0 1-6 0z" fill="#4a3210"/>'),
        forward: svg(HOURGLASS),
        rewind: svg('<g transform="translate(32 0) scale(-1 1)">' + HOURGLASS + '</g>'),
        rules: svg('<path d="M6 27V6a3 3 0 0 1 3-3h17v22H9a3 3 0 0 0-3 3a3 3 0 0 0 3 3h17v-6" fill="#7a3b2a" stroke="#f2b632" stroke-width="2" stroke-linejoin="round"/>'
            + '<path d="M8.5 28h17" stroke="#efe3c8" stroke-width="2.2"/><path d="M11 9h10M11 13.5h7" stroke="#f2b632" stroke-width="2" stroke-linecap="round"/>'),
        help: svg('<rect x="6" y="5" width="20" height="22" rx="2" fill="#efe3c8" stroke="#b08a3a" stroke-width="2"/>'
            + '<path d="M4 6.5h24M4 25.5h24" stroke="#b08a3a" stroke-width="3.4" stroke-linecap="round"/>'
            + '<path d="M12.5 12.4a3.5 3.5 0 1 1 5.2 3c-1.1.6-1.7 1.3-1.7 2.6" fill="none" stroke="#1f7f77" stroke-width="2.6" stroke-linecap="round"/><circle cx="16" cy="21.6" r="1.6" fill="#1f7f77"/>'),
        leave: svg('<rect x="8" y="3" width="16" height="25" rx="1.5" fill="#f6c75a" stroke="#b08a3a" stroke-width="2"/>'
            + '<path d="M8 3l9 2.5v25L8 28z" fill="#8a5a2b" stroke="#4a3210" stroke-width="1.6" stroke-linejoin="round"/>'
            + '<circle cx="14.5" cy="17" r="1.4" fill="#f2b632"/><path d="M4 29h24" stroke="#b08a3a" stroke-width="2.4" stroke-linecap="round"/>'),
        close: svg('<path d="M9 9l14 14M23 9L9 23" stroke="#efe3c8" stroke-width="3.2" stroke-linecap="round"/>'),
        replay: svg('<path d="M4.5 12h5l7-6v20l-7-6h-5z" fill="#f2b632" stroke="#b08a3a" stroke-width="1.6" stroke-linejoin="round"/>'
            + '<path d="M21 11.5a6 6 0 0 1 0 9M24.5 8a11 11 0 0 1 0 16" fill="none" stroke="#3fe0d0" stroke-width="2.4" stroke-linecap="round"/>'),
    };
    // The word under each draw button (the tooltip has the details).
    const DRAW_LABEL = { deck: 'Your deck', axiom: 'Rule card', forward: 'Fate sooner', rewind: 'Fate later' };
    const DRAW_ART = { deck: 'ui/btn-draw-deck', axiom: 'ui/btn-draw-axiom', forward: 'ui/btn-fate-forward', rewind: 'ui/btn-fate-rewind' };
    let tipCount = 0;

    function colourChip(colour) {
        // A nicknamed creature has no colour at all ('none'), which is not the same as Memory.
        if (!Rift.COLOURS[colour]) return el('span.chip', { dataset: { colour: 'none' }, title: 'No colour' }, ['No colour']);
        const C = Rift.COLOURS[colour];
        return el('span.chip', { dataset: { colour }, title: C.name }, [C.icon + ' ' + C.name]);
    }

    function calmMotion() {
        const doc = root.document;
        if (doc && doc.body && doc.body.classList && doc.body.classList.contains('calm-motion')) return true;
        try { return !!(root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { return false; }
    }

    function resolvePlayer(p, save, seed) {
        const given = p.player || {};
        const S = Rift.State || {};
        let team = given.team;
        if ((!team || !team.length) && save) team = S.battleTeam ? S.battleTeam(save) : (save.creatures || []).slice(0, 10);
        if (!team || !team.length) team = B().Engine.randomTeam(Rift.makeRng(seed + ':you'), 10, { prefix: 'you', legendaries: false });
        let tactics = given.tactics;
        if (!tactics && save && S.deckTactics) tactics = S.deckTactics(save);
        return {
            name: 'You', team, tactics: tactics || undefined, hearts: given.hearts,
            items: given.items || (save && save.items) || {},
            axioms: given.axioms || (save && save.axiomLoadout && save.axiomLoadout.length ? save.axiomLoadout : save && save.axioms) || [],
            consumables: given.consumables || {},
            bag: given.bag || [],
            // Hero power ({ id, tweaks }, data/powers.js) chosen by the launcher (js/ui/battles.js).
            power: given.power || null,
            // Own rule cards for the opening hand (Granny's Spare Axiom), chosen by the launcher.
            ownAxioms: given.ownAxioms || [],
            art: given.art || (save && save.avatar && save.avatar.type && Rift.avatarArt ? Rift.avatarArt(save.avatar, 'neutral') : null),
        };
    }

    function mount(rootEl, params) {
        const p = params || {};
        const E = B().Engine;
        const guide = p.guide && p.guide.steps && p.guide.steps.length ? p.guide : null;
        const mode = p.mode || 'practice';
        const opp = p.opponent || {};
        const seed = String(p.seed == null ? Date.now().toString(36) : p.seed);
        const save = Rift.State && Rift.State.get ? Rift.State.get() : null;
        const me = resolvePlayer(p, save, seed);
        const oppTeam = opp.team && opp.team.length ? opp.team : E.randomTeam(Rift.makeRng(seed + ':opp'), 10, { prefix: 'npc', legendaries: false });
        // AI level (Normal / Competent / Expert; 'easy' and 'hard' are old names for the first two).
        const askedLevel = opp.ai || p.aiLevel || DEFAULT_AI[mode] || 'normal';
        const aiLevel = B().AI && B().AI.levelOf ? B().AI.levelOf(askedLevel) : askedLevel;
        const anteType = mode === 'practice' ? 'practice' : (opp.type || mode);
        const oppAxioms = opp.axioms || Rift.makeRng(seed + ':axiom-opponent').shuffle((Rift.data.axiomDecks || {}).starter || []).slice(0, 10);
        // A long title ("Sergeant Syllo · Road challenge") stays in tooltips; the engine's log and
        // the portrait use the short name before " · ".
        const oppTitle = opp.name || 'Rival';
        const oppShort = opp.shortName || String(oppTitle).split(' · ')[0] || oppTitle;

        let state = guide && guide.create ? guide.create() : p.initialState ? p.initialState : E.createBattle({
            seed,
            players: [
                { id: 'you', name: 'You', team: me.team, tactics: me.tactics, axioms: me.axioms, consumables: me.consumables, hearts: me.hearts, bag: me.bag, power: me.power, ownAxioms: me.ownAxioms },
                { id: 'opp', name: oppShort, team: oppTeam, tactics: opp.tactics, axioms: oppAxioms, hearts: opp.hearts, power: opp.power || null },
            ],
            axiomDeck: p.axiomDeck || E.buildAxiomDeck(me.axioms, oppAxioms),
            options: Object.assign({}, p.battleOptions, { mode }),
        });
        const oppName = state.players[OPP].name;
        const oppFull = guide ? oppName : oppTitle;
        const ante = B().Ante && !guide ? B().Ante.compute({ type: anteType, player: { items: me.items }, opponent: Object.assign({}, opp, { team: oppTeam }), seed }) : null;
        const ui = {
            sel: null, note: '', news: [], timer: null, noteTimer: null, ended: false, busy: false, queue: [],
            preview: null, drag: null, suppressClick: false, step: 0, sideOpen: false, inspectTimer: null,
            inspect: null, longPress: null, bannerTurn: null, bannerTimer: null,
            hoverBlock: null, confirm: false, handPos: null, bagOpen: false,
        };
        // Nothing is at stake in practice and story matches (not the guided lesson): they can be left.
        const canLeave = !guide && mode === 'practice';
        const nodes = {};
        const inspectables = {};   // key → { node, make } for the big-card preview
        const tipNodes = {};       // key → picture button, so a shown tooltip survives re-renders
        const tipId = 'b-tip-' + (++tipCount);
        let help = null;

        // ---- skeleton ----
        const dom = {};
        const lesson = p.lesson || (save && save.chapter && Rift.data.chapters && Rift.data.chapters[save.chapter] ? Rift.data.chapters[save.chapter].lesson : 1);
        const sceneId = ['scene/arena-l' + lesson, 'scene/arena'].find(id => has(id)) || 'scene/battle-table';
        if (Rift.Ambience) Rift.Ambience.scene(sceneId);
        const screen = el('div.battle' + (guide ? '.guide-mode' : ''), {}, [
            dom.arena = el('div.b-arena', {}, [
                // Top row: opponent hero | opponent hand (backs) | opponent energy.
                dom.oppRow = el('div.b-hero-row.opp', {}, [
                    dom.oppLeft = el('div.b-row-left'),
                    dom.oppHand = el('div.b-opp-hand'),
                    dom.oppRight = el('div.b-row-right'),
                ]),
                dom.oppBoard = el('div.b-board.opp-board', { dataset: { zone: 'opp-board' } }),
                dom.lane = el('div.b-lane', { dataset: { zone: 'lane' } }),
                dom.myBoard = el('div.b-board.my-board', { dataset: { zone: 'my-board' } }),
                // Bottom row: my hero | my hand | my energy.
                dom.myRow = el('div.b-hero-row.me', {}, [
                    dom.myLeft = el('div.b-row-left'),
                    dom.myHand = el('div.b-hand', { dataset: { zone: 'hand' } }),
                    dom.myRight = el('div.b-row-right'),
                ]),
                dom.end = el('div.b-end-wrap'),
                dom.draw = el('div.b-draw', { role: 'group', 'aria-label': 'Your draw' }),
                dom.choice = el('div.b-choice'),
                dom.arrow = svgArrow(),
                dom.floats = el('div.b-floats'),
                dom.banner = el('div.b-banner', { 'aria-hidden': 'true' }),
                // A card shown big over the opponent's side: what the opponent plays, a rule change.
                dom.reveal = el('div.b-reveal', { 'aria-live': 'polite' }),
                // Recent plays (newest at the top): a column of small pictures at the table's left edge;
                // hover shows the card and what happened.
                dom.recent = el('section.b-recent', { 'aria-label': 'Recent plays' }),
            ]),
            dom.coach = guide ? el('div.b-coach.panel', { role: 'region', 'aria-label': 'Granny\'s guide' }) : null,
            dom.side = el('aside.b-side', {}, [
                el('div.b-side-top', {}, [
                    iconButton('.b-help', { key: 'help', name: 'How to play', detail: 'All the card rules on one page.', art: 'ui/btn-help', svg: CTRL_SVG.help, onclick: openHelp }),
                    canLeave ? iconButton('.b-leave', { key: 'leave', name: 'Leave match', detail: 'Stop this match. Nothing is at stake.', art: 'ui/btn-leave', svg: CTRL_SVG.leave, onclick: askLeave }) : null,
                    iconButton('.b-side-close', { key: 'close', name: 'Close', detail: 'Hide the rules and the log.', svg: CTRL_SVG.close, onclick: () => toggleSide(false) }),
                ]),
                dom.rules = el('section.b-rules.panel', { 'aria-label': 'Rules in play' }),
                dom.wheel = wheelLegend(),
            ]),
            iconButton('.b-side-toggle', { key: 'side', name: 'Rules & log', detail: 'The rules now, the keywords, the colour wheel and what happened.', art: 'ui/btn-rules', svg: CTRL_SVG.rules, onclick: () => toggleSide() }),
            // The big preview sits over the side panel (or the far edge of the table), never over the
            // centre lane or End turn. See placeInspect.
            dom.inspect = el('div.b-inspect', { 'aria-hidden': 'true' }),
            dom.overlay = el('div.b-overlay'),
            // One small tooltip for every picture button (name + one detail line). See showTip.
            dom.tip = el('div.b-tip', { role: 'tooltip', id: tipId, 'aria-hidden': 'true' }),
        ]);
        const boardImg = Rift.Assets.img(sceneId, { className: 'scene-bg', label: 'the card table' });
        rootEl.appendChild(boardImg);
        rootEl.appendChild(screen);
        // The lesson boards paint a calm band across the middle (its centre at about 46.7% of the
        // picture's height). The lane sits above the screen's middle (the hand takes the bottom), so
        // plain "cover" leaves the band low; scale and shift the picture so the band stays behind the lane.
        const BOARD_BAND = 0.467;
        function alignBoard() {
            if (!/^scene\/arena-l/.test(sceneId) || !boardImg.naturalWidth || !rootEl.getBoundingClientRect) return;
            const box = rootEl.getBoundingClientRect(), lane = dom.lane.getBoundingClientRect();
            const W = rootEl.clientWidth, H = rootEl.clientHeight, iw = boardImg.naturalWidth, ih = boardImg.naturalHeight;
            if (!W || !H || !lane.height) return;
            const cy = lane.top + lane.height / 2 - box.top - rootEl.clientTop;
            const s = Math.max(W / iw, H / ih, cy / (BOARD_BAND * ih), (H - cy) / ((1 - BOARD_BAND) * ih));
            Object.assign(boardImg.style, { inset: 'auto', maxWidth: 'none', objectFit: 'fill', transitionProperty: 'none',
                width: iw * s + 'px', height: ih * s + 'px', left: (W - iw * s) / 2 + 'px', top: cy - BOARD_BAND * ih * s + 'px' });
        }
        boardImg.addEventListener('load', alignBoard);
        const boardObserver = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(alignBoard) : null;
        if (boardObserver) { boardObserver.observe(rootEl); boardObserver.observe(dom.lane); }
        screen.addEventListener('keydown', e => { if (e.key === 'Escape') { hideTip(); cancelDrag(); if (ui.bagOpen) toggleBag(false); clearSel(); } });
        screen.addEventListener('pointermove', onPointerMove);
        screen.addEventListener('pointerup', onPointerUp);
        screen.addEventListener('pointercancel', () => { cancelDrag(); cancelLongPress(); cancelTipPress(); });
        // Pressing the mouse anywhere closes the preview (and a waiting one never opens).
        screen.addEventListener('pointerdown', ev => { if (!ev.pointerType || ev.pointerType === 'mouse') hideInspect(); });
        // A tooltip opened by a long-press stays until the next tap anywhere.
        screen.addEventListener('pointerdown', () => { if (ui.tip && ui.tip.sticky) hideTip(); });
        screen.addEventListener('dragstart', e => e.preventDefault());
        screen.addEventListener('contextmenu', e => { if (e.target && e.target.closest && e.target.closest('[data-cid], [data-tip]')) e.preventDefault(); });

        function toggleSide(on) {
            ui.sideOpen = on == null ? !ui.sideOpen : on;
            screen.classList.toggle('side-open', ui.sideOpen);
        }
        function openHelp() {
            if (help || ui.confirm || !Rift.Battles || !Rift.Battles.rules) return;
            // The opponent pauses only once the window is really open.
            let opened = null;
            try { opened = Rift.Battles.rules(() => { help = null; if (!ui.ended) schedule(); }); } catch (e) { console.error('[battle] How to play', e); }
            if (opened) { help = opened; clearTimeout(ui.timer); }
        }

        // ---- legality ----
        const decider = () => E.decider(state);
        const myTurn = () => decider() === ME && !ui.ended && !ui.busy && !ui.preview && !ui.confirm;
        const step = () => (guide ? guide.steps[ui.step] || null : null);
        const matches = expect => a => Object.keys(expect).every(k => a[k] === expect[k]);
        function legal() {
            if (!myTurn()) return [];
            const L = E.legalActions(state);
            const st = step();
            if (guide) return st ? L.filter(a => matches(st.expect)(a) || (st.trap && matches(st.trap.expect)(a))) : [];
            return L;
        }
        const name = cid => E.cardName(state, cid);

        // Targets for the current selection: Map target → action.
        function targetMap(sel, L) {
            const out = new Map();
            if (!sel) return out;
            (L || legal()).forEach(a => {
                if (!a.target) return;
                if (sel.kind === 'board' && a.type === 'attack' && a.cid === sel.cid) out.set(a.target, a);
                if (sel.kind === 'hand' && a.type === 'play' && a.cid === sel.cid) out.set(a.target, a);
                if (sel.kind === 'activate' && a.type === 'activate' && a.cid === sel.cid && a.ability === sel.ability) out.set(a.target, a);
                if (sel.kind === 'item' && a.type === 'item' && a.id === sel.id) out.set(a.target, a);
                if (sel.kind === 'power' && a.type === 'power') out.set(a.target, a);
            });
            return out;
        }

        // ---- acting ----
        function act(action) {
            if (ui.ended) return;
            clearTimeout(ui.timer);
            const by = decider();
            const before = rects();
            const guided = guide && by === ME && !ui.busy && step() && matches(step().expect)(action);
            if (action.type === 'end' && by === ME) ui.snap = snapshot();
            if (by === ME && action.type !== 'draw') ui.recapTurn = null;   // the recap has been read
            // The lesson's trap: the move is not made; Granny shows why it would backfire.
            if (guide && by === ME && !ui.busy && step() && step().trap && matches(step().trap.expect)(action) && !matches(step().expect)(action)) { springTrap(step().trap); return; }
            try {
                state = E.applyAction(state, Object.assign({ player: by }, action));
            } catch (e) {
                console.error('[battle]', e);
                return;
            }
            // A creature dropped on the table that was still waiting for its Entrance target is
            // not played when something else happens first: say so (it stays in the hand).
            const waiting = ui.sel && ui.sel.pending && ui.sel.cid !== action.cid ? ui.sel.cid : null;
            if (action.type === 'item' || action.type === 'end') ui.bagOpen = false;
            ui.sel = null;
            ui.preview = null;
            ui.note = '';
            if (guided) { ui.busy = true; ui.queue = (step().replies || []).slice(); if (ui.queue.some(r => r.say)) stopVoice(); }
            noteEvents(state.lastEvents);
            render();
            effects(state.lastEvents, before);
            ruleReveal(state.lastEvents);
            if (waiting && state.players[ME].hand.includes(waiting)) setNote(name(waiting) + ' was not played. It is back in your hand: its Entrance needs a target first.');
            schedule();
        }

        // Show what the opponent (or a scripted reply) is about to do, then do it. A card the opponent
        // plays is first shown big with a caption (a rule card is shown once it is in play, by
        // ruleReveal); an attack shows its arrow.
        function perform(action, revealed) {
            if (ui.ended) return;
            const by = decider();
            const target = action.target;
            if (by === OPP && !revealed && action.type === 'play' && state.cards[action.cid]) {
                const what = state.cards[action.cid].kind === 'tactic' ? 'plays a tactic' : 'plays a creature';
                const aim = target ? ' on ' + targetName(target) : '';
                showReveal(cardEl(action.cid, { size: 'big', unregistered: true }), oppName + ' ' + what + aim, REVEAL, '', false);
                ui.timer = setTimeout(() => perform(action, true), REVEAL);
                return;
            }
            // The opponent's power is shown big too, then (with a target) its arrow.
            if (by === OPP && !revealed && action.type === 'power' && state.players[OPP].power) {
                const pw = state.players[OPP].power;
                showReveal(powerBig(pw.id, OPP), oppName + ' uses the power ' + powerName(pw.id) + (target ? ' on ' + targetName(target) : ''), REVEAL, 'power', false);
                ui.timer = setTimeout(() => perform(action, true), REVEAL);
                return;
            }
            if (target && (action.type === 'attack' || action.type === 'play' || action.type === 'activate' || action.type === 'power')) {
                ui.preview = { cid: action.type === 'power' ? 'pw' + by : action.cid, target, by, action };
                render();
                ui.timer = setTimeout(() => { ui.preview = null; act(action); }, PREVIEW);
            } else act(action);
        }

        // The big card over the opponent's side, with a caption; it fades after ms. While a reveal is
        // up, the opponent and the lesson wait (schedule), so each move can be read before the next.
        // resume: call schedule() when it fades (false when the caller has its own timer running).
        function showReveal(card, caption, ms, cls, resume) {
            clearTimeout(ui.revealTimer);
            dom.reveal.innerHTML = '';
            dom.reveal.className = 'b-reveal' + (cls ? ' ' + cls : '');
            put(dom.reveal, el('div.b-reveal-caption', { text: caption }), card);
            void dom.reveal.offsetWidth;
            dom.reveal.classList.add('show');
            ui.holding = true;
            ui.revealTimer = setTimeout(() => {
                dom.reveal.classList.remove('show');
                ui.holding = false;
                if (resume !== false) schedule();
            }, ms);
        }
        // A rule changed (a card played or Fate): show the card and what it changes, for everyone.
        function ruleReveal(events) {
            const ev = events.filter(e => e.t === 'axiom').pop();
            const reset = events.some(e => e.t === 'reset');
            if (!ev && !reset) return;
            if (ev) {
                const ax = (Rift.data.axioms || {})[ev.id] || { name: ev.id };
                const by = ev.clear ? (ev.player === ME ? 'You clear every rule' : oppName + ' clears every rule')
                    : ev.player == null ? 'Fate turns over a free rule' : ev.player === ME ? 'You change a rule' : oppName + ' changes a rule';
                const what = (RULE_LABEL[ax.category] || ax.category) + ': ' + (ax.short || ax.name);
                showReveal(el('div.b-reveal-rule', {}, [axiomCardEl(ev.id, { size: 'big' }), el('div.b-reveal-what', { text: what })]), by + '!', RULE_SHOW, 'rule');
            } else {
                showReveal(el('div.b-reveal-rule', {}, [el('div.b-reveal-reset', {}, [icon('ui/fate-reset', '↺', 'b-reset-icon'), el('div', { text: 'All rules go back to the basics.' })])]), 'Fate: reset!', RULE_SHOW, 'rule');
            }
        }

        function aiAction() {
            try {
                const a = B().AI.choose(state, { level: aiLevel });
                if (a) return a;
            } catch (e) { console.error('[battle] AI', e); }
            const L = E.legalActions(state);
            return L.find(a => a.type === 'draw') || L.find(a => a.type === 'end') || L[0] || null;
        }

        function schedule() {
            clearTimeout(ui.timer);
            if (ui.ended || help || ui.confirm) return;
            // A card shown big (a reveal) is read first: everything waits until it fades.
            if (ui.holding || ui.saying) return;
            if (E.winner(state) != null) { ui.timer = setTimeout(finish, 1000); return; }
            if (ui.preview && ui.preview.action) { const a = ui.preview.action; ui.preview = null; perform(a); return; }
            if (ui.queue.length) {
                // A narration line ({ say }) in the lesson's replies: show it, say it, and go on only
                // when the voice has finished (each reply is its own small block).
                if (!ui.queue[0].type && ui.queue[0].say) { narrate(ui.queue.shift().say); return; }
                ui.timer = setTimeout(() => perform(ui.queue.shift()), REPLY_DELAY);
                return;
            }
            if (guide && ui.busy) {
                ui.busy = false;
                ui.say = '';
                ui.step += 1;
                startHintClock();
                render();
                speak();
                return;
            }
            if (!guide && decider() === OPP) {
                ui.timer = setTimeout(() => { const a = aiAction(); if (a) perform(a); }, AI_DELAY);
            }
        }

        function visibleText(ev) {
            if (ev.privateTo === undefined || ev.privateTo === ME) return ev.text;
            return ev.publicText || null;
        }

        function noteEvents(events) {
            ui.news = events.map(visibleText).filter(Boolean).filter(t => !/^Round \d+\.$/.test(t) && !/Choose a draw\.$/.test(t));
            try { battleSounds(events); } catch (e) { /* sound is optional */ }
        }

        // Sounds for one batch of events (assets/sfx/el via data/sfx-el.js; older Kenney names as the
        // fallback). Sounds in a batch are spaced out, creature calls use their own channel, and at most
        // one spoken creature bark (data/barks.js) plays, only when it is recorded and no
        // other voice is talking.
        function battleSounds(events) {
            const A = Rift.Audio;
            if (!A || !A.has) return;
            const cue = [];
            const add = (name, fallback, opts) => {
                const n = A.has(name) ? name : fallback && A.has(fallback) ? fallback : null;
                if (n) cue.push([n, opts || {}]);
            };
            const sp = cid => { const c = cid && state.cards[cid]; return c && c.kind === 'creature' ? c.species : null; };
            const call = (cid, kind) => { const s = sp(cid); if (s) add('cr-' + s + '-' + kind, null, { bus: 'creature' }); };
            const dying = new Set(events.filter(ev => ev.t === 'defeated').map(ev => ev.cid));
            const avatar = ((Rift.State && Rift.State.get()) || {}).avatar || {};
            const grunt = { [ME]: avatar.variant === 'girl' ? 'hurt-girl' : avatar.variant === 'boy' ? 'hurt-boy' : null, [OPP]: opp.gender ? 'hurt-' + opp.gender : null };
            let bark = null;
            const wantBark = (cid, kind, chance) => { const s = sp(cid); if (!bark && s && Math.random() < chance) bark = { s, kind }; };
            events.forEach(ev => {
                switch (ev.t) {
                    case 'play': add('summon', 'card-play'); call(ev.cid, 'enter'); wantBark(ev.cid, 'enter', 0.6); break;
                    case 'tactic-play': {
                        const def = (Rift.data.tactics || {})[ev.id] || {};
                        add('tactic-' + ev.id, 'cast-' + (def.colour || 'colourless'));
                        if (!cue.length) add('card-play');
                        break;
                    }
                    case 'item-use': add('item-use', 'card-play'); break;
                    case 'axiom-play': add('draw'); break;
                    case 'axiom': add('axiom', 'axiom'); break;
                    case 'reset': add('reset', 'axiom'); break;
                    case 'power-use': add('power', 'jingle'); break;
                    case 'activate': add('activate'); call(ev.cid, 'enter'); wantBark(ev.cid, 'ability', 0.7); break;
                    case 'attack': call(ev.cid, 'attack'); add('slash'); break;
                    case 'fight': add('fight', 'block'); break;
                    case 'damage': add('impact', 'hit'); if (!dying.has(ev.cid)) call(ev.cid, 'hurt'); break;
                    case 'shield': add('shield', 'block'); break;
                    case 'hit': add('hero-hit', 'hit'); if (grunt[ev.player]) add(grunt[ev.player], null, { bus: 'grunt' }); break;
                    case 'defeated': call(ev.cid, 'die'); add('defeat', 'defeat'); wantBark(ev.cid, 'defeat', 0.5); break;
                    case 'fizzle': add('fizzle'); break;
                    case 'draw': if (ev.player === ME) add('draw', null, { volume: 0.5 }); break;
                }
            });
            if (Rift.Ambience && events.some(ev => ev.t === 'hit' || ev.t === 'end')) {
                const low = Math.min(...state.players.map(P => P.hearts / (P.maxHearts || 12)));
                Rift.Ambience.tension(events.some(ev => ev.t === 'end') ? 0 : Rift.clamp((0.75 - low) / 0.6, 0, 1));
            }
            // Space the batch out; a channel may only cut its own previous sound.
            cue.slice(0, 6).forEach(([n, o], i) => setTimeout(() => { try { A.sfx(n, o); } catch (e) { /* no audio */ } }, i * 220));
            if (bark && !guide && !A.speaking()) {
                const lines = (((Rift.data.barks || {})[bark.s] || {})[bark.kind]) || [];
                const text = lines[Math.floor(Math.random() * lines.length)];
                const voice = text && Rift.voiceId(bark.s, text);
                if (voice && (Rift.data.voices || {})[voice]) setTimeout(() => { if (!A.speaking()) A.speak({ speaker: bark.s, text, voice }); }, cue.length * 220 + 300);
            }
        }

        function setNote(text) {
            ui.note = text;
            render();
            clearTimeout(ui.noteTimer);
            ui.noteTimer = setTimeout(() => { if (ui.note === text) { ui.note = ''; if (!ui.ended && !ui.drag) render(); } }, 4000);
        }

        function clearSel() { if (ui.sel) { ui.sel = null; render(); } }

        // ---- why a card can't act (short notes for disabled controls) ----
        function whyNot(cid) {
            if (ui.ended) return '';
            if (guide && !ui.busy) return 'Not now. Follow the gold pointer.';
            if (ui.busy || decider() !== ME) return 'Wait for your turn.';
            if (state.phase === 'draw') return 'First choose your draw.';
            if (state.phase === 'choose') return 'First answer the question.';
            const c = state.cards[cid];
            const P = state.players[ME];
            if (P.hand.includes(cid)) {
                if (E.playsLeft && !E.playsLeft(state, ME)) return 'No card plays left this turn (' + E.playLimit(state, ME) + ' per turn). You can still attack.';
                const cost = E.playCost(state, cid);
                if (cost > P.energy) return name(cid) + ' needs ' + cost + ' energy. You have ' + P.energy + '.';
                if (c.kind === 'creature' && P.board.length >= state.options.boardLimit) return 'Your side is full.';
                const tdef = c.kind === 'tactic' ? (Rift.data.tactics || {})[c.tactic] : null;
                if (tdef && tdef.colour && !E.colourInPlay(state, ME, tdef.colour)) return needsText(tdef.colour);
                return 'It has no target right now.';
            }
            if (c.controller !== ME) return 'That is ' + oppName + '\'s creature. Pick one of yours first.';
            const d = E.describe(state, cid);
            if (d.sleeping) return name(cid) + ' is asleep. It can attack next turn.';
            if (d.frozen) return name(cid) + ' was lectured. ' + frozenText(cid) + '.';
            if (d.activated) return name(cid) + ' used its ability this turn.';
            if (d.attacks) return name(cid) + ' already attacked this turn.';
            if (d.attack <= 0) return name(cid) + ' has 0 attack.';
            return 'No attacks left this turn under the current rules.';
        }

        // A lectured (frozen) creature: the lecture lasts until the end of its controller's next turn.
        function frozenText(cid) {
            const c = state.cards[cid];
            return c && c.controller === state.active ? 'It can\'t attack this turn' : 'It can\'t attack on its next turn';
        }
        // "Granny's Billie Eelish is Elusive: …" for a tactic or Entrance aimed at an Elusive enemy.
        function elusiveNote(t) {
            const c = state.cards[t];
            if (!c || c.kind !== 'creature' || c.controller === ME || !state.players[OPP].board.includes(t) || !E.hasKeyword(state, t, 'elusive')) return '';
            return targetName(t) + ' is Elusive: tactics and abilities can\'t target it.';
        }

        // Why an attacker can't hit this target: Guard first, else the general hint.
        function badTargetNote(att, target) {
            const c = state.cards[att];
            if (!c || target === att) return '';
            const foe = 1 - c.controller;
            const enemy = target === E.heroId(foe) || state.players[foe].board.includes(target);
            if (!enemy) return 'Attack an enemy: a glowing creature or the enemy hero.';
            if (E.canAttack(state, att)) {
                const guards = E.attackTargets(state, att).filter(t => !E.isHero(t) && E.hasKeyword(state, t, 'guard'));
                if (guards.length && !guards.includes(target)) {
                    return guards.length === 1 ? name(guards[0]) + ' has Guard. Attack it first.'
                        : guards.map(name).join(' and ') + ' have Guard. Attack one of them first.';
                }
                if (guide && E.attackTargets(state, att).includes(target)) return 'Not now. Follow the gold pointer.';
            }
            return 'You can\'t attack that. Glowing cards are valid targets.';
        }

        // ---- card faces ----
        function gem(kind, value, extra) {
            const art = { cost: 'ui/stat-cost', attack: 'ui/stat-attack', health: 'ui/stat-health' }[kind];
            const style = bg(art);
            return el('span.bc-gem.' + kind + (style ? '.art' : '') + (extra ? '.' + extra : ''), style ? { style, text: String(value) } : { text: String(value) });
        }
        function icon(id, fallback, cls, title) {
            const style = bg(id);
            return el('span.b-icon' + (cls ? '.' + cls : '') + (style ? '.art' : ''), { style, title: title || null, text: style ? '' : fallback });
        }

        // "Entrance", "Last Word", "Activate (1⚡)" or '' for an always-on ability.
        function timing(l) {
            if (!AB_KIND[l.kind]) return '';
            return AB_KIND[l.kind] + (l.kind === 'activate' && l.cost != null ? ' (' + l.cost + '⚡)' : '');
        }

        // Small cards (board, hand) show keyword chips and the ability's name in readable type;
        // the big preview (hover, focus or long-press) shows the full text.
        // On the table (size 'board') a card shows only the keyword chips and the ability's timing
        // (Entrance / Last Word / Activate), so nothing is cut off; the hand also shows the ability's name.
        function briefLines(d, size) {
            const onTable = size === 'board';
            const ignored = k => k === 'guard' && E.rules(state).ignoreGuard;
            const kws = d.keywords.filter(k => !(onTable && k === 'guard')).map(k => has('ui/kw-' + k)
                ? el('span.bc-kw.art' + (ignored(k) ? '.off' : ''), { title: ignored(k) ? 'Guard is ignored under the current rules.' : null }, [icon('ui/kw-' + k, '', 'kw', KW_NAME[k] || k), KW_NAME[k] || k])
                : el('span.bc-kw' + (ignored(k) ? '.off' : ''), { text: KW_NAME[k] || k }));
            // The timing word comes first, in words: "Last Word: Metaverse", "Activate (1⚡): Well, Actually".
            const abilities = d.lines.map(l => el('span.bc-ab.' + l.kind + (l.off ? '.off' : '') + (l.gained ? '.gained' : ''), {}, [
                has('ui/ab-' + l.kind) ? icon('ui/ab-' + l.kind, '', 'ab', AB_KIND[l.kind] || l.name) : null,
                timing(l) ? el('span.bc-ab-kind', { text: onTable ? AB_KIND[l.kind] : timing(l) + ':' }) : null,
                onTable && timing(l) ? null : el('span.bc-ab-name', { text: l.name }),
            ]));
            return el('div.bc-brief', {}, [kws.length ? el('div.bc-kws-row', {}, kws) : null].concat(abilities,
                !d.lines.length && !d.keywords.length ? [el('span.bc-ab.none', { text: d.silenced ? 'No abilities' : '—' })] : []));
        }

        const upFirst = t => (t ? t.charAt(0).toUpperCase() + t.slice(1) : t);
        const ordinal = n => n + (n === 1 ? 'st' : n === 2 ? 'nd' : n === 3 ? 'rd' : 'th');
        // Long names get a smaller type size (and may wrap to two lines) instead of being cut off.
        const fitName = n => (n.length > 18 ? '.xlong' : n.length > 11 ? '.long' : '');

        function creatureFace(cid, size) {
            const d = E.describe(state, cid);
            const frame = bg('ui/card-' + d.printedColour) || bg('ui/card-' + d.colour);
            const atkClass = d.attack > d.baseAttack ? 'up' : d.attack < d.baseAttack ? 'down' : '';
            const hpClass = d.damaged ? 'hurt' : d.maxHealth > d.baseHealth ? 'up' : '';
            // Every card face shows the short form; the magnifier's notes hold the full ability text.
            const text = briefLines(d, size === 'big' ? 'hand' : size);
            return [
                el('div.bc-bg'),
                el('div.bc-frame' + (frame ? '.art' : ''), frame ? { style: frame } : {}),
                el('div.bc-art', {}, [Rift.Assets.img('creature/' + d.species + '/idle', { colour: d.printedColour, label: d.speciesName, alt: '' })]),
                gem('cost', d.cost),
                el('div.bc-name' + fitName(d.name + (d.legendary ? ' ★' : '')), { text: d.name + (d.legendary ? ' ★' : '') }),
                text,
                gem('attack', d.attack, atkClass),
                gem('health', d.health, hpClass),
                d.keywords.includes('shield') ? el('div.bc-bubble') : null,
                // Guard: a shield badge under the card's bottom edge (dimmed while a rule ignores Guard).
                size === 'board' && d.keywords.includes('guard') ? el('div.bc-guard' + (E.rules(state).ignoreGuard ? '.off' : ''), {
                    style: bg('ui/kw-guard'), text: has('ui/kw-guard') ? '' : '🛡️', 'aria-hidden': 'true',
                }) : null,
                // States read at a glance on the table: a dark veil with a word over the picture.
                size === 'board' && d.sleeping ? el('div.bc-state.sleep', {}, [icon('ui/state-sleeping', 'Zzz', 'veil'), el('span', { text: 'Asleep' })]) : null,
                size === 'board' && !d.sleeping && d.frozen ? el('div.bc-state.frozen', {}, [icon('ui/state-frozen', '❄', 'veil'), el('span', { text: 'Lectured' })]) : null,
                size !== 'board' && d.sleeping ? icon('ui/state-sleeping', 'Zzz', 'state.sleep', 'Asleep') : null,
                size !== 'board' && d.frozen ? icon('ui/state-frozen', '❄', 'state.frozen', frozenText(cid)) : null,
                size === 'board' && d.silenced ? el('div.bc-state.silenced', {}, [el('span', { text: 'No ability' })]) : null,
                // A second attack this turn (the Axiom of Haste or an ability): say why it glows again.
                d.onBoard && d.attacks > 0 && d.canAttack ? el('span.b-again', { text: ordinal(d.attacks + 1) + ' attack' }) : null,
            ];
        }

        // Plain notes under the big preview: colour, keywords explained, state and changes.
        function creatureNotes(cid) {
            const d = E.describe(state, cid);
            const KT = B().KEYWORD_TEXT || {};
            const lines = [];
            if (d.sleeping) lines.push('💤 Asleep: it can attack next turn.');
            else if (d.frozen) lines.push('❄ Lectured: ' + frozenText(cid).replace(/^It c/, 'it c') + '.');
            else if (d.onBoard && d.canAttack && d.attacks > 0 && state.cards[cid].controller === ME && decider() === ME) lines.push('✅ Ready again: the rules let it attack ' + (d.attacks === 1 ? 'twice' : 'again') + ' this turn (' + ordinal(d.attacks + 1) + ' attack).');
            else if (d.onBoard && d.canAttack && state.cards[cid].controller === ME && decider() === ME) lines.push('✅ Ready: drag it onto a target to attack.');
            d.keywords.forEach(k => { if (KT[k]) lines.push(KT[k]); });
            if (d.damaged) lines.push('Health ' + d.health + ' of ' + d.maxHealth + '. Damage stays.');
            d.attackParts.filter(x => x.source !== 'base').forEach(x => lines.push(x.label + ': ' + (x.amount > 0 ? '+' : '') + x.amount + ' attack.'));
            // The full ability text first (it never fits on the card face itself).
            const abilityLines = d.lines.map(l => el('div.b-note-line.b-ability' + (l.off ? '.off' : '') + (l.gained ? '.gained' : ''), {}, [
                el('b', { text: (l.warped ? '🌀 ' : '') + (timing(l) ? timing(l) + ' · ' + l.name + ': ' : l.name + ': ') }),
                upFirst(l.text.replace(/^(Guard|Swift|Shield|Elusive)\.\s*/, '').replace(/^(Entrance|Last Word|Activate \(\d+ energy\)):\s*/i, '')),
                l.kind === 'entrance' ? el('span.b-note-hint', { text: ' (Entrance: it happens when you play the card.)' }) : null,
                l.kind === 'lastword' ? el('span.b-note-hint', { text: ' (Last Word: it happens when this creature is defeated.)' }) : null,
                l.kind === 'activate' ? el('span.b-note-hint', { text: ' (Activate: pay the energy; it uses this creature\'s attack this turn.)' }) : null,
            ]));
            if (!d.lines.length) abilityLines.push(el('div.b-note-line.off', { text: d.silenced ? 'It lost its abilities.' : 'No ability.' }));
            const tags = [];
            // Only your own borrowed cards are tagged (an opponent's team is never "loaned").
            if (d.loaner && state.cards[cid].owner === ME) tags.push('Loaned');
            if (d.trophyOf) tags.push('🏆 ' + d.trophyOf);
            if (d.taught) tags.push('Learned: ' + d.taught);
            if (d.variant && d.variant.trait) tags.push('Natural ' + d.variant.trait);
            if (d.injured && d.injured.includes('minus-one')) tags.push('🤕 Injured in an earlier battle: −1 attack');
            if (d.prediction) tags.push('🔮 ' + (Rift.COLOURS[d.prediction] || {}).name);
            if (d.metaverseUsed) tags.push('Last Word used');
            return el('div.b-notes', {}, [
                el('div.b-notes-tags', {}, [colourChip(d.colour)].concat(tags.map(t => el('span.b-tag', { text: t })))),
                ...abilityLines,
                ...lines.map(t => el('div.b-note-line', { text: t })),
                whyNotNote(cid),
            ]);
        }

        function tacticFace(cid, size) {
            const d = E.describe(state, cid);
            // A colour tactic: its own frame art if painted, else the CSS frame tinted to the colour.
            const frame = d.colour ? bg('ui/card-tactic-' + d.colour) : bg('ui/card-tactic');
            const art = has('tactic/' + d.id) ? Rift.Assets.img('tactic/' + d.id, { alt: '' }) : el('div.bc-glyph', { text: TACTIC_ICON[d.id] || '✦' });
            return [
                el('div.bc-bg'),
                el('div.bc-frame' + (frame ? '.art' : ''), frame ? { style: frame } : {}),
                el('div.bc-art', {}, [art]),
                gem('cost', d.cost),
                d.colour ? colourEmblem(d.colour, d.colourReady) : null,
                el('div.bc-name' + fitName(d.name + (d.rarity === 'rare' ? ' ★' : '')), { text: d.name + (d.rarity === 'rare' ? ' ★' : '') }),
                el('div.bc-text', {}, [
                    size === 'big' ? null : el('div.bc-kind', { text: d.colour ? tacticKind(d) : 'Tactic' }),
                    size === 'big' && d.colour ? el('div.bc-kind.tc-kind', { text: tacticKind(d) }) : null,
                    el('div.bc-line', { text: d.short || d.text }),
                    d.colour && !d.colourReady && state.cards[cid].controller === ME ? el('div.bc-need', { text: needsText(d.colour) }) : null,
                ]),
            ];
        }
        // "Reason · uncommon" under the name of a colour tactic.
        const tacticKind = d => (Rift.COLOURS[d.colour] || { name: d.colour }).name + (d.rarity ? ' · ' + d.rarity : '');
        // A colour tactic is played only while you control a creature of its colour.
        const needsText = colour => { const C = Rift.COLOURS[colour] || { colour, name: colour }; return 'Needs a ' + C.colour + ' (' + C.name + ') creature in play.'; };
        // The colour's emblem in the card's top corner; lit while a creature of that colour is in play.
        function colourEmblem(colour, on) {
            const C = Rift.COLOURS[colour] || {};
            return el('div.bc-emblem' + (on ? '.on' : ''), { title: (C.name || colour) + ' tactic', 'aria-hidden': 'true' },
                [has('ui/icon-' + colour) ? Rift.Assets.img('ui/icon-' + colour, { alt: '' }) : el('span', { text: C.icon || '◆' })]);
        }

        function axiomFace(id, size) {
            const ax = (Rift.data.axioms || {})[id] || { name: id, text: '', category: '' };
            const frame = bg('ui/card-axiom');
            return [
                el('div.bc-bg'),
                el('div.bc-frame' + (frame ? '.art' : ''), frame ? { style: frame } : {}),
                el('div.bc-art', {}, [has('ui/axiom-' + id) ? Rift.Assets.img('ui/axiom-' + id, { alt: '' }) : el('div.bc-glyph', { text: '⚖' })]),
                gem('cost', E.axiomCost(state, id)),
                el('div.bc-name' + fitName(ax.name), { text: ax.name }),
                el('div.bc-text', {}, [
                    isBasic(ax) ? el('div.bc-kind.basic', { text: axiomKind(ax) }) : size === 'big' ? null : el('div.bc-kind', { text: axiomKind(ax) }),
                    el('div.bc-line', { text: ax.short ? (size === 'hand' ? ax.short : (RULE_LABEL[ax.category] || ax.category) + ': ' + ax.short) : ax.text }),
                ]),
            ];
        }
        // A "basic" axiom only puts its category back to the default rule (engine flag ax.basic):
        // it is labelled "Back to normal" and never listed as a changed rule.
        const isBasic = ax => !!(ax && ax.basic);
        // Active rule cards that really change a basic rule (engine: changedAxioms).
        const changedRules = () => (E.changedAxioms ? E.changedAxioms(state) : E.activeAxioms(state).filter(ax => !isBasic(ax)));
        const axiomKind = ax => (isBasic(ax) ? 'Back to normal: ' + (ax.category || 'rule') : ax.own ? 'Your own card' : (ax.category || 'rule') + ' rule');

        // A card element. o: { size, classes, onclick, drag, target, guide }
        function cardEl(cid, o) {
            const c = state.cards[cid];
            const size = o.size || 'board';
            const kind = c.kind === 'tactic' ? 'tactic' : 'creature';
            const colour = kind === 'creature' ? E.colourOf(state, c) : 'tactic';
            const tcolour = kind === 'tactic' ? ((Rift.data.tactics || {})[c.tactic] || {}).colour : null;
            const clickable = !!o.onclick;
            const node = el((clickable ? 'button' : 'div') + '.bc.' + kind + '.' + size, {
                type: clickable ? 'button' : null,
                dataset: tcolour ? { cid, colour, tcolour } : { cid, colour },
                'aria-label': cardLabel(cid),
            }, kind === 'tactic' ? tacticFace(cid, size) : creatureFace(cid, size));
            if (o.target) node.dataset.target = cid;
            (o.classes || []).forEach(k => node.classList.add(k));
            if (clickable) node.addEventListener('click', ev => { if (ui.suppressClick) return; o.onclick(ev); });
            if (o.drag) node.addEventListener('pointerdown', ev => startDrag(ev, o.drag, node));
            if (size !== 'big') hoverInspect(node, () => cardPreview(cid), cid);
            // Only the card on the table (or in the hand) is "the" card: the big hover copy and
            // question-panel copies must never take over glows, damage numbers or lunges.
            if (size !== 'big' && !o.unregistered && !nodes[cid]) nodes[cid] = node;
            return node;
        }

        // "Can't play it now: …" for a dimmed card in my hand (null otherwise).
        function whyNotNote(cid) {
            if (!state.players[ME].hand.includes(cid) || decider() !== ME || state.phase !== 'main' || ui.busy) return null;
            if (legal().some(a => a.type === 'play' && a.cid === cid)) return null;
            return el('div.b-note-line.b-why', { text: 'Can\'t play it now: ' + whyNot(cid) });
        }
        // A card in the opponent's hand that I may see (Night Sight): say so under the big copy.
        function seenNote(cid) {
            if (!state.players[OPP].hand.includes(cid)) return null;
            const sight = (state.players[ME].sight || []).includes(cid);
            return el('div.b-note-line.b-seen-note', {}, [el('b', { text: '👁 Seen: ' }), 'this card is in ' + oppName + '\'s hand'
                + (sight ? '. You see it with Night Sight until your next turn.' : '. You know it is there.')]);
        }
        function cardPreview(cid) {
            const out = cardPreviewOf(cid);
            const seen = seenNote(cid);
            if (seen) out[1].appendChild(seen);
            return out;
        }
        function cardPreviewOf(cid) {
            const big = cardEl(cid, { size: 'big' });
            if (state.cards[cid].kind === 'creature') return [big, creatureNotes(cid)];
            const d = E.describe(state, cid);
            const C = d.colour ? Rift.COLOURS[d.colour] || { name: d.colour } : null;
            const mine = state.cards[cid].controller === ME;
            return [big, el('div.b-notes', {}, [
                C ? el('div.b-notes-tags', {}, [colourChip(d.colour)]) : null,
                el('div.b-note-line.b-ability', {}, [el('b', { text: d.name + ': ' }), d.text]),
                el('div.b-note-line', {}, [el('b', { text: 'Tactic: ' }), 'it works once, then goes to your discard pile.']),
                whyNotNote(cid),
                C ? el('div.b-note-line', {}, [el('b', { text: C.name + ' tactic' + (d.rarity ? ' (' + d.rarity + ')' : '') + ': ' }),
                    'it can only be played while you control a ' + C.colour + ' (' + C.name + ') creature. '
                    + (mine ? (d.colourReady ? 'You do now.' : 'You don\'t right now.') : '')]) : null,
                d.flavour ? el('div.b-note-line.b-flavour', { text: d.flavour }) : null,
            ])];
        }

        function axiomCardEl(id, o) {
            const clickable = !!(o && o.onclick);
            const node = el((clickable ? 'button' : 'div') + '.bc.axiom.' + ((o && o.size) || 'hand'), {
                type: clickable ? 'button' : null, dataset: { axiom: id },
                'aria-label': 'Rule card: ' + ((Rift.data.axioms || {})[id] || { name: id }).name,
            }, axiomFace(id, (o && o.size) || 'hand'));
            ((o && o.classes) || []).forEach(k => node.classList.add(k));
            if (clickable) node.addEventListener('click', ev => { if (ui.suppressClick) return; o.onclick(ev); });
            if (o && o.drag) node.addEventListener('pointerdown', ev => startDrag(ev, o.drag, node));
            if (!o || o.size !== 'big') hoverInspect(node, () => [axiomCardEl(id, { size: 'big' }), axiomNote(id)], 'ax:' + id);
            return node;
        }

        function axiomNote(id) {
            const ax = (Rift.data.axioms || {})[id] || {};
            const on = E.activeAxioms(state).some(a => a.id === id);
            return el('div.b-notes', {}, [
                el('div.b-note-line.b-ability', {}, [el('b', { text: ax.name + ': ' }), ax.text]),
                ax.clearRules
                    ? el('div.b-note-line', {}, [el('b', { text: 'Your own card: ' }), 'every rule goes back to normal for BOTH players. Only you have it. It never goes into the shared deck.'])
                    : isBasic(ax)
                    ? el('div.b-note-line', {}, [el('b', { text: 'Back to normal: ' + (ax.category || 'rule') + '. ' }), 'It puts the basic ' + (ax.category || '') + ' rule back for BOTH players.'])
                    : el('div.b-note-line', {}, [el('b', { text: 'Rule card (' + (ax.category || 'rule') + '): ' }), on
                        ? 'active now for BOTH players.'
                        : 'play it to change this rule for BOTH players.']),
                ax.flavour ? el('div.b-note-line.b-flavour', { text: ax.flavour }) : null,
            ]);
        }

        function cardLabel(cid) {
            const c = state.cards[cid];
            const d = E.describe(state, cid);
            if (c.kind === 'tactic') return 'Tactic ' + d.name + ', cost ' + d.cost + ': ' + d.text
                + (d.colour ? ' ' + tacticKind(d) + '.' + (d.colourReady ? '' : ' ' + needsText(d.colour)) : '');
            return d.name + ', cost ' + d.cost + ', attack ' + d.attack + ', health ' + d.health + ' of ' + d.maxHealth
                + (d.keywords.length ? ', ' + d.keywords.join(', ') : '') + (d.sleeping ? ', asleep' : '') + (d.canAttack ? ', ready' : '');
        }

        function cardBack(axiom) {
            const id = axiom ? 'ui/axiom-back' : 'ui/card-back';
            const style = bg(id);
            return el('div.b-back' + (axiom ? '.axiom' : '') + (style ? '.art' : ''), style ? { style } : {}, style ? [] : [el('span', { text: axiom ? '⚖' : '⟁' })]);
        }

        // ---- inspect: a big readable card on hover, keyboard focus or long-press (touch) ----
        // The preview survives re-renders while the pointer stays on the same card in the same zone.
        const zoneOf = node => { const z = node && node.closest ? node.closest('[data-zone]') : null; return z ? z.dataset.zone : ''; };
        function hoverInspect(node, make, key) {
            if (key) inspectables[key] = { node, make };
            node.addEventListener('pointerenter', ev => {
                if (ui.drag || (ev.pointerType && ev.pointerType !== 'mouse')) return;
                // Pointing at a target with an attacker chosen shows the fight preview instead.
                if (ui.sel && ui.sel.kind === 'board' && node.classList.contains('valid')) return;
                // Right after a drag the mouse often rests on a card: wait until it moves.
                if (ui.hoverBlock) return;
                waitInspect(node, make, key);
            });
            node.addEventListener('pointerleave', ev => { if (!ev || !ev.pointerType || ev.pointerType === 'mouse') hideInspect(); });
            node.addEventListener('focus', () => { let kb = true; try { kb = node.matches(':focus-visible'); } catch (e) { /* old browser */ } if (kb) showInspect(make(), node, key); });
            node.addEventListener('blur', () => hideInspect());
            // Touch and pen: press and hold to read the card. Releasing hides it and skips the click.
            node.addEventListener('pointerdown', ev => {
                if (!ev.pointerType || ev.pointerType === 'mouse') return;
                cancelLongPress();
                const lp = { id: ev.pointerId, x: ev.clientX, y: ev.clientY, shown: false };
                lp.timer = setTimeout(() => { if (!ui.drag || !ui.drag.active) { lp.shown = true; showInspect(make(), node, key); } }, 450);
                ui.longPress = lp;
            });
            node.addEventListener('pointerup', () => {
                const lp = ui.longPress;
                if (!lp) return;
                cancelLongPress();
                if (lp.shown) {
                    hideInspect();
                    ui.suppressClick = true;
                    setTimeout(() => { ui.suppressClick = false; }, 0);
                }
            });
        }
        // A resting mouse opens the preview after a short delay (quicker when one is already open).
        // While a card waits for its target, the big preview stays shut (it would hide the glowing
        // targets and the instruction); tiles in the side panel may still open it.
        const aiming = node => !!(ui.sel && (targetMap(ui.sel).size || ui.sel.kind === 'hand' || ui.sel.kind === 'axiom') && !(dom.side.contains && dom.side.contains(node)));
        function waitInspect(node, make, key) {
            clearTimeout(ui.inspectTimer);
            const showing = dom.inspect.classList.contains('show');
            ui.inspectTimer = setTimeout(() => {
                if (ui.drag || ui.hoverBlock || ui.confirm || aiming(node)) return;
                showInspect(make(), node, key);
            }, showing ? 120 : HOVER_DELAY);
        }
        function cancelLongPress() {
            if (ui.longPress) clearTimeout(ui.longPress.timer);
            ui.longPress = null;
        }
        function showInspect(content, anchor, key) {
            if (ui.drag && ui.drag.active) return;
            clearTimeout(ui.inspectTimer);
            dom.inspect.innerHTML = '';
            [].concat(content).forEach(n => { if (n) dom.inspect.appendChild(n); });
            dom.inspect.classList.add('show');
            ui.inspect = { key: key || null, zone: zoneOf(anchor), anchor };
            placeInspect(anchor);
        }
        // Over the side panel (Rules now and the log), level with the card where it fits, so it
        // never covers the centre lane, the instruction bar or End turn. Without a side panel
        // (narrow screens) it goes to the far edge of the table, in the card's half.
        function placeInspect(anchor) {
            if (!anchor || !anchor.getBoundingClientRect || !screen.getBoundingClientRect) return;
            const box = screen.getBoundingClientRect();
            const a = anchor.getBoundingClientRect();
            const p = dom.inspect.getBoundingClientRect();
            if (!p.width || !box.width) return;
            // Right beside the card (like a magnifier): to its right when there is room, else to its
            // left; level with it, kept inside the screen. A tile in the side panel opens to its left.
            const m = 6, gap = 10;
            const ax = a.left - box.left, cy = a.top + a.height / 2 - box.top;
            const inSide = dom.side.contains && dom.side.contains(anchor);
            const right = ax + a.width + gap, left = ax - gap - p.width;
            const arenaRight = dom.arena.getBoundingClientRect().right - box.left;
            let x = !inSide && right + p.width <= arenaRight - m ? right : left >= m ? left : right;
            let y = cy - p.height / 2;
            x = Math.max(m, Math.min(box.width - p.width - m, x));
            y = Math.max(m, Math.min(box.height - p.height - m, y));
            dom.inspect.style.left = Math.round(x) + 'px';
            dom.inspect.style.top = Math.round(y) + 'px';
        }
        function hideInspect(keep) {
            clearTimeout(ui.inspectTimer);
            dom.inspect.classList.remove('show');
            if (!keep) ui.inspect = null;
        }
        function restoreInspect() {
            const was = ui.inspect;
            if (!was || !was.key || (ui.drag && ui.drag.active)) return;
            const it = inspectables[was.key];
            if (it && zoneOf(it.node) === was.zone && !aiming(it.node)) showInspect(it.make(), it.node, was.key);
            else ui.inspect = null;
        }

        // ---- picture buttons and their tooltip ----
        // One floating bubble (name in bold + one detail line): after TIP_DELAY under a resting mouse,
        // at once on keyboard focus, after a touch long-press (then it stays until the next tap).
        // It hides on leave, blur, click and Escape, and sits above the button (below when the gold
        // pointer is above it), so it never covers the button itself.
        function ctrlIcon(art, svgText, cls) {
            const style = art ? bg(art) : null;
            return el('span.b-ctrl-icon' + (cls ? '.' + cls : '') + (style ? '.art' : ''), style ? { style, 'aria-hidden': 'true' } : { html: svgText, 'aria-hidden': 'true' });
        }
        // o: { key, name, detail, art, svg, icon, badge, label, onclick, off, extra }
        function iconButton(cls, o) {
            const b = el('button.b-ibtn' + (cls || '') + (o.off ? '.off' : ''), Object.assign({
                type: 'button', 'aria-label': o.label || o.name, 'aria-disabled': o.off ? 'true' : null,
                onclick: ev => { if (ui.tipSuppress) return; hideTip(); if (o.onclick) o.onclick(ev, b); },
            }, o.extra || {}), [
                o.icon || ctrlIcon(o.art, o.svg),
                o.badge != null && o.badge !== '' ? el('span.b-ibtn-badge' + (o.badgeClass ? '.' + o.badgeClass : ''), { text: String(o.badge), 'aria-hidden': 'true' }) : null,
            ]);
            tipFor(b, o.key, o.name, o.detail);
            return b;
        }
        function tipFor(node, key, tipName, detail) {
            node.dataset.tip = tipName;
            node.dataset.tipKey = key;
            node.dataset.tipDetail = detail || '';
            if (node.title) node.title = '';
            tipNodes[key] = node;
            node.addEventListener('pointerenter', ev => {
                if ((ev.pointerType && ev.pointerType !== 'mouse') || (ui.drag && ui.drag.active)) return;
                clearTimeout(ui.tipTimer);
                const wait = ui.tip ? 60 : TIP_DELAY;
                ui.tipTimer = setTimeout(() => showTip(screen.contains(node) ? node : tipNodes[key]), wait);
            });
            node.addEventListener('pointerleave', ev => { if (!ev || !ev.pointerType || ev.pointerType === 'mouse') hideTip(); });
            // Keyboard focus shows it at once; focus from a mouse press does not.
            node.addEventListener('focus', () => { if (!ui.tipPress) showTip(node); });
            node.addEventListener('blur', () => { if (ui.tip && ui.tip.node === node) hideTip(); });
            node.addEventListener('pointerdown', ev => {
                ui.tipPress = true;
                setTimeout(() => { ui.tipPress = false; }, 0);
                if (!ev.pointerType || ev.pointerType === 'mouse') { hideTip(); return; }
                cancelTipPress();
                const lp = { id: ev.pointerId, x: ev.clientX, y: ev.clientY, shown: false };
                lp.timer = setTimeout(() => { lp.shown = true; showTip(node, true); }, TIP_PRESS);
                ui.tipLP = lp;
            });
            node.addEventListener('pointerup', () => {
                const lp = ui.tipLP;
                if (!lp) return;
                cancelTipPress();
                // A long-press only reads the name: the button is not pressed.
                if (lp.shown) { ui.tipSuppress = true; setTimeout(() => { ui.tipSuppress = false; }, 0); }
            });
        }
        function cancelTipPress() {
            if (ui.tipLP) clearTimeout(ui.tipLP.timer);
            ui.tipLP = null;
        }
        function showTip(node, sticky) {
            clearTimeout(ui.tipTimer);
            if (!node || !node.dataset || !node.dataset.tip || !screen.contains(node) || ui.confirm || (ui.drag && ui.drag.active)) return;
            if (ui.tip && ui.tip.node !== node) unlinkTip(ui.tip.node);
            dom.tip.innerHTML = '';
            put(dom.tip, el('strong.b-tip-name', { text: node.dataset.tip }),
                node.dataset.tipDetail ? el('span.b-tip-detail', { text: node.dataset.tipDetail }) : null);
            node.setAttribute('aria-describedby', tipId);
            dom.tip.setAttribute('aria-hidden', 'false');
            dom.tip.classList.add('show');
            ui.tip = { node, key: node.dataset.tipKey, sticky: !!sticky || !!(ui.tip && ui.tip.sticky && ui.tip.key === node.dataset.tipKey) };
            hideInspect();
            placeTip(node);
        }
        function unlinkTip(node) { if (node && node.removeAttribute) node.removeAttribute('aria-describedby'); }
        function hideTip() {
            clearTimeout(ui.tipTimer);
            cancelTipPress();
            if (!ui.tip) return;
            unlinkTip(ui.tip.node);
            ui.tip = null;
            dom.tip.classList.remove('show');
            dom.tip.setAttribute('aria-hidden', 'true');
        }
        // Above the button, centred and kept inside the screen; below it when there is no room above
        // or when the gold pointer (guide mode) sits above it.
        function placeTip(node) {
            if (!node.getBoundingClientRect || !screen.getBoundingClientRect) return;
            const box = screen.getBoundingClientRect();
            const a = node.getBoundingClientRect();
            const t = dom.tip.getBoundingClientRect();
            if (!box.width || !t.width) return;
            const m = 6, gap = 8;
            const x = Math.max(m, Math.min(box.width - t.width - m, a.left + a.width / 2 - box.left - t.width / 2));
            const above = a.top - box.top - gap - t.height;
            const below = a.bottom - box.top + gap;
            const fitsBelow = below + t.height <= box.height - m;
            const pointer = node.classList.contains('guide-focus');
            const y = (above < m || pointer) && fitsBelow ? below : Math.max(m, above);
            dom.tip.style.left = Math.round(x) + 'px';
            dom.tip.style.top = Math.round(y) + 'px';
        }
        // After a re-render the same button (by key) takes over a shown tooltip, with fresh text.
        function restoreTip() {
            const was = ui.tip;
            if (!was) return;
            const n = screen.contains(was.node) ? was.node : tipNodes[was.key];
            if (n && screen.contains(n)) showTip(n, was.sticky);
            else hideTip();
        }

        // ---- heroes ----
        function heroEl(pi, valid, L) {
            const P = state.players[pi];
            const r = E.rules(state);
            const speaker = opp.speaker && (Rift.data.speakers || {})[opp.speaker];
            const art = pi === ME ? me.art : (opp.art || (speaker && speaker.art) || null);
            const portrait = art ? Rift.Assets.img(art, { label: P.name, alt: '' })
                : Rift.Assets.img(pi === ME ? 'avatar/unknown' : 'npc/rival', { label: pi === ME ? 'You' : P.name, alt: '' });
            const frame = bg('ui/hero-frame');
            const heart = bg('ui/heart-full');
            const active = state.active === pi && E.winner(state) == null;
            const id = 'h' + pi;
            const isTarget = valid.has(id);
            const full = pi === ME ? 'You' : oppFull;
            const node = el((isTarget ? 'button' : 'div') + '.b-hero' + (active ? '.active' : '') + (isTarget ? '.valid' : ''), {
                type: isTarget ? 'button' : null,
                dataset: { target: id },
                title: full + ': ' + P.hearts + ' of ' + P.maxHearts + ' hearts',
                'aria-label': (pi === ME ? 'Your hero' : full) + ': ' + P.hearts + ' hearts',
            }, [
                el('div.b-portrait', {}, [portrait]),
                el('div.b-hero-frame' + (frame ? '.art' : ''), frame ? { style: frame } : {}),
                el('div.b-hero-name', { text: pi === ME ? 'You' : P.name, title: full }),
                el('div.b-hearts' + (heart ? '.art' : ''), { style: heart, title: P.hearts + ' of ' + P.maxHearts + ' hearts' }, [el('span', { text: String(P.hearts) })]),
                r.reverseHearts ? el('div.b-reverse', { text: '0 hearts = WIN' }) : null,
                pi === ME ? dangerEl(P, r) : null,
            ]);
            if (isTarget) node.addEventListener('click', () => { if (!ui.suppressClick) clickTarget(id, L); });
            else if (pi === OPP) node.addEventListener('click', () => { if (!ui.suppressClick && ui.sel && ui.sel.kind === 'board') setNote(badTargetNote(ui.sel.cid, id)); });
            nodes[id] = node;
            return node;
        }

        // "Danger": the enemy creatures together could take all my hearts on their next turn
        // (Guard and the rules aside). Only under the normal victory rule.
        function dangerEl(P, r) {
            if (r.reverseHearts || E.winner(state) != null) return null;
            const per = cid => { const a = Math.max(0, E.describe(state, cid).attack); return r.heroDamageCap != null ? Math.min(a, r.heroDamageCap) : a; };
            const hits = [];
            state.players[OPP].board.forEach(cid => { for (let k = 0; k < (r.attacksPerCreature || 1); k++) hits.push(per(cid)); });
            hits.sort((a, b) => b - a);
            const total = hits.slice(0, r.attackLimit === Infinity ? hits.length : r.attackLimit).reduce((n, x) => n + x, 0);
            if (!total || total < P.hearts) return null;
            return el('div.b-danger', { title: 'Danger: ' + oppName + '\'s creatures have ' + total + ' attack together. You have ' + P.hearts + ' hearts.' }, [
                has('ui/danger') ? icon('ui/danger', '', 'b-danger-icon') : null,
                el('strong', { text: (has('ui/danger') ? '' : '⚠ ') + 'Danger' }), el('span', { text: 'Their attack: ' + total }),
            ]);
        }

        // ---- hero power: a round button by the hero (design/AVATARS.md 1.6) ----
        const powerDef = id => (Rift.data.powers || {})[id] || { name: id, text: '' };
        const powerName = id => powerDef(id).name;
        function powerIcon(id, cls) {
            if (Rift.PowerView) return Rift.PowerView.icon(id, cls);
            return el('span.pw-icon.pw-glyph' + (cls ? '.' + cls : ''), { text: '✷', 'aria-hidden': 'true' });
        }
        // The counter counts its owner's turns: 'on your next turn', 'in 3 of their turns'.
        const turnsWords = (n, pi) => (n === 1 ? 'on ' + (pi === OPP ? 'their' : 'your') + ' next turn' : 'in ' + n + ' of ' + (pi === OPP ? 'their' : 'your') + ' turns');
        // Used this turn: the counter still holds its full value (recharge + 1) during its owner's turn.
        const powerUsedNow = (pi, st) => state.active === pi && !st.ready && st.turnsLeft === st.recharge + 1 && E.winner(state) == null;
        // Why my power can't be used now ('' when it can).
        function powerWhy(st, L) {
            if (L.some(a => a.type === 'power')) return '';
            if (ui.ended || E.winner(state) != null) return 'The battle is over.';
            if (powerUsedNow(ME, st)) return 'You used it this turn. It is ready again ' + turnsWords(st.turnsLeft, ME) + '.';
            if (!st.ready) return 'It is resting: ready ' + turnsWords(st.turnsLeft, ME) + '.';
            if (guide && !ui.busy) return 'Not now. Follow the gold pointer.';
            if (ui.busy || decider() !== ME) return 'Wait for your turn.';
            return st.note || 'Not now.';
        }
        // The power big (an opponent's power as it is used, the Recent plays preview).
        function powerBig(id, pi) {
            const st = E.powerStatus(state, pi);
            const x = st && st.id === id ? st : Object.assign({ cost: powerDef(id).cost, heartCost: 0, recharge: powerDef(id).recharge }, Rift.PowerView ? Rift.PowerView.numbers(id) : {}, { name: powerName(id), text: powerDef(id).text });
            const cost = x.heartCost ? x.heartCost + ' heart' + (x.heartCost === 1 ? '' : 's') : x.cost ? x.cost + ' energy' : 'free';
            return el('div.b-power-big' + (pi === ME ? '.mine' : '.theirs'), {}, [
                el('div.b-power-big-ring', {}, [powerIcon(id)]),
                el('div.b-power-big-who', { text: (pi === ME ? 'Your' : oppName + '\'s') + ' power' }),
                el('strong.b-power-big-name', { text: x.name }),
                el('div.b-power-big-text', { text: x.text }),
                el('div.b-power-big-stats', { text: 'Cost: ' + cost + ' · ' + (x.recharge ? 'rests ' + x.recharge + ' turn' + (x.recharge === 1 ? '' : 's') + ' after use' : 'ready every turn') }),
            ]);
        }
        function powerEl(pi, L) {
            const st = E.powerStatus ? E.powerStatus(state, pi) : null;
            if (!st) return null;
            const mine = pi === ME;
            const can = mine && L.some(a => a.type === 'power');
            const used = powerUsedNow(pi, st);
            const resting = !st.ready && !used;
            const poor = st.why === 'energy' || st.why === 'hearts';
            const idle = mine && !can && st.ready && !poor && (st.why === 'useless' || st.why === 'target');
            const chosen = mine && ui.sel && ui.sel.kind === 'power';
            const heart = st.heartCost > 0;
            const costArt = bg(heart ? 'ui/heart-full' : 'ui/stat-cost');
            const costText = heart ? st.heartCost + ' heart' + (st.heartCost === 1 ? '' : 's') : st.cost ? st.cost + ' energy' : 'free';
            const why = mine ? powerWhy(st, L) : '';
            const stateLine = mine
                ? (can ? (st.target ? 'Click it, then click a glowing target.' : 'Click to use it.') : 'Not now: ' + why)
                : used ? 'Used this turn.' : resting ? 'Resting: ready ' + turnsWords(st.turnsLeft, pi) + '.' : 'Ready.';
            const rest = st.recharge ? 'Rests ' + st.recharge + ' turn' + (st.recharge === 1 ? '' : 's') + ' after use.' : 'Ready every turn.';
            const detail = st.text + ' Cost: ' + costText + '. ' + rest + ' Not a card play. ' + stateLine;
            const node = el((mine ? 'button' : 'div') + '.b-power' + (mine ? '.mine' : '.theirs') + (can ? '.ready' : '') + (used ? '.used' : '') + (resting ? '.resting' : '')
                + (poor ? '.poor' : '') + (idle ? '.idle' : '') + (chosen ? '.selected' : ''), {
                type: mine ? 'button' : null, tabindex: mine ? null : 0, dataset: { power: st.id },
                'aria-disabled': mine && !can ? 'true' : null,
                'aria-label': (mine ? 'Your power: ' : oppName + '\'s power: ') + st.name + ', ' + costText + '. ' + (mine ? (can ? 'Ready.' : 'Not now: ' + why) : stateLine),
            }, [
                powerIcon(st.id, 'b-pw-pic'),
                el('span.b-pw-cost' + (heart ? '.heart' : '') + (costArt ? '.art' : ''), { style: costArt, text: String(heart ? st.heartCost : st.cost), 'aria-hidden': 'true' }),
                resting ? el('span.b-pw-wait', { text: String(st.turnsLeft), 'aria-hidden': 'true' }) : null,
                used ? el('span.b-pw-used', { text: 'Used', 'aria-hidden': 'true' }) : null,
            ]);
            if (mine) node.addEventListener('click', () => { if (!ui.tipSuppress && !ui.suppressClick) { hideTip(); clickPower(L); } });
            tipFor(node, 'power:' + pi, (mine ? 'Your power: ' : oppName + '\'s power: ') + st.name, detail);
            nodes['pw' + pi] = node;
            return node;
        }
        function clickPower(L) {
            // The lesson's "Your power" step: the click is the step, the power is not used.
            if (guide && step() && step().info) { infoDone(); return; }
            const acts = L.filter(a => a.type === 'power');
            if (!acts.length) { ui.sel = null; setNote(powerWhy(E.powerStatus(state, ME), L)); return; }
            if (acts.length === 1 && !acts[0].target) { act(acts[0]); return; }
            ui.sel = ui.sel && ui.sel.kind === 'power' ? null : { kind: 'power' };
            render();
            // Keyboard: the button is drawn anew, so give it the focus back (Tab then reaches the targets).
            if (nodes.pw0 && nodes.pw0.focus) try { nodes.pw0.focus(); } catch (e) { /* ignore */ }
        }
        // Worth a look before End turn: a usable power, except Brainstorm with no card to play.
        function powerWorth(L) {
            if (!L.some(a => a.type === 'power')) return false;
            const st = E.powerStatus(state, ME);
            if (!st || st.id !== 'brainstorm') return true;
            const P = state.players[ME];
            const energy = P.energy - st.cost + (st.tweaks.includes('broader') ? 1 : 0);
            return P.hand.some(cid => E.playCost(state, cid) <= energy) || P.axHand.some(id => axiomChanges(id) && E.axiomCost(state, id) <= energy);
        }

        // "grows by 1 each turn (up to 10)", "stays the same", "shrinks by 1 each turn (never below 1)".
        const growthWords = g => (g > 0 ? 'grows by ' + g + ' each turn (up to ' + state.options.energyCap + ')' : g === 0 ? 'stays the same each turn' : 'shrinks by ' + -g + ' each turn (never below 1)');
        // Card plays left this turn (the Plays rule): a row of card icons, used ones dim.
        function playsEl() {
            const lim = E.playLimit(state, ME), left = E.playsLeft(state, ME);
            const mine = state.active === ME;
            const shown = lim === Infinity ? null : lim;
            return el('div.b-plays' + (mine && !left ? '.none' : ''), { title: lim === Infinity ? 'Card plays: no limit this turn.' : 'Card plays: ' + (mine ? left : lim) + ' of ' + lim + ' left this turn. Creatures, tactics and rule cards each use one.' }, [
                el('span.b-plays-label', { text: 'Plays' }),
                shown == null ? el('strong', { text: '∞' }) : el('span.b-plays-pips', {}, Array.from({ length: shown }, (x, i) => el('span.b-play-pip' + (!mine || i < left ? '.on' : '') + (has('ui/play-token') ? '.art' : ''), { style: bg('ui/play-token') }))),
            ]);
        }

        function energyEl(pi) {
            const P = state.players[pi];
            const cap = P.capacity + (P.consumables['extra-energy'] || 0);
            const total = Math.max(cap, P.energy);
            const crystals = [];
            for (let i = 0; i < total; i++) {
                const full = i < P.energy;
                const style = bg(full ? 'ui/energy-full' : 'ui/energy-empty');
                crystals.push(el('span.b-crystal' + (full ? '.full' : '') + (style ? '.art' : ''), style ? { style } : {}));
            }
            const node = el('div.b-energy' + (pi === OPP ? '.small' : '') + (pi === ME && !P.energy && decider() === ME ? '.empty' : ''), { tabindex: pi === ME ? 0 : null }, [
                el('div.b-crystals', {}, crystals),
                el('div.b-energy-num', {}, [el('strong', { text: String(P.energy) }), el('span', { text: '/' + cap })]),
                el('div.b-energy-label', { text: 'Energy' }),
                pi === ME && E.playsLeft ? playsEl() : null,
                // Night Sight's tax: the next card(s) this player plays cost 1 more.
                P.tax > 0 ? el('div.b-tax', { text: (P.tax === 1 ? 'Next card' : 'Next ' + P.tax + ' cards') + ' +1 ⚡' }) : null,
            ]);
            tipFor(node, 'energy:' + pi, (pi === ME ? 'Your energy: ' : oppName + '\'s energy: ') + P.energy + ' of ' + cap,
                'Cards cost energy (the blue number on each card). It refills every turn and ' + growthWords(E.rules(state).growth) + '. Attacking is free.'
                + (P.tax > 0 ? ' Night Sight: the next ' + (P.tax === 1 ? 'card' : P.tax + ' cards') + ' played cost' + (P.tax === 1 ? 's' : '') + ' 1 more.' : ''));
            return node;
        }

        function infoEl(pi) {
            const P = state.players[pi];
            return el('div.b-info', {}, [
                el('div', { text: 'Deck ' + P.deck.length }),
                el('div', { text: 'Hand ' + (P.hand.length + P.axHand.length) }),
                el('div', { text: 'Discard ' + P.discard.length }),
            ]);
        }

        // ---- rendering ----
        function render() {
            if (ui.ended && dom.overlay.classList.contains('show')) return;
            Object.keys(nodes).forEach(k => delete nodes[k]);
            Object.keys(inspectables).forEach(k => delete inspectables[k]);
            hideInspect(true);
            // The lane can move without changing size (the hand or a board row grows), which the
            // ResizeObserver misses: re-align the board picture after every render's layout.
            if (typeof requestAnimationFrame === 'function') requestAnimationFrame(alignBoard);
            [dom.myBoard, dom.oppBoard, dom.lane].forEach(n => { n.classList.remove('guide-ring'); n.classList.remove('guide-focus'); });
            const L = legal();
            ui.sparkFor = !guide && decider() === ME ? sparkHelp(L) : null;
            const tmap = targetMap(ui.sel, L);
            const valid = new Set(tmap.keys());
            const targeting = valid.size > 0;
            screen.classList.toggle('targeting', targeting);
            screen.classList.toggle('my-turn', decider() === ME && !ui.busy);
            screen.classList.toggle('reverse-goal', !!E.rules(state).reverseHearts);

            // opponent hand
            dom.oppHand.innerHTML = '';
            // Cards I know (Night Sight) lie face up, tagged "Seen"; only what the engine tells me.
            const knows = state.players[ME].knows;
            state.players[OPP].hand.forEach(cid => {
                if (!knows.includes(cid)) { dom.oppHand.appendChild(cardBack(false)); return; }
                const seen = cardEl(cid, { size: 'mini', classes: ['revealed'] });
                seen.appendChild(el('span.b-seen-tag', { text: 'Seen', 'aria-hidden': 'true' }));
                seen.setAttribute('aria-label', 'Seen in ' + oppName + '\'s hand: ' + seen.getAttribute('aria-label'));
                dom.oppHand.appendChild(seen);
            });
            state.players[OPP].axHand.forEach(() => dom.oppHand.appendChild(cardBack(true)));

            // hero rows: hero, power and pile counts on the left, energy on the right
            dom.oppLeft.innerHTML = '';
            const oppPower = powerEl(OPP, L);
            put(dom.oppLeft, heroEl(OPP, valid, L), oppPower ? el('div.b-left.b-left-opp', {}, [oppPower, infoEl(OPP)]) : infoEl(OPP));
            dom.oppRight.innerHTML = '';
            put(dom.oppRight, energyEl(OPP));
            const P = state.players[ME];
            const spark = L.find(a => a.type === 'spark');
            const sparkStyle = bg('ui/spark');
            dom.myLeft.innerHTML = '';
            put(dom.myLeft, heroEl(ME, valid, L), el('div.b-left', {}, [
                powerEl(ME, L),
                infoEl(ME),
                P.spark ? iconButton('.b-spark' + (sparkStyle ? '.art' : '') + (ui.sparkFor ? '.glow' : ''), {
                    key: 'spark', name: 'Spark', label: 'Spark: +1 energy',
                    detail: 'Once per match: +1 energy this turn (you went second).',
                    icon: el('span.b-spark-icon', { style: sparkStyle, text: sparkStyle ? '' : '✦', 'aria-hidden': 'true' }), badge: '+1',
                    extra: { disabled: !spark }, onclick: () => { if (spark) act(spark); },
                }) : null,
            ]));
            dom.myRight.innerHTML = '';
            put(dom.myRight, bagEl(L), energyEl(ME));

            // boards
            const attackers = new Set(L.filter(a => a.type === 'attack' || a.type === 'activate').map(a => a.cid));
            [[OPP, dom.oppBoard], [ME, dom.myBoard]].forEach(([pi, box]) => {
                box.innerHTML = '';
                const list = state.players[pi].board;
                if (!list.length && !(pi === ME && ui.sel && ui.sel.pending)) box.appendChild(el('div.b-empty', { text: pi === ME ? 'Drag a creature here to play it.' : oppName + '\'s side is empty.' }));
                // The creature dropped here that still waits for its Entrance target: a faint copy.
                if (pi === ME && ui.sel && ui.sel.pending && state.players[ME].hand.includes(ui.sel.cid)) {
                    const ghost = cardEl(ui.sel.cid, { size: 'board', classes: ['pending'], unregistered: true });
                    ghost.appendChild(el('span.b-pending-tag', { text: 'Choose a target' }));
                    box.appendChild(ghost);
                }
                list.forEach(cid => {
                    const d = E.describe(state, cid);
                    const classes = [];
                    if (d.keywords.includes('guard')) classes.push('guard');
                    if (d.damaged) classes.push('damaged');
                    if (pi === ME && attackers.has(cid)) classes.push('ready');
                    if (pi === ME && decider() === ME && (d.attacks || d.activated) && !attackers.has(cid)) classes.push('spent');
                    if (ui.sel && ui.sel.cid === cid) classes.push('selected');
                    if (valid.has(cid)) classes.push('valid');
                    else if (targeting) classes.push('dim');
                    if (ui.preview && ui.preview.cid === cid) classes.push('attacking');
                    if (ui.preview && ui.preview.target === cid) classes.push('targeted');
                    const ready = pi === ME && attackers.has(cid);
                    const node = cardEl(cid, {
                        size: 'board', classes, target: true,
                        onclick: () => clickCard(cid, L),
                        drag: ready && L.some(a => a.type === 'attack' && a.cid === cid) ? { kind: 'board', cid } : pi === ME ? { kind: 'board', cid, blocked: true } : null,
                    });
                    // A word over a creature that can act now (the glow alone was easy to miss).
                    if (ready && !(d.attacks > 0) && !valid.size) {
                        const canHit = L.some(a => a.type === 'attack' && a.cid === cid);
                        node.appendChild(el('span.b-ready-tag', { text: canHit ? 'Ready' : 'Ability' }));
                    }
                    box.appendChild(node);
                });
            });

            // my hand (cards that stay slide from their old places, so the card you see is the card you grab)
            const oldHand = handPositions();
            dom.myHand.innerHTML = '';
            const plays = new Set(L.filter(a => a.type === 'play').map(a => a.cid));
            const axPlays = new Set(L.filter(a => a.type === 'axiom').map(a => a.choice));
            const handItems = P.hand.length + P.axHand.length;
            dom.myHand.style.setProperty('--n', String(Math.max(1, handItems)));
            let i = 0;
            // In my main phase, a card that can't be played right now is dimmed.
            const myMain = decider() === ME && state.phase === 'main' && !ui.busy && !ui.ended;
            // Hand limit rule: the oldest cards over the limit go at the end of my turn.
            const cap = E.rules(state).handCap;
            const over = cap != null && decider() === ME ? Math.max(0, P.hand.length + P.axHand.length - cap) : 0;
            const doomed = new Set(P.hand.slice(0, over));
            P.hand.forEach(cid => {
                const classes = [];
                if (plays.has(cid)) classes.push('playable');
                else if (myMain) classes.push('unplayable');
                if (ui.sel && ui.sel.kind === 'hand' && ui.sel.cid === cid) classes.push('selected');
                if (valid.has(cid)) classes.push('valid');
                const node = cardEl(cid, { size: 'hand', classes, onclick: () => clickHand(cid, L), drag: plays.has(cid) ? { kind: 'hand', cid } : { kind: 'hand', cid, blocked: true } });
                if (doomed.has(cid)) node.appendChild(el('span.b-hand-tag.warn', { text: 'Lost at End turn' }));
                fan(node, i++, handItems);
                dom.myHand.appendChild(node);
            });
            P.axHand.forEach(id => {
                const classes = [];
                if (axPlays.has(id)) classes.push('playable');
                else if (myMain) classes.push('unplayable');
                if (ui.sel && ui.sel.kind === 'axiom' && ui.sel.id === id) classes.push('selected');
                const node = axiomCardEl(id, { size: 'hand', classes, onclick: () => clickAxiom(id, L), drag: axPlays.has(id) ? { kind: 'axiom', id } : { kind: 'axiom', id, blocked: true } });
                // A rule card that would change nothing (that rule is already on) says so on the card.
                if (!axiomChanges(id)) { node.appendChild(el('span.b-hand-tag', { text: (Rift.data.axioms[id] || {}).clearRules ? 'No rule to clear' : 'Already the rule' })); node.title = whyNotAxiomRule(id); }
                else {
                    const tlr = E.timeline(state)[0];
                    if (tlr && tlr.type === 'reset' && tlr.turns <= 2) node.appendChild(el('span.b-hand-tag.warn', { text: 'Reset in ' + tlr.turns + '!' }));
                }
                if (!nodes['ax:' + id]) nodes['ax:' + id] = node;
                fan(node, i++, handItems);
                dom.myHand.appendChild(node);
            });
            if (!handItems) dom.myHand.appendChild(el('div.b-empty', { text: 'Your hand is empty.' }));
            settleHand(oldHand);

            // Click-click: pointing at (or focusing) a glowing target shows the predicted fight.
            if (ui.sel && ui.sel.kind === 'board') {
                const att = ui.sel.cid;
                valid.forEach(t => {
                    const n = nodes[t];
                    if (!n || !n.addEventListener) return;
                    const show = () => { clearPredict(); showPredict(att, t); };
                    n.addEventListener('pointerenter', show);
                    n.addEventListener('focus', show);
                    n.addEventListener('pointerleave', clearPredict);
                    n.addEventListener('blur', clearPredict);
                });
            }

            renderLane();
            renderPrompt();
            renderEnd(L);
            renderDraw(L);
            renderChoice(L);
            renderRules();
            renderRecent();
            if (guide) renderCoach();
            renderGuidePointer();
            drawArrowForPreview();
            restoreInspect();
            restoreTip();
            turnBanner();
        }

        // Hand card positions by key (cid, or axiom id plus copy number), for the settle animation.
        function handPositions() {
            const out = {};
            const seen = {};
            Array.from(dom.myHand.children || []).forEach(n => {
                if (!n.dataset || !n.getBoundingClientRect) return;
                const k = n.dataset.cid || 'ax:' + n.dataset.axiom;
                seen[k] = (seen[k] || 0) + 1;
                out[k + '#' + seen[k]] = n.getBoundingClientRect().left;
            });
            return out;
        }
        // Cards that moved slide quickly into their new places (a short settle; none under calm motion).
        function settleHand(old) {
            if (calmMotion() || !Object.keys(old).length) return;
            const now = handPositions();
            const seen = {};
            Array.from(dom.myHand.children || []).forEach(n => {
                if (!n.dataset || !n.animate) return;
                const k = n.dataset.cid || 'ax:' + n.dataset.axiom;
                seen[k] = (seen[k] || 0) + 1;
                const key = k + '#' + seen[k];
                const dx = old[key] == null ? 0 : old[key] - now[key];
                if (Math.abs(dx) < 2) return;
                try { n.animate([{ translate: dx + 'px 0' }, { translate: '0 0' }], { duration: SETTLE, easing: 'ease-out' }); } catch (e) { /* no WAAPI */ }
            });
        }

        // A gentle fan: outer cards tilt a little and sit a few pixels lower. Cards stay fully visible.
        function fan(node, i, n) {
            const mid = (n - 1) / 2;
            const off = i - mid;
            node.style.setProperty('--rot', (n > 1 ? off * Math.min(3, 15 / n) : 0).toFixed(2) + 'deg');
            node.style.setProperty('--lift', Math.min(6, Math.round(off * off * Math.min(1.2, 6 / n))) + 'px');
        }

        // "Your turn" fades in and out when a new turn of mine starts (no movement: calm-safe).
        function turnBanner() {
            const mine = state.active === ME && state.phase === 'draw' && decider() === ME && E.winner(state) == null && !ui.ended;
            const theirs = state.active === OPP && state.phase === 'draw' && E.winner(state) == null && !ui.ended;
            if ((!mine && !theirs) || ui.bannerTurn === state.turn) return;
            ui.bannerTurn = state.turn;
            dom.banner.innerHTML = '';
            dom.banner.classList.toggle('theirs', theirs);
            if (theirs) {
                // A rule card shown big (a reveal) already covers the top of the table: no banner then.
                if (ui.holding) return;
                put(dom.banner, el('div.b-banner-title', { text: oppName + '\'s turn' }), el('div.b-banner-sub', { text: 'Watch what ' + oppName + ' does.' }));
                dom.banner.classList.remove('show');
                void dom.banner.offsetWidth;
                dom.banner.classList.add('show');
                clearTimeout(ui.bannerTimer);
                ui.bannerTimer = setTimeout(() => dom.banner.classList.remove('show'), 1900);
                return;
            }
            // Guide mode: Granny's script may draw for you (a reply), so the line follows the lesson.
            let sub = 'First, choose your draw.';
            if (guide) {
                const queued = ui.busy && ui.queue.length;
                const next = ui.busy ? guide.steps[ui.step + 1] : step();
                sub = queued || !next || next.expect.type !== 'draw' ? '' : 'Do this: ' + next.label + '.';
            }
            put(dom.banner, el('div.b-banner-title', { text: 'Your turn' }), sub ? el('div.b-banner-sub', { text: sub }) : null);
            dom.banner.classList.remove('show');
            void dom.banner.offsetWidth;
            dom.banner.classList.add('show');
            clearTimeout(ui.bannerTimer);
            ui.bannerTimer = setTimeout(() => dom.banner.classList.remove('show'), 1900);
        }

        // The lane: the Fate track across the top; below it the instruction (or the draw choice),
        // the shared axiom deck, and End turn on the right.
        function renderLane() {
            dom.lane.innerHTML = '';
            dom.fate = el('div.b-fate', { role: 'group', 'aria-label': 'Fate track' });
            paintFate(0);
            const deckN = state.axioms.deck.length;
            const axdeck = el('div.b-axdeck', { tabindex: 0, 'aria-label': 'Shared rule deck: ' + deckN + ' rule cards' }, [cardBack(true), el('span', { text: String(deckN) })]);
            tipFor(axdeck, 'axdeck', 'Shared rule deck', deckN + ' rule cards. Both players draw from it, and the Fate track turns its top card over.');
            put(dom.lane, dom.fate, dom.prompt = el('div.b-prompt', { role: 'status', 'aria-live': 'polite' }), el('div.b-lane-right', {}, [axdeck]), dom.draw, dom.end);
        }

        // Fate events in the log, by turn: the rules that turned over or were played, resets and
        // time draws. k = turns before the current one (0 = this turn, -1 = the turn before).
        function fateHistory() {
            let count = 0, between = false;
            const out = [];
            E.fullLog(state).forEach(ev => {
                if (ev.t === 'turn') { count += 1; between = false; return; }
                if (ev.t === 'turn-end') { between = true; return; }
                const idx = between ? count + 1 : count;
                if (ev.t === 'reset') out.push({ idx, kind: 'reset' });
                else if (ev.t === 'axiom') out.push({ idx, kind: ev.player == null ? 'flip' : 'rule', id: ev.id, by: ev.player });
                else if (ev.t === 'time') out.push({ idx, kind: /closer/.test(ev.text) ? 'forward' : 'rewind', by: ev.player });
            });
            return out.map(x => Object.assign(x, { k: x.idx - count }));
        }

        // The Fate track, a reel: NOW (the hourglass) is fixed in the middle; three past turns on the
        // left, three coming turns on the right, the next events on their spaces (a further one waits at
        // the right edge). When turns pass, the reel slides left under NOW (a fade under calm motion). Each space is tinted by whose turn it
        // is. shift (−1 / +1) previews a Fate sooner / later draw: the next event appears where it
        // would land. Every event (past or coming) shows its card on hover, focus or tap.
        const FATE_PAST = 3, FATE_AHEAD = 3;
        function paintFate(shift) {
            const box = dom.fate;
            if (!box) return;
            box.innerHTML = '';
            const tl = E.timeline(state);
            if (!tl.length) { put(box, el('div.b-fate-none', { text: 'No Fate track in this match.' })); return; }
            const AX = Rift.data.axioms || {};
            const owner = k => ((state.active + k) % 2 + 2) % 2;
            const hist = fateHistory();
            const top = state.axioms.deck[0];
            const next = tl[0];
            const moved = shift ? Math.max(0, Math.min(state.options.fateMax, next.turns + shift)) : null;
            const spaces = [];
            for (let k = -FATE_PAST; k <= FATE_AHEAD; k++) {
                const who = owner(k);
                const kids = [];
                // Past events (and those of this turn) as small markers.
                hist.filter(h => h.k === k && k >= -FATE_PAST).forEach(h => kids.push(pastMarker(h, AX)));
                // Coming events on their own space (further ones wait in the chip beyond the reel).
                tl.forEach((ev, i) => {
                    if (ev.turns !== k || (shift && i === 0)) return;
                    kids.push(eventMarker(ev, i, top, false));
                });
                if (shift && moved === k) kids.push(eventMarker(Object.assign({}, next, { turns: moved }), 0, top, false, true));
                const cls = (k < 0 ? '.past' : k === 0 ? '.now' : '.ahead') + (who === ME ? '.mine' : '.theirs');
                const space = el('div.b-fs' + cls, { dataset: { k: String(k) } }, kids);
                // The game's own tooltip (no native title): whose turn this space is.
                tipFor(space, 'fs:' + k, who === ME ? 'Your turn' : oppName + '\'s turn', k === 0 ? 'Now.' : k < 0 ? (-k) + ' turn' + (k === -1 ? '' : 's') + ' ago.' : 'In ' + k + ' turn' + (k === 1 ? '' : 's') + '.');
                spaces.push(space);
            }
            let reel = null;
            const turnsWord = n => n + ' turn' + (n === 1 ? '' : 's');
            const evName = ev => (ev.type === 'reset' ? 'All rules reset' : 'New rule' + (top && ev === next && AX[top] ? ': ' + ruleWords(AX[top]) + (E.axiomWouldChange && !E.axiomWouldChange(state, top) ? ' (no change)' : '') : ''));
            const anchored = state.fate.anchorTurn === state.turn;
            const kind = next.type === 'reset' ? 'Reset' : 'New rule';
            const summary = shift
                ? (moved === 0 ? (next.type === 'reset' ? 'Reset happens NOW' : 'New rule NOW') : (shift < 0 ? '⏩ ' : '⏪ ') + kind + ' in ' + turnsWord(moved))
                : (anchored ? '⚓ ' : '') + kind + ' in ' + turnsWord(next.turns);
            // The second line: what it will be, and whose turn it starts.
            const whose = owner(next.turns) === ME ? 'your turn' : 'their turn';
            const detail = (next.type === 'reset' ? 'All rules back to basic' : evName(next).replace(/^New rule: /, '').replace(/^New rule$/, 'The top rule card')) + ' · ' + whose;
            // Beyond the reel: the nearest event further than three turns away, with its count.
            const farIdx = tl.findIndex(ev => ev.turns > FATE_AHEAD);
            const farGhost = shift && moved > FATE_AHEAD;
            let farChip = null;
            if (farGhost) farChip = el('div.b-fate-far', {}, [el('span.b-far-arrow', { text: '››' }), eventMarker(Object.assign({}, next, { turns: moved }), 0, top, true, true)]);
            else if (farIdx >= 0 && !(shift && farIdx === 0)) farChip = el('div.b-fate-far', {}, [el('span.b-far-arrow', { text: '››' }), eventMarker(tl[farIdx], farIdx, top, true)]);
            // A card bent time (not a turn passing): the summary flashes so the change is seen.
            const sig = next.type + ':' + next.turns;
            const bent = !shift && ui.fateSig && ui.fateSig.turn === state.turn && ui.fateSig.sig !== sig;
            if (!shift) ui.fateSig = { turn: state.turn, sig };
            put(box,
                el('div.b-fate-label', {}, [el('strong', { text: 'Fate' }), el('span', { text: 'turns' })]),
                el('div.b-fate-track' + (has('ui/fate-track') ? '.art' : ''), {}, [
                    // Nine-slice: the end caps keep their shape, only the plain bar between them stretches.
                    el('div.b-fate-groove', { style: (u => (u ? { borderImageSource: 'url("' + u + '")' } : null))(artUrl('ui/fate-track')) }),
                    reel = el('div.b-fate-reel', {}, spaces),
                    el('div.b-fate-now', {}, [el('span.b-fs-now', { style: bg('ui/fate-marker'), text: has('ui/fate-marker') ? '' : '⧗' }), el('span.b-fate-now-tag', { text: 'NOW' })]),
                ]),
                farChip || el('div.b-fate-far.none'),
                el('div.b-fate-sum' + (shift ? '.preview' : '') + (bent ? '.bent' : ''), {}, [el('strong', { text: summary }),
                    el('span', { text: shift ? 'if you choose this draw' : detail, title: detail })]),
            );
            slideReel(reel, shift);
            tipFor(box.querySelector ? box.querySelector('.b-fate-label') || box : box, 'fate', 'Fate track', 'Each End turn moves every event 1 space closer to NOW (the hourglass). At NOW it happens: a free new rule, or a reset to the basic rules.');
        }
        // Turns passed since the last paint: the reel slides that many spaces left (at most 3), one space
        // at a time with a short stop on each ("tick, tick"), slow enough to follow. The screen repaints the
        // reel on every move, so the slide is kept in ui.fateSlide and picked up again by each new reel
        // (before, a repaint mid-slide threw it away and the reel seemed to jump). Calm motion steps
        // space by space without sliding.
        const FATE_STEP = 700, FATE_HOLD = 220;
        function slideReel(reel, shift) {
            const was = ui.fateTurn;
            if (!shift) ui.fateTurn = state.turn;
            if (!reel || shift || !reel.animate) return;
            const now = root.performance && root.performance.now ? root.performance.now() : Date.now();
            const run = ui.fateSlide && now - ui.fateSlide.start < ui.fateSlide.d * FATE_STEP ? ui.fateSlide : null;
            if (was != null && state.turn > was) {
                // Spaces still to go in a slide that is under way are added to the new one.
                const left = run ? run.d - Math.floor((now - run.start) / FATE_STEP) : 0;
                ui.fateSlide = { d: Math.min(3, state.turn - was + left), start: now };
            } else if (!run) { ui.fateSlide = null; return; }
            const s = ui.fateSlide, unit = 100 / (FATE_PAST + FATE_AHEAD + 1), calm = calmMotion();
            const at = i => ({ transform: 'translateX(' + ((s.d - i) * unit) + '%)' });
            const frames = [Object.assign(at(0), { offset: 0 })];
            for (let i = 1; i <= s.d; i++) {
                const end = i / s.d, moved = (i * FATE_STEP - FATE_HOLD) / (s.d * FATE_STEP);
                frames[frames.length - 1].easing = calm ? 'steps(1, end)' : 'ease-in-out';
                frames.push(Object.assign(at(i), { offset: moved }), Object.assign(at(i), { offset: end }));
            }
            try {
                const anim = reel.animate(frames, { duration: s.d * FATE_STEP, fill: 'backwards' });
                anim.currentTime = Math.max(0, now - s.start);
            } catch (e) { /* no WAAPI */ }
        }
        // A coming event: the flip (with the rule card that will turn over) or the reset.
        function eventMarker(ev, i, top, far, ghost) {
            const AX = Rift.data.axioms || {};
            const reset = ev.type === 'reset';
            const known = !reset && i === 0 && top && AX[top];
            const m = el('div.b-fev' + (reset ? '.reset' : '.flip') + (ghost ? '.ghost' : '') + (far ? '.far' : ''), {
                tabindex: ghost ? null : 0, role: ghost ? null : 'button',
                'aria-label': (reset ? 'Reset' : 'New rule') + ' in ' + ev.turns + ' turns',
            }, [
                icon(reset ? 'ui/fate-reset' : 'ui/fate-flip', reset ? '↺' : '✦', 'b-fev-icon'),
                el('span.b-fev-label', { text: (reset ? 'Reset' : 'New rule') + (far ? ' · in ' + ev.turns : '') }),
            ]);
            if (ghost) return m;
            const make = () => (known ? [axiomCardEl(top, { size: 'big' }), el('div.b-notes', {}, [
                el('div.b-note-line', {}, [el('b', { text: 'Fate in ' + ev.turns + ' turn' + (ev.turns === 1 ? '' : 's') + ': ' }), 'this rule card turns over for free and changes the rule for BOTH players.']),
                el('div.b-note-line', {}, [el('b', { text: 'It replaces: ' }), replacedRule(top)]),
                el('div.b-note-line.b-flavour', { text: 'It is the top card of the shared rule deck. If someone takes it first, the next card turns over instead.' })])]
                : [el('div.b-notes', {}, [el('div.b-note-line', {}, [el('b', { text: (reset ? 'Reset' : 'New rule') + ' in ' + ev.turns + ' turns: ' }),
                    reset ? 'every rule card in play is removed. All rules go back to the basics.' : 'the top card of the shared rule deck turns over for free.'])])]);
            hoverInspect(m, make, 'fate:' + i);
            m.addEventListener('click', () => { if (!ui.suppressClick) showInspect(make(), m, 'fate:' + i); });
            return m;
        }
        // " Fate resets all rules in 1 turn!" when a reset is that close (else '').
        function resetSoon() {
            const ev = E.timeline(state)[0];
            return ev && ev.type === 'reset' && ev.turns <= 2 ? ' Careful: Fate resets all rules in ' + ev.turns + ' turn' + (ev.turns === 1 ? '' : 's') + '!' : '';
        }
        // 'Guard: Off (attack anyone)' — the category's name, then the rule in a few words.
        const ruleWords = ax => (ax.short ? (RULE_LABEL[ax.category] || ax.category) + ': ' + ax.short : ax.name);
        // The rule a new rule card would replace: the changed rule in its category, else the basic one.
        function replacedRule(id) {
            const AX = Rift.data.axioms || {};
            const ax = AX[id];
            if (!ax) return 'nothing';
            const cur = AX[state.axioms.active[ax.category]];
            if (cur && !cur.basic) return cur.name + ' (' + (cur.short || cur.text) + ')';
            const core = CORE_RULES.find(c => c[0] === ax.category);
            const basic = core ? core[2] : BASIC_WORDS[ax.category];
            return 'the basic rule' + (basic ? ' (' + basic + ')' : '');
        }
        // Something that already happened on the track (or this turn): a small marker.
        function pastMarker(h, AX) {
            const ax = h.id ? AX[h.id] : null;
            const who = h.by === ME ? 'You' : h.by === OPP ? oppName : 'Fate';
            const text = h.kind === 'reset' ? 'Fate reset all rules' : h.kind === 'forward' ? who + ': Fate 1 sooner' : h.kind === 'rewind' ? who + ': Fate 1 later'
                : (h.kind === 'flip' ? 'Fate turned over ' : who + ' played ') + (ax ? ax.name : 'a rule');
            const m = el('div.b-fpast.' + h.kind, { tabindex: 0, role: 'button', 'aria-label': text },
                [h.kind === 'reset' ? el('span', { text: '↺' }) : h.kind === 'forward' ? el('span', { text: '⏩' }) : h.kind === 'rewind' ? el('span', { text: '⏪' })
                    : has('ui/axiom-' + h.id) ? Rift.Assets.img('ui/axiom-' + h.id, { alt: '' }) : el('span', { text: '⚖' })]);
            const make = () => (ax ? [axiomCardEl(h.id, { size: 'big' }), el('div.b-notes', {}, [el('div.b-note-line', { text: text + (h.k === 0 ? ' (this turn).' : ' (' + -h.k + ' turn' + (h.k === -1 ? '' : 's') + ' ago).') })])]
                : [el('div.b-notes', {}, [el('div.b-note-line', { text: text + '.' })])]);
            hoverInspect(m, make, 'past:' + h.idx + ':' + h.kind + ':' + (h.id || ''));
            m.addEventListener('click', () => { if (!ui.suppressClick) showInspect(make(), m, 'past:' + h.idx + ':' + h.kind + ':' + (h.id || '')); });
            return m;
        }

        // Short Fate wording for the lane (two lines at most); the long one is in its tooltip.
        function fateShort(ev) {
            const when = 'In ' + ev.turns + ' turn' + (ev.turns === 1 ? '' : 's') + ': ';
            if (ev.type === 'reset') return when + (changedRules().length ? 'all rules go back to normal.' : 'rules reset (no change now).');
            const top = state.axioms.deck[0];
            const ax = top && (Rift.data.axioms || {})[top];
            if (ax) return when + 'new rule (' + ax.name + ').';
            if (!state.axioms.deck.length && !state.axioms.discard.length) return when + 'no rule card is left.';
            return when + 'a new rule card.';
        }

        // Plain Fate track wording: "In 6 turns: a new rule card turns over (Wounds Remain)".
        // The named card is only the current top card of the shared deck: someone may take it first.
        function fateText(ev, long) {
            const when = 'In ' + ev.turns + ' turn' + (ev.turns === 1 ? '' : 's') + ': ';
            if (ev.type === 'reset') return when + 'all rules go back to normal.';
            const top = state.axioms.deck[0];
            const ax = top && (Rift.data.axioms || {})[top];
            const next = ev.turns === (E.timeline(state)[0] || {}).turns;
            if (next && ax) return when + 'a new rule card turns over (' + ax.name + (long ? ', the top card of the shared deck' : '') + ').';
            if (!state.axioms.deck.length && !state.axioms.discard.length) return when + 'no rule card is left to turn over.';
            return when + 'a new rule card turns over (the top card of the shared deck).';
        }

        function button(label, fn, cls, extra) {
            const b = el('button.btn.small' + (cls ? '.' + cls : ''), Object.assign({ type: 'button', onclick: fn }, extra || {}), [label]);
            return b;
        }

        // "Granny", "your hero", a card name; an enemy with the same name as one of yours gets "Granny's".
        const targetName = t => {
            if (t === 'h' + OPP) return oppName;
            if (t === 'h' + ME) return 'your hero';
            const c = state.cards[t];
            const twin = c && c.controller === OPP && state.players[ME].board.concat(state.players[ME].hand).some(x => name(x) === name(t));
            return twin ? oppName + "'s " + name(t) : name(t);
        };

        // While a card is being dragged the bar says where it can go.
        function dragText(info) {
            const st = guide ? step() : null;
            const x = st && st.expect;
            if (info.kind === 'board') {
                if (x && x.type === 'attack' && x.cid === info.cid) return 'Drop it on ' + targetName(x.target) + '.';
                return 'Drop it on a glowing target to attack.';
            }
            if (info.kind === 'axiom') return 'Drop it in the middle row.';
            if (info.kind === 'item') return 'Drop it on a glowing target.';
            const c = state.cards[info.cid];
            if (x && x.type === 'play' && x.cid === info.cid && x.target) return 'Drop it on ' + targetName(x.target) + '.';
            if (dragTargets(info).size) return 'Drop it on a glowing target.';
            return c && c.kind === 'creature' ? 'Drop it on your side.' : 'Drop it on the table to use it.';
        }

        // Guide mode: how to do the step's action, in one short sentence.
        function guideHow(x) {
            if (!x) return '';
            if (x.type === 'play' && x.target) return 'Drag ' + name(x.cid) + ' onto ' + targetName(x.target) + '.';
            if (x.type === 'play') return state.cards[x.cid].kind === 'creature' ? 'Drag it onto your side, or click it and press Play.' : 'Drag it onto the table, or click it and press Play.';
            if (x.type === 'attack') return 'Drag ' + name(x.cid) + ' onto ' + targetName(x.target) + '.';
            if (x.type === 'activate') return 'Click ' + name(x.cid) + ', then press Activate.';
            if (x.type === 'axiom') return 'Drag it to the middle row, or click it and press Play rule.';
            return '';
        }

        function renderPrompt() {
            const box = dom.prompt;
            if (!box) return;
            box.innerHTML = '';
            const L = legal();
            const ask = el('div.b-ask');
            const buttons = el('div.b-buttons');
            put(box, ask, buttons);
            nodes.buttons = {};
            if (E.winner(state) != null) { ask.textContent = 'The battle is over.'; return; }
            if (ui.busy || decider() !== ME) {
                ask.textContent = ui.busy ? 'Watch what happens…' : oppName + ' is thinking…';
                ask.classList.add('wait');
            } else if (state.phase === 'draw') {
                ask.textContent = guide && step() ? 'Do this: ' + step().label + '.' : 'Choose your draw for this turn.';
            } else if (state.phase === 'choose') {
                ask.textContent = state.pending.prompt || 'Choose.';
            } else if (ui.drag && ui.drag.active) {
                ask.textContent = dragText(ui.drag.info);
            } else {
                const sel = ui.sel;
                const P = state.players[ME];
                if (!sel && guide && step()) {
                    // Guide mode: the bar repeats Granny's "Do this" (the step's label) plus how.
                    const open = step().open && !ui.hinted;
                    ask.textContent = open ? 'Your decision: read the rule tiles first.' : 'Do this: ' + step().label + '.';
                    const how = step().open && !ui.hinted ? '' : guideHow(step().expect);
                    if (how) ask.appendChild(el('span.b-ask-how', { text: ' ' + how }));
                } else if (!sel) {
                    const canPlay = L.some(a => a.type === 'play' || a.type === 'axiom');
                    const canAttack = L.some(a => a.type === 'attack');
                    const canActivate = L.some(a => a.type === 'activate');
                    const noPlays = E.playsLeft && !E.playsLeft(state, ME) && P.hand.length + P.axHand.length > 0;
                    ask.textContent = noPlays && canAttack ? 'No card plays left. Attack with a ready creature, then End turn.'
                        : noPlays ? 'No card plays left this turn. Press End turn.'
                        : canPlay && canAttack ? 'Drag (or click) a glowing card to play it, or a ready creature onto a target to attack.'
                        : canPlay ? 'Drag (or click) a glowing card to play it. Then End turn.'
                            : canAttack ? 'Drag a ready creature (green glow) onto a target to attack.'
                                : canActivate ? 'Click a ready creature (green glow) to use its ability.'
                                    : ui.sparkFor ? 'Use the Spark (+1 energy) to play ' + ui.sparkFor + '?'
                                        : powerWorth(L) ? 'You can still use your power (the round button by your hero), or press End turn.'
                                        : L.some(a => a.type === 'item') ? 'You can still use an item from your Bag (bottom right), or press End turn.'
                                        : 'Nothing left to do. Press End turn.';
                } else if (sel.kind === 'board') {
                    const tm = targetMap(sel, L);
                    const acts = L.filter(a => a.type === 'activate' && a.cid === sel.cid);
                    ask.textContent = tm.size ? name(sel.cid) + ': click a glowing target to attack.'
                        : acts.length ? name(sel.cid) + ': press the Activate button.' : name(sel.cid) + ': ' + whyNot(sel.cid);
                    acts.reduce((seen, a) => {
                        if (seen.includes(a.ability)) return seen;
                        const info = E.activations(state, sel.cid).find(x => x.id === a.ability) || { name: a.ability, cost: 0 };
                        const b = button('Activate ' + info.name + ' · ' + info.cost + ' ⚡', () => clickActivate(sel.cid, a.ability, L), 'gold');
                        nodes.buttons['activate:' + a.ability] = b;
                        buttons.appendChild(b);
                        return seen.concat(a.ability);
                    }, []);
                    if (acts.length) {
                        const def = (B().Abilities || {})[acts[0].ability];
                        ask.textContent = name(sel.cid) + (def ? ': ' + upFirst(String(def.text).replace(/^Activate \(\d+ energy\):\s*/i, '')) : '') + ' Activating uses its attack this turn.';
                    }
                } else if (sel.kind === 'activate') {
                    ask.textContent = 'Choose a glowing target for ' + name(sel.cid) + '.';
                } else if (sel.kind === 'power') {
                    const st = E.powerStatus(state, ME);
                    ask.textContent = targetMap(sel, L).size ? 'Now click a glowing target for ' + st.name + ' (or Cancel).' : st.name + ': ' + powerWhy(st, L);
                } else if (sel.kind === 'item') {
                    itemPrompt(sel, L, ask, buttons);
                } else if (sel.kind === 'hand') {
                    const playActs = L.filter(a => a.type === 'play' && a.cid === sel.cid);
                    const cost = E.playCost(state, sel.cid);
                    if (!playActs.length) ask.textContent = whyNot(sel.cid);
                    else if (playActs.some(a => a.target)) {
                        const entrance = state.cards[sel.cid].kind === 'creature';
                        ask.textContent = 'Now click a glowing target for ' + name(sel.cid) + (entrance ? '\'s Entrance' : '') + ' (or Cancel).';
                    } else {
                        ask.textContent = 'Play ' + name(sel.cid) + ' for ' + cost + ' energy? You have ' + P.energy + '.';
                        const b = button('Play · ' + cost + ' ⚡', () => act(playActs[0]), 'primary');
                        nodes.buttons.play = b;
                        buttons.appendChild(b);
                    }
                } else if (sel.kind === 'axiom') {
                    const a = L.find(x => x.type === 'axiom' && x.choice === sel.id);
                    const ax = Rift.data.axioms[sel.id];
                    const cost = E.axiomCost(state, sel.id);
                    ask.textContent = !a ? ax.name + ' needs ' + cost + ' energy. You have ' + P.energy + '.'
                        : (ax.clearRules ? ax.name + ' puts every basic rule back for BOTH players, then you draw a card.'
                            : isBasic(ax) ? ax.name + ' puts the basic ' + ax.category + ' rule back for BOTH players.' : ax.name + ' replaces ' + replacedRule(sel.id) + ' for BOTH players.')
                            + resetSoon()
                            + ' Press Play rule, or drag it to the middle row.';
                    if (a) { const b = button('Play rule · ' + cost + ' ⚡', () => act(a), 'primary'); nodes.buttons.axiom = b; buttons.appendChild(b); }
                }
                if (sel) buttons.appendChild(button('Cancel', () => clearSel()));
            }
            // The lane is short: with buttons, a note takes the place of the instruction and the
            // "what just happened" lines are left out (they are in the log), so nothing overlaps.
            const withButtons = buttons.children ? buttons.children.length > 0 : false;
            box.classList.toggle('has-buttons', withButtons);
            box.classList.toggle('has-note', !!ui.note);
            if (ui.note) box.appendChild(el('div.b-note', { text: ui.note }));
            else if (!withButtons && !guide && ui.recapTurn === state.turn && decider() === ME && state.phase === 'main' && ui.recapText) box.appendChild(el('div.b-news.recap', { text: ui.recapText, title: ui.recapFull || ui.recapText }));
            else if (ui.news.length && !withButtons) box.appendChild(el('div.b-news', {}, ui.news.slice(-1).map(t => el('div', { text: t }))));
        }

        function snapshot() {
            const mine = {};
            state.players[ME].board.forEach(cid => { const c = state.cards[cid]; mine[cid] = { damage: c.damage || 0, silenced: !!c.silenced, frozen: !!c.frozen, attack: E.describe(state, cid).attack, name: name(cid) }; });
            return { me: state.players[ME].hearts, them: state.players[OPP].hearts, mine };
        }
        // "Their turn: you lost 3 ❤ · Kim Kardashiant defeated · new rule: Underdog" (or '').
        function theirTurnRecap() {
            const log = E.fullLog(state);
            let start = -1;
            for (let i = log.length - 1; i >= 0; i--) { if (log[i].t === 'turn' && log[i].player === OPP) { start = i; break; } }
            if (start < 0) return '';
            const bits = [];
            let lost = 0;
            const fell = [], played = [];
            const AX = Rift.data.axioms || {};
            log.slice(start).forEach(ev => {
                if (ev.t === 'hit' && ev.player === ME) lost += ev.amount || 0;
                if (ev.t === 'defeated' && ev.player === ME && state.cards[ev.cid]) fell.push(name(ev.cid));
                if ((ev.t === 'play' || ev.t === 'tactic-play') && ev.player === OPP && state.cards[ev.cid]) played.push(name(ev.cid));
                if (ev.t === 'power-use' && ev.player === OPP) bits.push('used ' + powerName(ev.id) + (ev.target && state.cards[ev.target] ? ' on ' + targetName(ev.target) : ''));
                if (ev.t === 'axiom' && AX[ev.id]) bits.push(AX[ev.id].basic ? ruleWords(AX[ev.id]) + ' (as before)' : 'new rule: ' + ruleWords(AX[ev.id]));
                if (ev.t === 'reset') bits.push('all rules reset');
            });
            if (fell.length) bits.unshift(fell.join(', ') + ' defeated');
            if (played.length) bits.unshift('played ' + played.join(', '));
            const snap = ui.snap;
            if (snap) {
                Object.keys(snap.mine).forEach(cid => {
                    const c = state.cards[cid];
                    if (!c) return;
                    if (!state.players[ME].board.includes(cid)) {
                        if (state.players[ME].hand.includes(cid)) bits.push(name(cid) + ' sent back to your hand');
                        return;
                    }
                    if (c.frozen && !snap.mine[cid].frozen) bits.push(name(cid) + ' lectured (can\'t attack)');
                    if ((c.damage || 0) > snap.mine[cid].damage) bits.push(name(cid) + ' took ' + (c.damage - snap.mine[cid].damage) + ' damage');
                    if (c.silenced && !snap.mine[cid].silenced) bits.push(name(cid) + ' lost its abilities');
                    const atk = E.describe(state, cid).attack;
                    const renamed = name(cid) !== snap.mine[cid].name;
                    if (renamed) bits.push(snap.mine[cid].name + ' is now ' + name(cid) + (atk < snap.mine[cid].attack ? ' (−' + (snap.mine[cid].attack - atk) + ' attack)' : ''));
                    else if (atk < snap.mine[cid].attack) bits.push(name(cid) + ' −' + (snap.mine[cid].attack - atk) + ' attack');
                });
                const healed = state.players[OPP].hearts - snap.them;
                if (healed > 0) bits.push(oppName + ' healed ' + healed + ' ❤');
            }
            if (lost) bits.unshift('you lost ' + lost + ' ❤');
            ui.recapFull = bits.length ? oppName + '\'s turn: ' + bits.join(' · ') : '';
            if (!bits.length) return oppName + '\'s turn: nothing changed on your side';
            // Rule news first (the point of the game), then what happened to my side, then their plays.
            const rules = bits.filter(b => /^new rule|all rules reset|\(as before\)$/.test(b)).map(b => (/reset/.test(b) ? '↺ all rules reset' : '⚖ ' + b.replace(/^new rule: /, 'new rule: ')));
            const mine = bits.filter(b => !/^new rule|all rules reset|\(as before\)$|^played /.test(b));
            const plays = bits.filter(b => /^played /.test(b));
            return oppName + '\'s turn: ' + rules.concat(mine, plays).join(' · ');
        }

        // The second player's Spark: a card that becomes playable with +1 energy (null if none).
        function sparkHelp(L) {
            const sp = L.find(a => a.type === 'spark');
            if (!sp || state.phase !== 'main' || L.some(a => a.type === 'play' || a.type === 'axiom')) return null;
            try {
                const next = E.applyAction(state, Object.assign({ player: ME }, sp));
                const a = E.legalActions(next).find(x => x.type === 'play') || E.legalActions(next).find(x => x.type === 'axiom');
                if (!a) return null;
                return a.type === 'play' ? name(a.cid) : ((Rift.data.axioms || {})[a.choice] || { name: a.choice }).name;
            } catch (e) { return null; }
        }

        function renderEnd(L) {
            dom.end.innerHTML = '';
            const end = L.find(a => a.type === 'end');
            // A usable power stops the glow (Brainstorm only when there is a card it would let me play).
            const onlyEnd = end && !ui.sparkFor && !powerWorth(L) && !L.some(a => a.type !== 'end' && a.type !== 'spark' && a.type !== 'item' && a.type !== 'power');
            const style = bg('ui/end-turn');
            const mine = decider() === ME && !ui.busy;
            const b = el('button.b-end' + (style ? '.art' : '') + (onlyEnd ? '.glow' : ''), {
                type: 'button', disabled: !end, style,
                'aria-label': state.phase === 'over' ? 'Game over' : mine ? 'End turn' : ui.busy ? 'Watch' : 'Their turn',
                onclick: () => { if (end && !ui.tipSuppress) act(end); },
            }, (state.phase === 'over' ? ['Game', 'over'] : mine ? ['End', 'turn'] : ui.busy ? ['Watch', ''] : ['Their', 'turn'])
                .filter(Boolean).map(w => el('span', { text: w })));
            tipFor(b, 'end', 'End turn', state.phase === 'over' ? 'The battle is over.' : !mine ? 'Wait for your turn.'
                : state.phase === 'draw' ? 'First choose your draw.' : end ? 'Finish your turn. The Fate track moves 1 space.' + (E.rules(state).handCap != null && state.players[ME].hand.length + state.players[ME].axHand.length > E.rules(state).handCap ? ' Hand limit ' + E.rules(state).handCap + ': your oldest cards will be discarded.' : '') : 'First answer the question.');
            nodes.end = b;
            dom.end.appendChild(b);
            if (onlyEnd) dom.end.appendChild(el('div.b-end-hint', { text: 'Nothing left to do' }));
        }

        // The rule card draw takes the top card of the shared deck: the one Fate would turn over next.
        function axiomDrawNote(tl) {
            const AX = Rift.data.axioms || {};
            const top = AX[state.axioms.deck[0]];
            if (!top) return 'Shared deck: ' + state.axioms.deck.length;
            const flip = tl.length && tl[0].type === 'flip';
            return 'You take ' + top.name + ': ' + ruleWords(top) + (flip ? '. Fate would turn it over in ' + tl[0].turns + ' turn' + (tl[0].turns === 1 ? '' : 's') + ', so taking it stops that' : '');
        }
        function renderDraw(L) {
            dom.draw.innerHTML = '';
            const show = state.phase === 'draw' && decider() === ME && !ui.ended && !ui.busy;
            dom.draw.classList.toggle('show', show);
            dom.lane.classList.toggle('drawing', show);
            nodes.draw = {};
            if (!show) return;
            const P = state.players[ME];
            const choices = E.drawChoices(state);
            const full = P.hand.length + P.axHand.length >= state.options.handLimit;
            const tl = E.timeline(state);
            // Short enough to fit at 1280 px: "Rule card in 4", "Reset in 3", "Reset (no change now)".
            const after = n => {
                const ev = tl[0];
                if (ev.type === 'reset' && !changedRules().length) return 'Reset (no change now)';
                return (ev.type === 'reset' ? 'Reset' : 'Rule card') + (n <= 0 ? ' now' : ' in ' + n);
            };
            const noFate = !state.options.timeline ? 'No Fate track in this match.' : '';
            const why = {
                deck: full ? 'Your hand is full.' : !P.deck.length ? 'Your deck is empty.' : P.deck.length + ' cards left',
                axiom: full ? 'Your hand is full.' : !(state.axioms.deck.length || state.axioms.discard.length) ? 'The rule deck is empty.' : axiomDrawNote(tl),
                forward: noFate || (tl.length ? after(tl[0].turns - 1) : ''),
                rewind: noFate || (tl.length ? after(Math.min(state.options.fateMax, tl[0].turns + 1)) : ''),
            };
            const st = step();
            // Picture buttons with a tiny status badge; the name and the details are in the tooltip.
            const when = n => (n <= 0 ? 'now' : 'in ' + n);
            const badge = {
                deck: String(P.deck.length),
                axiom: String(state.axioms.deck.length),
                forward: !noFate && tl.length ? when(tl[0].turns - 1) : '',
                rewind: !noFate && tl.length ? when(Math.min(state.options.fateMax, tl[0].turns + 1)) : '',
            };
            const none = L.find(x => x.type === 'draw' && x.choice === 'none');
            put(dom.draw, el('div.b-draw-title', {}, [el('strong', { text: 'Choose' }), el('span', { text: 'one draw' })]), el('div.b-draw-buttons', {}, ['deck', 'axiom'].concat(state.options.timeDraws ? ['forward', 'rewind'] : []).map(choice => {
                const a = L.find(x => x.type === 'draw' && x.choice === choice);
                const possible = choices.includes(choice);
                const lessonOnly = !a && possible && guide && st;
                const detail = (choice === 'deck' && E.rules(state).drawCount > 1 ? E.rules(state).drawCount + ' cards from your deck' : DRAW_TEXT[choice][1]) + '. ' + (lessonOnly ? 'Not in this lesson step.' : why[choice] ? why[choice].replace(/\.?$/, '.') : '');
                const b = iconButton('.b-draw-btn', {
                    key: 'draw:' + choice, name: DRAW_TEXT[choice][0], detail: detail.trim(), off: !a,
                    art: DRAW_ART[choice], svg: CTRL_SVG[choice], badge: badge[choice], extra: { dataset: { choice } },
                    // A dim button says why on a click or tap (the tooltip stays until the next tap).
                    onclick: (ev, btn) => { if (a) act(a); else showTip(btn, true); },
                });
                nodes.draw[choice] = b;
                // Pointing at a time draw previews it on the Fate track.
                if ((choice === 'forward' || choice === 'rewind') && !noFate) {
                    const preview = on => { if (dom.draw.classList.contains('show')) paintFate(on ? (choice === 'forward' ? -1 : 1) : 0); };
                    b.addEventListener('pointerenter', () => preview(true));
                    b.addEventListener('pointerleave', () => preview(false));
                    b.addEventListener('focus', () => preview(true));
                    b.addEventListener('blur', () => preview(false));
                }
                // The rule card button also names the card on top of the shared deck.
                const topAx = choice === 'axiom' && a ? (Rift.data.axioms || {})[state.axioms.deck[0]] : null;
                return el('div.b-draw-opt', {}, [b, el('span.b-draw-label', { 'aria-hidden': 'true', onclick: () => b.click() }, [DRAW_LABEL[choice],
                    topAx ? el('small', { text: ruleWords(topAx) }) : choice === 'deck' && a ? el('small', { text: 'creature or tactic' }) : null])]);
            }).concat(none ? [button('Nothing to draw: continue', () => act(none), 'primary')] : [])));
            // What the opponent's turn did to me, in one line, beside the draw choice.
            const recap = guide ? '' : theirTurnRecap();
            ui.recapTurn = state.turn;
            ui.recapText = recap;
            if (recap) dom.draw.appendChild(el('div.b-draw-recap', { text: recap, title: ui.recapFull || recap }));
        }

        function renderChoice(L) {
            dom.choice.innerHTML = '';
            const pend = state.pending;
            const show = state.phase === 'choose' && pend && decider() === ME && !ui.busy;
            dom.choice.classList.toggle('show', !!show);
            nodes.choose = {};
            if (!show) return;
            const pick = choice => { const a = L.find(x => x.type === 'choose' && x.choice === choice); if (a) act(a); };
            const opts = el('div.b-choice-options');
            pend.options.forEach(choice => {
                const ok = L.some(x => x.type === 'choose' && x.choice === choice);
                let b;
                if (pend.choiceKind === 'card' && state.cards[choice]) {
                    b = cardEl(choice, { size: 'hand', unregistered: true, onclick: () => pick(choice), classes: ok ? ['playable'] : [] });
                } else if (pend.choiceKind === 'axiom') {
                    b = axiomCardEl(choice, { size: 'hand', onclick: () => pick(choice), classes: ok ? ['playable'] : [] });
                } else if (pend.choiceKind === 'colour') {
                    b = el('button.btn.colour-btn', { type: 'button', dataset: { colour: choice }, onclick: () => pick(choice) }, [Rift.COLOURS[choice].icon + ' ' + Rift.COLOURS[choice].name]);
                } else if (pend.choiceKind === 'ability') {
                    const def = B().Abilities[choice] || { name: choice, text: '' };
                    b = el('button.btn.b-choice-text', { type: 'button', onclick: () => pick(choice) }, [el('b', { text: def.name + ': ' }), def.text]);
                } else {
                    const label = (pend.labels && pend.labels[choice]) || String(choice);
                    b = el('button.btn.b-choice-text', { type: 'button', onclick: () => pick(choice) }, [label, fateOutcome(pend, choice)]);
                }
                if (!ok) b.disabled = true;
                nodes.choose[choice] = b;
                opts.appendChild(b);
            });
            put(dom.choice, el('div.b-choice-title', { text: pend.prompt || 'Choose.' }), opts);
        }

        // "Rules in play": one tile per rule, a picture and a few words. The four core rules always
        // show; a changed rule glows gold and says "Changed". Hover, focus or tap a tile for the card.
        // For a Fate choice (Clockwork): what the next event would do after that move.
        function fateOutcome(pend, choice) {
            if (!(choice === 'forward' || choice === 'rewind') || !pend.source || pend.source.id !== 'clockwork') return null;
            const tl = E.timeline(state);
            if (!tl.length) return null;
            const n = Math.max(0, Math.min(state.options.fateMax, tl[0].turns + (choice === 'forward' ? -1 : 1)));
            const what = tl[0].type === 'reset' ? 'Reset' : 'New rule';
            const whose = ((state.active + n) % 2) === ME ? 'your turn' : oppName + '\'s turn';
            return el('small.b-choice-out', { text: n === 0 ? what + ' happens NOW' : what + ' in ' + n + ' turn' + (n === 1 ? '' : 's') + ' (' + whose + ')' });
        }

        function renderRules() {
            dom.rules.innerHTML = '';
            // The colour wheel strip runs backwards under the Broken Postulate.
            const chainEl = dom.wheel.querySelector ? dom.wheel.querySelector('.b-wheel-chain') : null;
            if (chainEl) {
                const W = Rift.data.wheel, icons = W.order.concat(W.order[0]).map(c => (Rift.COLOURS[c] || {}).icon || c);
                chainEl.textContent = E.rules(state).wheelReversed ? icons.reverse().join(' › ') + '  (reversed!)' : icons.join(' › ');
            }
            const active = state.axioms.active;
            const AX = Rift.data.axioms || {};
            const tiles = CORE_RULES.map(([cat, , basic, art, long]) => ruleTile(cat, active[cat], basic, art, long));
            Object.keys(active).forEach(cat => {
                const ax = AX[active[cat]];
                if (ax && !ax.basic && !CORE_RULES.some(c => c[0] === cat)) tiles.push(ruleTile(cat, active[cat]));
            });
            const n = changedRules().length;
            put(dom.rules,
                el('div.b-rules-head', {}, [el('strong', { text: 'Rules in play' }), el('span.b-rules-sub', { text: n ? n + ' changed (gold tiles)' : 'All basic. Rule cards and Fate can change them.' })]),
                el('div.b-rule-tiles' + (tiles.length > 6 ? '.compact' : ''), {}, tiles));
        }
        function ruleTile(cat, id, basicWords, basicArt, basicLong) {
            const AX = Rift.data.axioms || {};
            const ax = id ? AX[id] : null;
            const changed = !!(ax && !ax.basic);
            // Changed: the rule card's vignette. Basic: the rule's own icon (ui/rule-<category>), else the basic card's.
            const art = changed ? 'ui/axiom-' + id : has('ui/rule-' + cat) ? 'ui/rule-' + cat : basicArt ? 'ui/axiom-' + basicArt : null;
            let words = changed ? ax.short || ax.name : basicWords || (ax && ax.short) || '';
            // An attack limit is a per-turn budget: show what is left for the player whose turn it is.
            const r = E.rules(state);
            let budget = null;
            if (cat === 'attacks' && r.attackLimit !== Infinity && E.winner(state) == null) {
                const left = Math.max(0, r.attackLimit - (state.players[state.active].attacksThisTurn || 0));
                budget = left + ' left' + (state.active === ME ? '' : ' for ' + oppName);
            }
            if (cat === 'energy' && !changed) words = '+' + r.growth + ' each turn';
            if (cat === 'plays' && E.playsLeft && E.winner(state) == null && r.playLimit !== Infinity) {
                budget = E.playsLeft(state, state.active) + ' left' + (state.active === ME ? '' : ' for ' + oppName);
            }
            const label = RULE_LABEL[cat] || cat;
            const tile = el('div.b-rtile' + (changed ? '.changed' : ''), {
                tabindex: 0, role: 'button', dataset: { cat },
                'aria-label': label + ': ' + words + (changed ? ' (changed by ' + ax.name + ')' : ''),
            }, [
                art && has(art) ? Rift.Assets.img(art, { className: 'b-rtile-art', alt: '' }) : el('span.b-rtile-art.glyph', { text: RULE_GLYPH[cat] || '⚖' }),
                el('span.b-rtile-words', {}, [el('span.b-rtile-cat', { text: label }), el('span.b-rtile-val', { text: words })]),
                budget ? el('span.b-rtile-budget', { text: budget }) : changed ? el('span.b-rtile-new', { text: 'Changed' }) : null,
            ]);
            const make = () => (changed ? [axiomCardEl(id, { size: 'big' }), axiomNote(id)]
                : [el('div.b-notes.b-basic-rule', {}, [el('div.b-note-line', {}, [el('b', { text: label + ' (basic rule): ' }), basicLong || words]),
                    el('div.b-note-line.b-flavour', { text: 'A rule card (axiom) can change this rule for BOTH players.' })])]);
            hoverInspect(tile, make, 'rule:' + cat);
            tile.addEventListener('click', () => {
                if (ui.suppressClick) return;
                if (ui.inspect && ui.inspect.key === 'rule:' + cat && dom.inspect.classList.contains('show')) hideInspect();
                else showInspect(make(), tile, 'rule:' + cat);
            });
            return tile;
        }

        // Recent plays, like a card battler's history column: the last moves as small pictures
        // (newest first, yours teal, theirs coral). Each holds what followed it (damage, defeats,
        // abilities) until the next move; hover, focus or tap shows the card and those lines.
        const MOVES = { play: '✦', 'tactic-play': '✦', attack: '⚔', activate: '⚡', axiom: '⚖', reset: '↺', time: '⧗', 'item-use': '🎒', spark: '✦', 'power-use': '✷' };
        const RECENT = 5;
        function recentMoves() {
            const moves = [];
            // A Fate flip logs 'flip' and then the rule ('axiom' with no player): one tile, the rule.
            E.fullLog(state).forEach(ev => {
                if (MOVES[ev.t] && !(ev.t === 'spark' && !/uses? the Spark/.test(ev.text || ''))) moves.push({ ev, after: [] });
                else if (moves.length && !/^(turn|turn-end|round|draw|draw-axiom|axiom-play|flip|time)$/.test(ev.t)) {
                    const text = visibleText(ev);
                    if (text) moves[moves.length - 1].after.push(text);
                }
            });
            return moves.slice(-RECENT).reverse();
        }
        function renderRecent() {
            const box = dom.recent;
            box.innerHTML = '';
            const moves = recentMoves();
            box.classList.toggle('empty', !moves.length);
            put(box, el('div.b-recent-head', { text: 'Recent' }), el('div.b-recent-list', {}, moves.map((m, i) => recentTile(m, i))));
        }
        function recentTile(m, i) {
            const ev = m.ev;
            const by = ev.player === ME ? 'You' : ev.player === OPP ? oppName : 'Fate';
            const AX = Rift.data.axioms || {};
            const axId = ev.t === 'axiom' ? ev.id : null;
            const card = ev.cid && state.cards[ev.cid] ? ev.cid : null;
            let pic;
            if (axId && has('ui/axiom-' + axId)) pic = Rift.Assets.img('ui/axiom-' + axId, { alt: '' });
            else if (card && state.cards[card].kind === 'creature') pic = Rift.Assets.img('creature/' + state.cards[card].species + '/idle', { alt: '', label: name(card) });
            else if (card && has('tactic/' + state.cards[card].tactic)) pic = Rift.Assets.img('tactic/' + state.cards[card].tactic, { alt: '' });
            else if (ev.t === 'reset') pic = icon('ui/fate-reset', '↺', 'b-recent-glyph');
            else if (ev.t === 'power-use') pic = powerIcon(ev.id, 'b-recent-glyph');
            else pic = el('span.b-recent-glyph', { text: MOVES[ev.t] || '•' });
            const text = visibleText(ev) || '';
            const tile = el('div.b-recent-tile.' + (ev.player === ME ? 'mine' : ev.player === OPP ? 'theirs' : 'fate') + (i === 0 ? '.newest' : ''), {
                tabindex: 0, role: 'button', 'aria-label': text + (m.after.length ? ' ' + m.after.join(' ') : ''),
            }, [pic, el('span.b-recent-move', { text: MOVES[ev.t] || '•', 'aria-hidden': 'true' }), el('span.b-recent-who', { text: by === 'You' ? 'You' : by === 'Fate' ? 'Fate' : 'Them', 'aria-hidden': 'true' })]);
            const make = () => {
                const big = axId ? axiomCardEl(axId, { size: 'big' }) : ev.t === 'power-use' ? powerBig(ev.id, ev.player) : card ? cardEl(card, { size: 'big', unregistered: true }) : null;
                return [big, el('div.b-notes', {}, [el('div.b-note-line', {}, [el('b', { text: text })])].concat(
                    m.after.slice(0, 5).map(t => el('div.b-note-line', { text: t }))))];
            };
            hoverInspect(tile, make, 'recent:' + i);
            tile.addEventListener('click', () => { if (!ui.suppressClick) showInspect(make(), tile, 'recent:' + i); });
            return tile;
        }

        // ---- guide mode ----
        function speak() {
            const st = step();
            if (!st || !Rift.Audio || !Rift.Audio.speak) return;
            try { Rift.Audio.speak({ speaker: 'granny', text: st.text, voice: Rift.voiceId('granny', st.text) }); } catch (e) { /* no voice */ }
        }
        function stopVoice() { try { if (Rift.Audio && Rift.Audio.stopVoice) Rift.Audio.stopVoice(); } catch (e) { /* none */ } }
        // A lesson trap (step.trap = { expect, card, title, what, say }): the tempting move is stopped,
        // its rule card is shown big with what would happen, and Granny says why. The step stays.
        function springTrap(trap) {
            ui.sel = null;
            const st = step();
            if (st && st.open && (ui.hintLevel || 0) < 1) { clearTimeout(ui.hintTimer); ui.hintTimer = setTimeout(() => giveHint(st, 1), TRAP_PAUSE); }
            ui.trapSaid = { step: ui.step, text: trap.say };
            showReveal(el('div.b-reveal-rule', {}, [trap.card ? axiomCardEl(trap.card, { size: 'big' }) : null, el('div.b-reveal-what', { text: trap.what })]), trap.title || 'Careful!', RULE_SHOW, 'rule trap', false);
            ui.holding = false;   // the learner may act again at once
            setNote(trap.say);
            try { if (Rift.Audio && Rift.Audio.speak) Rift.Audio.speak({ speaker: 'granny', text: trap.say, voice: Rift.voiceId ? Rift.voiceId('granny', trap.say) : null }); } catch (e) { /* no voice */ }
        }
        // An open lesson step ({ open, hint }): no gold pointer at first, so the learner decides. The
        // hint (and the pointer) come after HINT_AFTER ms, or at once after the step's trap.
        const HINT_AFTER = 40000, HINT2_AFTER = 25000, TRAP_PAUSE = 6000;   // TRAP_PAUSE: the warning is heard first
        function sayHint(text) {
            try { if (Rift.Audio && Rift.Audio.speak) Rift.Audio.speak({ speaker: 'granny', text, voice: Rift.voiceId ? Rift.voiceId('granny', text) : null }); } catch (e) { /* no voice */ }
        }
        // Level 1 shows the idea; level 2 (or a step without hint2) also shows the gold pointer.
        function giveHint(st, level) {
            if (ui.ended || step() !== st || (ui.hintLevel || 0) >= level) return;
            ui.hintLevel = level;
            ui.hinted = level >= 2 || !st.hint2;
            render();
            sayHint(level >= 2 ? st.hint2 : st.hint);
            if (level < 2 && st.hint2) { clearTimeout(ui.hintTimer); ui.hintTimer = setTimeout(() => giveHint(st, 2), HINT2_AFTER); }
        }
        function startHintClock() {
            clearTimeout(ui.hintTimer);
            ui.hinted = false;
            ui.hintLevel = 0;
            const st = step();
            if (!st || !st.open) return;
            ui.hintTimer = setTimeout(() => giveHint(st, 1), HINT_AFTER);
        }
        // The text Granny shows for a step: an open step adds its hints once they are due.
        const stepText = st => (!st.open ? st.text : ui.hintLevel >= 2 && st.hint2 ? st.hint2 : ui.hintLevel >= 1 && st.hint ? st.hint : st.text);
        // A narration line between replies: shown in Granny's panel and spoken; the lesson goes on
        // when the voice ends (at least a reading pause, at most 12 s).
        function narrate(text) {
            const gen = (ui.sayGen = (ui.sayGen || 0) + 1);
            ui.say = text;
            ui.saying = true;
            render();
            const words = String(text).split(/\s+/).length;
            let voiceDone = false, readDone = false;
            const go = () => { if (voiceDone && readDone && ui.sayGen === gen && !ui.ended && ui.saying) { ui.saying = false; clearTimeout(ui.sayCap); schedule(); } };
            let p = null;
            try { p = Rift.Audio && Rift.Audio.speak ? Rift.Audio.speak({ speaker: 'granny', text, voice: Rift.voiceId ? Rift.voiceId('granny', text) : null }) : null; } catch (e) { p = null; }
            if (p && p.then) p.then(() => { voiceDone = true; go(); }, () => { voiceDone = true; go(); });
            else voiceDone = true;
            ui.sayTimer = setTimeout(() => { readDone = true; go(); }, Math.max(1200, words * 260));
            ui.sayCap = setTimeout(() => { voiceDone = true; go(); }, 12000);
        }

        function leaveGuide() {
            if (ui.ended) return;
            ui.ended = true;
            clearTimeout(ui.timer);
            stopVoice();
            const result = { mode, outcome: 'left', turns: state.turn, rounds: state.round, endReason: null, fate: null, ante: null, settlement: null, itemsUsed: itemsUsedNow() };
            handle.result = result;
            if (typeof p.onEnd === 'function') p.onEnd(result);
        }

        // Practice and story matches: "Leave match" asks first, then ends with outcome 'left'.
        function askLeave() {
            if (ui.ended || ui.confirm || help) return;
            ui.confirm = true;
            clearTimeout(ui.timer);
            cancelDrag();
            hideInspect();
            hideTip();
            const stay = button('Keep playing', () => {
                ui.confirm = false;
                dom.overlay.classList.remove('show');
                dom.overlay.innerHTML = '';
                render();
                schedule();
            }, 'primary');
            const go = button('Leave match', leaveMatch, 'b-leave-confirm');
            dom.overlay.innerHTML = '';
            dom.overlay.appendChild(el('div.b-end-panel.panel.b-confirm', { role: 'dialog', 'aria-label': 'Leave this match?' }, [el('div.b-end-body', {}, [
                el('h2', { text: 'Leave this match?' }),
                el('p', { text: 'Nothing is at stake: no win or loss is counted. Your creatures are safe.' + (p.story ? ' You can try Syllo\'s challenge again later.' : '') }),
                el('div.b-buttons', {}, [stay, go]),
            ])]));
            dom.overlay.classList.add('show');
            if (stay.focus) try { stay.focus(); } catch (e) { /* ignore */ }
        }
        function leaveMatch() {
            if (ui.ended) return;
            ui.ended = true;
            clearTimeout(ui.timer);
            const result = { mode, outcome: 'left', turns: state.turn, rounds: state.round, endReason: null, fate: null, ante: null, settlement: null, itemsUsed: itemsUsedNow() };
            handle.result = result;
            if (typeof p.onEnd === 'function') p.onEnd(result);
        }

        function renderCoach() {
            const box = dom.coach;
            box.innerHTML = '';
            const st = step();
            const n = guide.steps.length;
            const speaker = (Rift.data.speakers || {}).granny;
            const done = !st;
            put(box, 
                el('div.b-coach-head', {}, [
                    speaker ? Rift.Assets.img(speaker.art, { className: 'b-coach-face', label: speaker.name, alt: '' }) : null,
                    el('div', {}, [el('div.b-coach-count', { text: done ? 'Lesson complete' : 'Step ' + (ui.step + 1) + ' of ' + n }), el('h3', { text: done ? 'Well played!' : st.title })]),
                ]),
                !ui.busy && ui.trapSaid && ui.trapSaid.step === ui.step ? el('p.b-coach-say.warn', { text: ui.trapSaid.text }) : null,
                ui.busy && !done ? null : el('p.b-coach-text', { text: done ? 'You won by the current rules.' : stepText(st) }),
                el('p.b-coach-notice', { role: 'status', 'aria-live': 'polite', text: done ? '' : E.winner(state) != null ? 'The match is over.' : ui.busy ? (ui.say || !ui.queue.length ? '' : 'Watch Granny\'s reply…') : st.open && !ui.hinted ? 'Your decision: read the rule tiles first.' : 'Do this: ' + st.label }),
                ui.busy && ui.say ? el('p.b-coach-say', { text: ui.say }) : null,
                st && st.compare ? comparison(st.compare) : null,
                el('div.b-coach-buttons', {}, [
                    st && st.info && !ui.busy && !nodes.pw0 ? el('button.btn.primary.b-coach-ok',{ type: 'button', text: st.label, onclick: infoDone }) : null,
                    done ? null : iconButton('.b-replay', { key: 'replay', name: 'Hear this step again', detail: 'Granny reads this step out loud again.', art: 'ui/btn-replay', svg: CTRL_SVG.replay, extra: { disabled: ui.busy }, onclick: speak }),
                    iconButton('.b-leave', { key: 'leave', name: 'Leave lesson', detail: 'Stop the lesson. You can start it again later.', art: 'ui/btn-leave', svg: CTRL_SVG.leave, onclick: leaveGuide }),
                ]),
            );
        }

        // An explain-only lesson step (step.info): Got it moves on, with no move made.
        function infoDone() {
            const st = step();
            if (!st || !st.info || ui.busy) return;
            ui.step += 1;
            startHintClock();
            render();
            speak();
        }

        function fightLine(label, pv, a, d) {
            const res = pv.attackerDefeated && pv.defenderDefeated ? 'both are defeated'
                : pv.attackerDefeated ? name(a) + ' is defeated'
                    : pv.defenderDefeated ? name(d) + ' is defeated' : 'both survive';
            return el('p', { text: label + ': ' + name(a) + ' ' + pv.pa + ' vs ' + name(d) + ' ' + pv.pb + ' → ' + res + '.' });
        }
        function comparison(pair) {
            const [a, d] = pair;
            const onBoard = cid => state.players[0].board.includes(cid) || state.players[1].board.includes(cid);
            if (!onBoard(a) || !onBoard(d)) return null;
            const without = Object.assign({}, state.axioms.active);
            delete without.combat;
            const normal = E.fightPreview(Object.assign({}, state, { axioms: Object.assign({}, state.axioms, { active: without }) }), a, d);
            const rule = E.fightPreview(Object.assign({}, state, { axioms: Object.assign({}, state.axioms, { active: Object.assign({}, without, { combat: 'underdog' }) }) }), a, d);
            return el('div.b-compare', {}, [el('strong', { text: 'Same cards, different rule' }), fightLine('Normal rules', normal, a, d), fightLine('Underdog', rule, a, d)]);
        }

        // Which element the gold pointer points at, and which target gets the ring.
        function renderGuidePointer() {
            if (!guide) return;
            const st = step();
            if (!st || ui.busy || decider() !== ME) return;
            if (st.open && !ui.hinted) return;   // an open step: the learner decides first
            const x = st.expect;
            let focus = null;
            let ring = null;
            if (x.type === 'info') focus = nodes.pw0 || null;
            else if (x.type === 'draw') focus = nodes.draw && nodes.draw[x.choice];
            else if (x.type === 'end') focus = nodes.end;
            else if (x.type === 'spark') focus = screen.querySelector ? screen.querySelector('.b-spark') : null;
            else if (x.type === 'choose') focus = nodes.choose && nodes.choose[x.choice];
            else if (x.type === 'axiom') {
                focus = ui.sel && ui.sel.kind === 'axiom' && nodes.buttons.axiom ? nodes.buttons.axiom : findAxiomInHand(x.choice);
                ring = dom.lane;
            } else if (x.type === 'play') {
                const selected = ui.sel && ui.sel.kind === 'hand' && ui.sel.cid === x.cid;
                if (selected && x.target) focus = nodes[x.target];
                else if (selected && nodes.buttons.play) focus = nodes.buttons.play;
                else { focus = nodes[x.cid]; ring = x.target ? nodes[x.target] : dom.myBoard; }
            } else if (x.type === 'attack') {
                if (ui.sel && ui.sel.cid === x.cid) focus = nodes[x.target];
                else { focus = nodes[x.cid]; ring = nodes[x.target]; }
            } else if (x.type === 'activate') {
                if (ui.sel && ui.sel.kind === 'activate' && ui.sel.cid === x.cid) focus = nodes[x.target];
                else if (ui.sel && ui.sel.cid === x.cid) focus = nodes.buttons['activate:' + x.ability];
                else focus = nodes[x.cid];
            }
            if (ring && ring !== focus) ring.classList.add('guide-ring');
            if (focus) {
                focus.classList.add('guide-focus');
                const up = focus.closest && focus.closest('.opp-board, .b-hero-row.opp');
                const tag = el('span.guide-pointer', { 'aria-hidden': 'true', text: (up ? '▲ ' : '▼ ') + st.label });
                focus.appendChild(tag);
                keepInside(tag);
            }
        }
        // Nudge a pointer label back inside the table when its card sits at the edge.
        function keepInside(tag) {
            if (!tag.getBoundingClientRect || !dom.arena.getBoundingClientRect) return;
            const a = dom.arena.getBoundingClientRect(), r = tag.getBoundingClientRect();
            if (!r.width) return;
            const dx = r.left < a.left + 6 ? a.left + 6 - r.left : r.right > a.right - 6 ? a.right - 6 - r.right : 0;
            if (dx) tag.style.marginLeft = Math.round(dx) + 'px';
        }
        function findAxiomInHand(id) { return nodes['ax:' + id] || null; }

        // ---- clicks ----
        function clickTarget(target, L) {
            const a = targetMap(ui.sel, L).get(target);
            if (a) { act(a); return true; }
            return false;
        }

        function clickCard(cid, L) {
            if (clickTarget(cid, L)) return;
            const c = state.cards[cid];
            const mine = c.controller === ME && state.players[ME].board.includes(cid);
            // A tactic, Entrance or ability waiting for a target, and an Elusive enemy is clicked.
            if (!mine && ui.sel && (ui.sel.kind === 'hand' || ui.sel.kind === 'activate' || ui.sel.kind === 'item') && elusiveNote(cid)) { setNote(elusiveNote(cid)); return; }
            // An attacker is selected and this enemy is not a valid target (for example: Guard).
            if (!mine && ui.sel && ui.sel.kind === 'board' && state.players[OPP].board.includes(cid)) { setNote(badTargetNote(ui.sel.cid, cid)); return; }
            if (mine && L.some(a => (a.type === 'attack' || a.type === 'activate') && a.cid === cid)) {
                ui.sel = ui.sel && ui.sel.cid === cid ? null : { kind: 'board', cid };
                render();
                return;
            }
            if (ui.sel) { ui.sel = null; render(); }
            setNote(whyNot(cid));
        }

        function clickHand(cid, L) {
            if (clickTarget(cid, L)) return;
            if (!L.some(a => a.type === 'play' && a.cid === cid)) { if (ui.sel) { ui.sel = null; render(); } setNote(whyNot(cid)); return; }
            ui.sel = ui.sel && ui.sel.cid === cid ? null : { kind: 'hand', cid };
            render();
        }

        function whyNotAxiom(id) {
            if (guide && !ui.busy) return 'Not now. Follow the gold pointer.';
            if (ui.busy || decider() !== ME) return 'Wait for your turn.';
            if (state.phase === 'draw') return 'First choose your draw.';
            if (state.phase === 'choose') return 'First answer the question.';
            if (!axiomChanges(id)) return whyNotAxiomRule(id);
            if (E.playsLeft && !E.playsLeft(state, ME)) return 'No card plays left this turn (' + E.playLimit(state, ME) + ' per turn).';
            return 'This rule card needs ' + E.axiomCost(state, id) + ' energy. You have ' + state.players[ME].energy + '.';
        }
        // The engine leaves out rule cards that would change nothing (same rule already on).
        const axiomChanges = id => !E.axiomWouldChange || E.axiomWouldChange(state, id);
        const whyNotAxiomRule = id => (((Rift.data.axioms || {})[id] || {}).clearRules ? 'No rule to clear: every rule is basic now.'
            : 'Already the rule: ' + ((Rift.data.axioms || {})[id] || { name: id }).name + ' would change nothing now.');
        function clickAxiom(id, L) {
            if (!L.some(a => a.type === 'axiom' && a.choice === id)) { setNote(whyNotAxiom(id)); return; }
            ui.sel = ui.sel && ui.sel.id === id ? null : { kind: 'axiom', id };
            render();
        }

        function clickActivate(cid, ability, L) {
            const acts = L.filter(a => a.type === 'activate' && a.cid === cid && a.ability === ability);
            if (!acts.length) return;
            if (acts.length === 1 && !acts[0].target) { act(acts[0]); return; }
            ui.sel = { kind: 'activate', cid, ability };
            render();
        }

        // ---- dragging (Pointer Events: mouse, pen and touch) ----
        function startDrag(ev, info, node) {
            if (ev.button != null && ev.button !== 0) return;
            // A card that can't be played now: no drag, but a drag gesture still explains why
            // (a drop must never vanish without a word).
            if (info.blocked || !myTurn() || state.phase !== 'main') {
                ui.drag = { info, blocked: true, x0: ev.clientX, y0: ev.clientY, id: ev.pointerId, active: false };
                return;
            }
            if (ev.preventDefault) ev.preventDefault();
            ui.drag = { info, node, x0: ev.clientX, y0: ev.clientY, id: ev.pointerId, active: false, ghost: null };
            try { if (node.setPointerCapture) node.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
        }

        function dragTargets(info) {
            const L = legal();
            const out = new Map();
            if (info.kind === 'board') L.forEach(a => { if (a.type === 'attack' && a.cid === info.cid) out.set(a.target, a); });
            if (info.kind === 'hand') L.forEach(a => { if (a.type === 'play' && a.cid === info.cid && a.target) out.set(a.target, a); });
            if (info.kind === 'item') L.forEach(a => { if (a.type === 'item' && a.id === info.id && a.target) out.set(a.target, a); });
            return out;
        }

        function onPointerMove(ev) {
            const lp = ui.longPress;
            if (lp && ev.pointerId === lp.id && !lp.shown && Math.hypot(ev.clientX - lp.x, ev.clientY - lp.y) >= DRAG_START) cancelLongPress();
            const tp = ui.tipLP;
            if (tp && ev.pointerId === tp.id && !tp.shown && Math.hypot(ev.clientX - tp.x, ev.clientY - tp.y) >= DRAG_START) cancelTipPress();
            // A mouse that has left the button hides its tooltip (also after a re-render).
            if (ev.pointerType === 'mouse' && ui.tip && !ui.tip.sticky && ev.target && ui.tip.node.contains && !ui.tip.node.contains(ev.target)) hideTip();
            // After a drag, hover previews wait until the mouse really moves; then the card under it may open one.
            const hb = ui.hoverBlock;
            if (hb && !ui.drag && Math.hypot(ev.clientX - hb.x, ev.clientY - hb.y) >= 12) {
                ui.hoverBlock = null;
                const under = Object.keys(inspectables).find(k => inspectables[k].node.contains && inspectables[k].node.contains(ev.target));
                if (under && ev.pointerType === 'mouse') waitInspect(inspectables[under].node, inspectables[under].make, under);
            }
            // A mouse that has left the previewed card hides the preview (also after a re-render).
            if (ev.pointerType === 'mouse' && ui.inspect && ui.inspect.anchor && ev.target && ui.inspect.anchor.contains
                && !ui.inspect.anchor.contains(ev.target) && dom.inspect.classList.contains('show')) {
                const it = ui.inspect.key && inspectables[ui.inspect.key];
                if (!it || !it.node.contains(ev.target)) hideInspect();
            }
            const d = ui.drag;
            if (!d || ev.pointerId !== d.id || d.blocked) return;
            if (!d.active) {
                if (Math.hypot(ev.clientX - d.x0, ev.clientY - d.y0) < DRAG_START) return;
                d.active = true;
                hideInspect();
                cancelLongPress();
                d.targets = dragTargets(d.info);
                screen.classList.add('dragging');
                d.node.classList.add('drag-source');
                markTargets(d.targets);
                if (d.info.kind !== 'board' && d.info.kind !== 'item') {
                    d.ghost = d.node.cloneNode ? d.node.cloneNode(true) : null;
                    if (d.ghost) {
                        d.ghost.classList.add('drag-ghost');
                        d.ghost.classList.remove('guide-focus');
                        dom.arena.appendChild(d.ghost);
                    }
                    const zone = d.info.kind === 'axiom' ? dom.lane : dom.myBoard;
                    const needsTarget = d.targets.size > 0;
                    if (!needsTarget || d.info.kind === 'hand' && state.cards[d.info.cid].kind === 'creature') zone.classList.add('drop-zone');
                }
                renderPrompt();
            }
            const box = dom.arena.getBoundingClientRect();
            const x = ev.clientX - box.left, y = ev.clientY - box.top;
            if (d.info.kind === 'board' || d.info.kind === 'item' || (d.targets && d.targets.size && state.cards[d.info.cid] && state.cards[d.info.cid].kind === 'tactic')) {
                const r = d.node.getBoundingClientRect();
                showArrow(r.left + r.width / 2 - box.left, r.top + r.height / 2 - box.top, x, y);
            }
            if (d.ghost) {
                d.ghost.style.left = x + 'px';
                d.ghost.style.top = y + 'px';
            }
            const over = hitTarget(ev.clientX, ev.clientY);
            Object.values(nodes).forEach(n => { if (n && n.classList) n.classList.remove('hover-target'); });
            const hovered = over && over.target && d.targets.has(over.target) && nodes[over.target] ? over.target : null;
            if (hovered) nodes[hovered].classList.add('hover-target');
            // The predicted fight for the target under the pointer (attacks only).
            if (d.info.kind === 'board' && d.hovered !== hovered) {
                d.hovered = hovered;
                clearPredict();
                if (hovered) showPredict(d.info.cid, hovered);
            }
        }

        function hitTarget(x, y) {
            const doc = root.document;
            if (!doc || !doc.elementFromPoint) return null;
            const elAt = doc.elementFromPoint(x, y);
            if (!elAt || !elAt.closest) return null;
            const t = elAt.closest('[data-target]');
            const zone = elAt.closest('[data-zone]');
            const inArena = !!(dom.arena.contains && dom.arena.contains(elAt));
            return { target: t ? t.dataset.target : null, zone: zone ? zone.dataset.zone : null, inArena };
        }

        function onPointerUp(ev) {
            const d = ui.drag;
            if (!d || ev.pointerId !== d.id) return;
            if (d.blocked) {
                ui.drag = null;
                if (Math.hypot(ev.clientX - d.x0, ev.clientY - d.y0) >= DRAG_START) ui.hoverBlock = { x: ev.clientX, y: ev.clientY };
                if (Math.hypot(ev.clientX - d.x0, ev.clientY - d.y0) >= DRAG_START * 3) {
                    let why = d.info.kind === 'axiom' ? whyNotAxiom(d.info.id) : d.info.kind === 'item' ? itemWhy(d.info.id) || 'Click it, then press Use.' : whyNot(d.info.cid);
                    // A tactic whose only possible targets are Elusive, dropped on one of them.
                    const at = d.info.kind === 'hand' && /no target/.test(why) ? (hitTarget(ev.clientX, ev.clientY) || {}).target : null;
                    if (at && elusiveNote(at)) why = elusiveNote(at);
                    setNote(why);
                }
                return;
            }
            if (!d.active) { ui.drag = null; return; }
            const hit = hitTarget(ev.clientX, ev.clientY) || {};
            const info = d.info;
            cancelDrag();
            ui.hoverBlock = { x: ev.clientX, y: ev.clientY };
            ui.suppressClick = true;
            setTimeout(() => { ui.suppressClick = false; }, 0);
            const L = legal();
            if (info.kind === 'board') {
                const a = L.find(x => x.type === 'attack' && x.cid === info.cid && x.target === hit.target);
                if (a) act(a);
                else if (hit.target && hit.target !== info.cid) setNote(badTargetNote(info.cid, hit.target));
                return;
            }
            if (info.kind === 'item') { dropItem(info.id, hit, L); return; }
            // A hand card counts as played when it is dropped anywhere on the table outside the
            // hand (also beside the heroes, which have no zone). Dropping it back on the hand cancels.
            const onTable = hit.inArena && hit.zone !== 'hand';
            if (info.kind === 'axiom') {
                const a = L.find(x => x.type === 'axiom' && x.choice === info.id);
                if (a && onTable) act(a);
                else if (a) setNote('Drop the rule card in the middle row to play it.');
                return;
            }
            const plays = L.filter(x => x.type === 'play' && x.cid === info.cid);
            const direct = plays.find(x => x.target && x.target === hit.target);
            if (direct) { act(direct); return; }
            if (!onTable) { if (plays.length) setNote('Drop it higher, on the table, to play it.'); return; }
            const plain = plays.find(x => !x.target);
            if (plain) { act(plain); return; }
            // Dropped on an Elusive enemy: say why, and leave the card in the hand (no waiting copy).
            const elusive = hit.target ? elusiveNote(hit.target) : '';
            if (elusive) { setNote(elusive); return; }
            if (plays.length) {
                // A targeted Entrance or tactic: keep the card chosen and ask for the target.
                ui.sel = { kind: 'hand', cid: info.cid, pending: true };
                render();
            }
        }

        function cancelDrag() {
            const d = ui.drag;
            ui.drag = null;
            if (!d) return;
            if (d.ghost && d.ghost.remove) d.ghost.remove();
            screen.classList.remove('dragging');
            if (d.node && d.node.classList) d.node.classList.remove('drag-source');
            [dom.lane, dom.myBoard].forEach(z => z.classList.remove('drop-zone'));
            Object.values(nodes).forEach(n => { if (n && n.classList) { n.classList.remove('valid-drag'); n.classList.remove('hover-target'); } });
            screen.classList.remove('targeting');
            hideArrow();
            clearPredict();
            if (d.active && !ui.ended) renderPrompt();
        }

        // ---- the Bag: items brought into this match (one per turn, used up only when used) ----
        const itemsUsedNow = () => (E.itemsUsed && state.players[ME].itemsUsed ? E.itemsUsed(state, ME) : {});
        const itemOk = (id, L) => L.some(a => a.type === 'item' && a.id === id);
        const itemInfo = id => (E.bagStatus ? E.bagStatus(state, ME) : []).find(x => x.id === id) || null;
        function itemWhy(id) {
            if (ui.ended) return '';
            if (ui.busy || decider() !== ME) return 'Wait for your turn.';
            const x = itemInfo(id);
            return (x && x.note) || (myTurn() ? '' : 'Wait a moment.');
        }
        function toggleBag(on) {
            ui.bagOpen = on == null ? !ui.bagOpen : !!on;
            render();
            const target = ui.bagOpen ? screen.querySelector('.b-bag-item') : dom.bagBtn;
            if (target && target.focus) try { target.focus(); } catch (e) { /* ignore */ }
        }
        // The Bag button (and its tray when open); null when no items were brought.
        function bagEl(L) {
            const P = state.players[ME];
            dom.bagBtn = null;
            if (!P.bag || !(P.bag.length + (P.itemsUsed || []).length)) return null;
            const list = E.bagStatus(state, ME);
            const style = bg('ui/bag');
            const n = P.bag.length;
            const btn = iconButton('.b-bag-btn' + (ui.bagOpen ? '.open' : '') + (list.some(x => itemOk(x.id, L)) ? '.has-use' : ''), {
                key: 'bag', name: 'Bag', label: 'Bag: ' + n + ' item' + (n === 1 ? '' : 's'),
                detail: n + ' item' + (n === 1 ? '' : 's') + '. Use one per turn. An item is used up only when you use it.',
                icon: el('span.b-bag-icon' + (style ? '.art' : ''), { style, text: style ? '' : '🎒', 'aria-hidden': 'true' }),
                badge: n, badgeClass: 'b-bag-count',
                extra: { 'aria-expanded': ui.bagOpen ? 'true' : 'false', 'aria-controls': 'b-bag-tray' },
                onclick: () => toggleBag(),
            });
            dom.bagBtn = btn;
            return el('div.b-bag-wrap', {}, [ui.bagOpen ? bagTray(list, L) : null, btn]);
        }
        function bagTray(list, L) {
            const rows = list.map(x => {
                const ok = itemOk(x.id, L);
                const why = ok ? '' : itemWhy(x.id);
                const chosen = ui.sel && ui.sel.kind === 'item' && ui.sel.id === x.id;
                const b = el('button.b-bag-item' + (ok ? '' : '.off') + (chosen ? '.selected' : ''), {
                    type: 'button', dataset: { item: x.id }, 'aria-disabled': ok ? null : 'true',
                    'aria-label': x.name + ', ' + x.cost + ' energy: ' + x.text + (why ? ' Not now: ' + why : ''),
                    onclick: () => { if (!ui.suppressClick) clickItem(x.id, L); },
                }, [
                    Rift.Assets.img('item/' + x.id, { className: 'b-bag-art', label: x.name, alt: '' }),
                    el('span.b-bag-words', {}, [
                        el('strong', { text: x.name + (x.count > 1 ? ' ×' + x.count : '') }),
                        el('span.b-bag-text', { text: x.text }),
                        why ? el('span.b-bag-why', { text: why }) : null,
                    ]),
                    el('span.b-bag-cost', { text: x.cost + ' ⚡' }),
                ]);
                const drag = ok && L.some(a => a.type === 'item' && a.id === x.id && a.target);
                b.addEventListener('pointerdown', ev => startDrag(ev, drag ? { kind: 'item', id: x.id } : { kind: 'item', id: x.id, blocked: true }, b));
                hoverInspect(b, () => itemPreview(x, why), 'item:' + x.id);
                return b;
            });
            return el('div.b-bag-tray.panel', { id: 'b-bag-tray', role: 'group', 'aria-label': 'Your bag' }, [
                el('div.b-bag-head', {}, [el('strong', { text: 'Bag' }), el('span.small', { text: ' One item per turn.' })]),
                rows.length ? el('div.b-bag-list', {}, rows) : el('p.small.b-bag-empty', { text: 'Your bag is empty.' }),
            ]);
        }
        // The big preview of an item (hover, keyboard focus or long-press), like a card.
        function itemPreview(x, why) {
            return [el('div.bc.item.big', { dataset: { colour: 'item' } }, [
                el('div.bc-bg'), el('div.bc-frame'),
                el('div.bc-art', {}, [Rift.Assets.img('item/' + x.id, { label: x.name, alt: '' })]),
                gem('cost', x.cost),
                el('div.bc-name', { text: x.name }),
                el('div.bc-text', {}, [el('div.bc-kind', { text: 'Bag item' }), el('div.bc-line', { text: x.text })]),
            ]), el('div.b-notes', {}, [
                el('div.b-note-line', {}, [el('b', { text: 'Bag item: ' }), 'one per turn. It is used up only when you use it.']),
                why ? el('div.b-note-line', { text: 'Not now: ' + why }) : null,
            ])];
        }
        function clickItem(id, L) {
            const acts = L.filter(a => a.type === 'item' && a.id === id);
            if (!acts.length) { if (ui.sel) ui.sel = null; setNote(itemWhy(id) || 'Not now.'); return; }
            ui.sel = ui.sel && ui.sel.kind === 'item' && ui.sel.id === id ? null : { kind: 'item', id };
            // A targeted item: close the tray so the glowing targets are easy to see.
            if (ui.sel && acts.some(a => a.target)) ui.bagOpen = false;
            render();
            if (ui.sel && nodes.buttons && nodes.buttons.item && nodes.buttons.item.focus) try { nodes.buttons.item.focus(); } catch (e) { /* ignore */ }
        }
        function itemPrompt(sel, L, ask, buttons) {
            const acts = L.filter(a => a.type === 'item' && a.id === sel.id);
            const x = itemInfo(sel.id) || { name: sel.id, cost: 0 };
            if (!acts.length) { ask.textContent = itemWhy(sel.id) || 'Not now.'; return; }
            if (acts.some(a => a.target)) { ask.textContent = 'Now click a glowing target for the ' + x.name + ' (or Cancel).'; return; }
            ask.textContent = 'Use the ' + x.name + (x.cost ? ' for ' + x.cost + ' energy? You have ' + state.players[ME].energy + '.' : '? It needs no energy.');
            const b = button('Use · ' + x.cost + ' ⚡', () => act(acts[0]), 'primary');
            nodes.buttons.item = b;
            buttons.appendChild(b);
        }
        // An item dragged out of the tray: dropped on its target it is used; else it stays chosen.
        function dropItem(id, hit, L) {
            const a = L.find(x => x.type === 'item' && x.id === id && x.target && x.target === hit.target);
            if (a) { act(a); return; }
            if (hit.target && elusiveNote(hit.target)) { setNote(elusiveNote(hit.target)); return; }
            if (itemOk(id, L)) { ui.sel = { kind: 'item', id }; ui.bagOpen = false; render(); }
        }

        // ---- fight preview: what an attack would do (colour wheel and rules included) ----
        function predictLines(att, target) {
            const pv = E.fightPreview(state, att, target);
            if (pv.hero) {
                const h = state.players[+target[1]];
                const rev = E.rules(state).reverseHearts;
                return { target: ['−' + pv.damage + ' heart' + (pv.damage === 1 ? '' : 's'), h.hearts - pv.damage <= 0 ? (rev ? '0 hearts: ' + oppName + ' wins!' : '0 hearts: you win!') : pv.hearts + ' left'].concat(
                    rev && target === 'h' + OPP ? ['⚠ The Last Shall Be First: this helps ' + oppName + '!'] : []),
                    attacker: ['Deals ' + pv.damage], targetDies: rev };
            }
            const colourPart = (cid, foe) => (E.attackParts(state, cid, foe).parts.find(x => x.source === 'colour') || {}).amount || 0;
            const ca = colourPart(att, target), cb = colourPart(target, att);
            const tag = n => (n ? ' (' + (n > 0 ? '+' : '−') + Math.abs(n) + ' colour)' : '');
            const blocked = (cid, amount) => amount > 0 && E.hasKeyword(state, cid, 'shield');
            const takesT = blocked(target, pv.toDefender) ? 'Shield blocks' : 'Takes ' + pv.toDefender + (pv.toDefender ? tag(ca) : '');
            const takesA = blocked(att, pv.toAttacker) ? 'Shield blocks' : 'Takes ' + pv.toAttacker + (pv.toAttacker ? tag(cb) : '');
            return {
                target: [takesT, pv.defenderDefeated ? 'Defeated' : 'Survives'],
                attacker: ['Deals ' + pv.toDefender + tag(ca), takesA, pv.attackerDefeated ? 'Defeated' : 'Survives'],
                targetDies: pv.defenderDefeated, attackerDies: pv.attackerDefeated,
            };
        }
        function predictBadge(lines, dies) {
            return el('div.b-predict' + (dies ? '.dies' : ''), { 'aria-hidden': 'true' }, lines.map((t, i) => el(i ? 'div' : 'strong', { text: t })));
        }
        function showPredict(att, target) {
            const a = nodes[att], t = nodes[target];
            if (!a || !t || !state.cards[att]) return;
            let p;
            try { p = predictLines(att, target); } catch (e) { return; }
            t.appendChild(predictBadge(p.target, p.targetDies || /you win/.test(p.target[1] || '')));
            a.appendChild(predictBadge(p.attacker, p.attackerDies));
        }
        function clearPredict() {
            const q = screen.querySelectorAll ? screen.querySelectorAll('.b-predict') : [];
            [].forEach.call(q, n => { if (n.remove) n.remove(); });
        }

        function markTargets(targets) {
            if (targets.size) screen.classList.add('targeting');
            targets.forEach((a, t) => { if (nodes[t]) nodes[t].classList.add('valid-drag'); });
        }

        // ---- arrow (SVG overlay) ----
        function svgArrow() {
            const doc = root.document;
            if (!doc || !doc.createElementNS) return el('div.b-arrow');
            const NS = 'http://www.w3.org/2000/svg';
            const svg = doc.createElementNS(NS, 'svg');
            svg.setAttribute('class', 'b-arrow');
            svg.innerHTML = '<defs><marker id="b-arrowhead" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">'
                + '<path d="M0,0 L10,5 L0,10 z" fill="#F2B632"/></marker></defs>'
                + '<path class="b-arrow-line" d="" fill="none" stroke="#F2B632" stroke-width="7" stroke-linecap="round" stroke-dasharray="2 12" marker-end="url(#b-arrowhead)"/>';
            return svg;
        }
        function showArrow(x1, y1, x2, y2) {
            const path = dom.arrow.querySelector && dom.arrow.querySelector('.b-arrow-line');
            if (!path) return;
            const mx = (x1 + x2) / 2, my = Math.min(y1, y2) - Math.abs(x2 - x1) * 0.15 - 30;
            path.setAttribute('d', 'M' + x1 + ',' + y1 + ' Q' + mx + ',' + my + ' ' + x2 + ',' + y2);
            dom.arrow.classList.add('show');
        }
        function hideArrow() { if (dom.arrow.classList) dom.arrow.classList.remove('show'); }
        function drawArrowForPreview() {
            hideArrow();
            const pv = ui.preview;
            if (!pv) return;
            const a = nodes[pv.cid], t = nodes[pv.target];
            if (!a || !t || !a.getBoundingClientRect || !dom.arena.getBoundingClientRect) return;
            const box = dom.arena.getBoundingClientRect(), r1 = a.getBoundingClientRect(), r2 = t.getBoundingClientRect();
            if (!r1.width || !r2.width) return;
            showArrow(r1.left + r1.width / 2 - box.left, r1.top + r1.height / 2 - box.top, r2.left + r2.width / 2 - box.left, r2.top + r2.height / 2 - box.top);
        }

        // ---- effects: damage numbers, lunges, defeat fades ----
        function rects() {
            const out = {};
            if (!dom.arena.getBoundingClientRect) return out;
            const box = dom.arena.getBoundingClientRect();
            Object.keys(nodes).forEach(k => {
                const n = nodes[k];
                if (n && n.getBoundingClientRect && n.dataset && (n.dataset.cid || n.dataset.target)) {
                    const r = n.getBoundingClientRect();
                    out[k] = { left: r.left - box.left, top: r.top - box.top, width: r.width, height: r.height, node: n };
                }
            });
            return out;
        }
        function rectOf(key, before) {
            const n = nodes[key];
            if (n && n.getBoundingClientRect && dom.arena.getBoundingClientRect) {
                const box = dom.arena.getBoundingClientRect(), r = n.getBoundingClientRect();
                if (r.width) return { left: r.left - box.left, top: r.top - box.top, width: r.width, height: r.height };
            }
            return before[key] || null;
        }
        function float(key, text, cls, before) {
            const r = rectOf(key, before);
            if (!r) return;
            const f = el('div.b-float' + (cls ? '.' + cls : ''), { text, style: { left: (r.left + r.width / 2) + 'px', top: (r.top + r.height * 0.4) + 'px' } });
            dom.floats.appendChild(f);
            setTimeout(() => { if (f.remove) f.remove(); }, 1300);
        }
        function effects(events, before) {
            if (!root.document || !dom.arena.getBoundingClientRect) return;
            const calm = calmMotion();
            events.forEach(ev => {
                if (ev.t === 'damage') float(ev.cid, '−' + ev.amount, 'dmg', before);
                if (ev.t === 'hit') float('h' + ev.player, '−' + ev.amount + ' ❤', 'dmg', before);
                if (ev.t === 'shield') float(ev.cid, 'Blocked!', 'info', before);
                // A changed fight rule decided this fight: name it over the defender.
                if (ev.t === 'fight') {
                    const rule = E.changedAxioms(state).find(a => a.category === 'combat');
                    if (rule) float(ev.defender, '⚖ ' + (rule.short || rule.name), 'rule', before);
                }
                if (ev.t === 'item-use') float(ev.target || 'h' + ev.player, ((Rift.data.items || {})[ev.id] || { name: ev.id }).name, 'info', before);
                if (ev.t === 'power-use') float(ev.target || 'pw' + ev.player, powerName(ev.id), 'info', before);
                if (ev.t === 'defeated' && before[ev.cid]) {
                    const r = before[ev.cid];
                    const ghost = r.node.cloneNode ? r.node.cloneNode(true) : null;
                    if (ghost) {
                        ghost.classList.add('b-defeat-ghost');
                        ['valid', 'selected', 'guide-focus', 'attacking', 'targeted'].forEach(k => ghost.classList.remove(k));
                        Object.assign(ghost.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px' });
                        dom.floats.appendChild(ghost);
                        setTimeout(() => { if (ghost.remove) ghost.remove(); }, 900);
                    }
                }
                if (ev.t === 'play' && nodes[ev.cid]) nodes[ev.cid].classList.add('entered');
                if (ev.t === 'attack' && !calm) lunge(ev.cid, ev.target, before);
                if (ev.t === 'axiom' || ev.t === 'reset') { dom.lane.classList.remove('flash'); void dom.lane.offsetWidth; dom.lane.classList.add('flash'); }
            });
        }
        function lunge(cid, target, before) {
            const n = nodes[cid];
            const a = rectOf(cid, before), t = rectOf(target, before);
            if (!n || !n.animate || !a || !t) return;
            const dx = (t.left + t.width / 2 - a.left - a.width / 2) * 0.35, dy = (t.top + t.height / 2 - a.top - a.height / 2) * 0.35;
            try { n.animate([{ transform: 'translate(0,0)' }, { transform: 'translate(' + dx + 'px,' + dy + 'px)' }, { transform: 'translate(0,0)' }], { duration: 380, easing: 'ease-in-out' }); } catch (e) { /* no WAAPI */ }
        }

        // ---- the end ----
        function finish() {
            if (ui.ended) return;
            ui.ended = true;
            cancelDrag();
            hideTip();
            const w = E.winner(state);
            const outcome = w === 'draw' ? 'draw' : w === ME ? 'won' : 'lost';
            let fate = null;
            let settlement = null;
            const itemsUsed = itemsUsedNow();
            if (mode !== 'practice' && !guide) {
                // A Ward or Anchor used in the battle (the Bag) can't also save a creature afterwards.
                const left = id => Math.max(0, (me.items[id] || 0) - (itemsUsed[id] || 0));
                fate = B().Fate.roll({
                    instances: me.team, defeated: E.lostUids(state, ME), mode, won: outcome === 'won',
                    items: { ward: left('ward'), anchor: left('anchor') }, seed: seed + ':fate',
                });
                settlement = B().Ante.settle(ante, outcome, { seed, now: Date.now() });
            }
            // powerUsed: how often I used my power this match (the save counts it; the Feed's Champion copies the top one).
            const myPower = state.players[ME].power;
            const powerUsed = myPower ? { id: myPower.id, uses: myPower.uses || 0 } : null;
            const result = { mode, outcome, turns: state.turn, rounds: state.round, endReason: state.endReason, fate, ante, settlement, itemsUsed, powerUsed };
            sfx(outcome === 'won' ? 'win' : 'lose');
            if (fate && fate.results.length) {
                const severity = ['death', 'warp', 'injured', 'scarred', 'fine'];
                const worst = severity.find(kind => fate.results.some(r => r.outcome === kind));
                sfx('fate-' + worst);
            }
            const title = guide ? (outcome === 'won' ? 'You won the lesson!' : 'Lesson over') : outcome === 'won' ? 'Victory!' : outcome === 'lost' ? 'Defeat…' : 'A draw';
            const reason = {
                hearts: outcome === 'won' ? oppName + ' ran out of hearts.' : 'You ran out of hearts.',
                'reverse-hearts': outcome === 'won' ? 'The reversed victory rule made reaching your own zero hearts a win.' : oppName + ' reached zero hearts under the reversed victory rule.',
                'cannot-act': outcome === 'won' ? oppName + ' ran out of creatures.' : 'You ran out of creatures.',
                'turn-limit': 'The rift closed before anyone won.',
                'both-zero': 'Both heroes reached zero hearts at once.',
            }[state.endReason] || '';
            const body = [el('h2', { text: title }), el('p.muted', { text: reason + ' ' + state.round + ' rounds, ' + state.turn + ' turns.' })];
            // The TOK point: which rules decided this match.
            const changes = E.fullLog(state).filter(ev => ev.t === 'axiom' || ev.t === 'reset').length;
            const endRules = changedRules();
            if (!guide && changes) body.push(el('div.b-end-rules', {}, [
                el('strong', { text: 'The rules changed ' + changes + ' time' + (changes === 1 ? '' : 's') + ' in this match.' }),
                el('span', { text: endRules.length ? ' Rules in play at the end: ' + endRules.map(ax => ax.name + ' (' + (ax.short || ax.text) + ')').join('; ') + '. Same cards, other rules: would you have won?'
                    : ' At the end the basic rules were back.' }),
            ]));
            if (guide) {
                const speaker = (Rift.data.speakers || {}).granny;
                const outro = guide.outro || 'Same table, different rules, different endings. In maths, the rules you start from are called axioms.';
                body.push(el('div.b-outro', {}, [speaker ? Rift.Assets.img(speaker.art, { className: 'b-coach-face', label: speaker.name, alt: '' }) : null, el('p', { text: outro })]));
                body.push(el('p.small', { text: 'Real matches start with ' + E.DEFAULTS.hearts + ' hearts each. Read the rule tiles before you attack!' }));
                if (guide.next) body.push(el('p.small', { text: guide.next }));
                try { if (Rift.Audio && Rift.Audio.speak) Rift.Audio.speak({ speaker: 'granny', text: outro, voice: Rift.voiceId ? Rift.voiceId('granny', outro) : null }); } catch (e) { /* no voice */ }
            } else if (mode === 'practice') {
                body.push(el('p', { text: p.story ? 'Story challenge: nothing at stake. Your creatures and items are safe.' : 'Practice: nothing at stake. Your creatures are safe.' }));
            } else {
                const F = Rift.data.fate;
                body.push(el('h3', { text: 'After-battle checks for your defeated creatures' }));
                if (!fate.results.length) body.push(el('p', { text: 'None of your creatures fell. Lucky.' }));
                else body.push(el('ul.fate-list', {}, fate.results.map(r => el('li.fate-' + r.outcome, {}, [
                    el('span.fate-icon', { text: F.outcomes[r.outcome].icon }),
                    el('b', { text: species(r.species).name + ': ' }),
                    F.outcomes[r.outcome].name + (r.detail ? ' — ' + r.detail : '')
                        + (r.savedBy === 'legend' ? ' (legendaries never die)' : r.savedBy ? ' (your ' + r.savedBy + ' saved it)' : ''),
                ]))));
                body.push(el('h3', { text: 'Stakes' }));
                body.push(el('ul.ante-list', {}, ante.lines.concat(settlement.lines).map(t => el('li', { text: t }))));
            }
            const cont = button(guide && outcome === 'won' ? 'Finish lesson' : 'Continue', () => {
                if (typeof p.onEnd === 'function') p.onEnd(result);
            }, 'primary');
            body.push(el('div.b-buttons', {}, [cont]));
            dom.overlay.appendChild(el('div.b-end-panel.panel', {}, [el('div.b-end-body', {}, body)]));
            dom.overlay.classList.add('show');
            screen.classList.add('ended');
            handle.result = result;
            if (cont.focus) try { cont.focus(); } catch (e) { /* ignore */ }
        }

        function wheelLegend() {
            const W = Rift.data.wheel;
            const items = W.order.map(c => el('li', {}, [
                colourChip(c), ' beats ', colourChip(W.beats[c]),
                el('div.wheel-line', { text: W.lines[c] }),
            ]));
            items.push(el('li', {}, [colourChip('memory'), el('div.wheel-line', { text: W.memory })]));
            const chain = W.order.concat(W.order[0]).map(c => (Rift.COLOURS[c] || {}).icon || c).join(' › ');
            return el('details.b-wheel.panel', {}, [
                el('summary', {}, [
                    'Colour wheel: +' + W.bonus + ' attack',
                    el('span.b-wheel-chain', { title: W.order.map(c => Rift.COLOURS[c].name + ' beats ' + Rift.COLOURS[W.beats[c]].name).join('. ') + '.', text: chain }),
                ]),
                el('p.small', { text: 'These are rules for this game, not a ranking of ways of knowing.' }),
                el('ul', {}, items),
            ]);
        }

        const handle = {
            destroy() {
                clearTimeout(ui.timer); clearTimeout(ui.noteTimer); clearTimeout(ui.inspectTimer); clearTimeout(ui.bannerTimer); clearTimeout(ui.revealTimer); clearTimeout(ui.hintTimer); clearTimeout(ui.sayTimer); clearTimeout(ui.sayCap); cancelLongPress(); hideTip();
                ui.ended = true; cancelDrag();
                if (boardObserver) boardObserver.disconnect();
                if (help) help.close();
                if (guide) stopVoice();
            },
            get state() { return state; },
            get step() { return ui.step; },
            get busy() { return ui.busy; },
            result: null,
        };

        noteEvents(state.lastEvents);
        render();
        if (guide) speak();
        schedule();
        return handle;
    }

    if (Rift.Screens) Rift.Screens.register('battle', { mount });
})(typeof window !== 'undefined' ? window : globalThis);
