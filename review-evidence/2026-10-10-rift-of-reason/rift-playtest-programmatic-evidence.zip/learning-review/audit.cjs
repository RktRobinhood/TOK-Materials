const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const dir = __dirname;
function load(p) { vm.runInThisContext(fs.readFileSync(path.join(dir,p),'utf8'), {filename:p}); }
load('js/core/rift.js');
Rift.Puzzles = {defs: {}, register(def) { this.defs[def.id]=def; }};
load('data/creatures.js'); load('data/cases.js');
for(const id of ['tribunal','tower','oracle','river-crossing','water-jugs','logic-grid','line-drawer','three-act']) load('js/puzzles/'+id+'.js');
for(const [id,p] of Object.entries(Rift.Puzzles.defs)) {
 let count=0, failures=[];
 for(let d=1;d<=3;d++) for(let i=0;i<12;i++) {
  try {
   const data=p.generate(Rift.makeRng('critic:'+id+':'+d+':'+i),d);
   const a=p.solve(data); const r=p.check(data,a); count++;
   if(!r.solved) failures.push({d,i,a,r});
  } catch(e) { failures.push({d,i,error:e.stack}); }
 }
 console.log(JSON.stringify({id,count,failures}));
}
const o=Rift.Puzzles.defs.oracle;
const gauss=o.internals.C.gauss(Rift.makeRng('critic-gauss'));
for(const n of [-1,0.5,1,2.5,4]) console.log(JSON.stringify({oracle:'gauss', n, step4:o.internals.testStep(gauss,3,{n})}));
const odd=o.internals.C.odd(Rift.makeRng('critic-odd'));
for(const j of [-1,0.5,1,2.5,4]) console.log(JSON.stringify({oracle:'odd',j,title:odd.title, final:o.internals.testStep(odd,3,{j})}));
const tower=Rift.Puzzles.defs.tower;
const towerData=tower.generate(Rift.makeRng('critic:tower:1:0'),1);
function losingPath(st,path) {
 if(st.done) return st.lost ? {path,reason:st.reason,rubble:st.rubble} : null;
 for(const a of towerData.questions[st.qi].answers) {
  const ns=structuredClone(st); const ev=tower._internal.step(towerData,ns,a.id);
  const out=losingPath(ns,path.concat([{question:towerData.questions[st.qi].text, answer:a.text,event:ev.type}]));
  if(out) return out;
 }
 return null;
}
console.log(JSON.stringify({towerCollapse:losingPath(tower._internal.newState(towerData),[])}));
function jugBfs(d) {
 const caps=d.caps || d.capacity || [d.a,d.b];
 const [a,b]=caps;
 const queue=[[0,0,0]], seen=new Set(['0,0']);
 for(let k=0;k<queue.length;k++) {
  const [x,y,n]=queue[k]; if(x===d.target||y===d.target) return n;
  const xy=Math.min(x,b-y), yx=Math.min(y,a-x);
  for(const [u,v] of [[a,y],[x,b],[0,y],[x,0],[x-xy,y+xy],[x+yx,y-yx]]) {
   const key=u+','+v; if(!seen.has(key)) {seen.add(key);queue.push([u,v,n+1]);}
  }
 }
 return null;
}
function riverBfs(d) {
 const full=(1<<d.cast.length)-1, q=[[0,0,0]], seen=new Set(['0,0']);
 for(let k=0;k<q.length;k++) {
  const [far,boat,n]=q[k]; if(far===full) return n;
  const source=boat?far:full^far;
  for(let carry=0;carry<=full;carry++) {
   if((carry&source)!==carry || carry.toString(2).replaceAll('0','').length>d.seats) continue;
   const next=far^carry, side=1-boat, unsupervised=side ? full^next : next;
   if(d.rivals.some(([a,b]) => (unsupervised&(1<<a)) && (unsupervised&(1<<b)))) continue;
   const key=next+','+side; if(!seen.has(key)) {seen.add(key);q.push([next,side,n+1]);}
  }
 }
 return null;
}
for(const id of ['water-jugs','river-crossing']) {
 const p=Rift.Puzzles.defs[id]; const failures=[];
 for(let d=1;d<=3;d++) for(let i=0;i<40;i++) {
  const data=p.generate(Rift.makeRng('independent:'+id+':'+d+':'+i),d);
  const answer=p.solve(data); const min=(id==='water-jugs'?jugBfs:riverBfs)(data);
  const planned=id==='water-jugs' ? (answer.moves || answer.plan || []).length : (answer.trips || []).length;
  if((min===null)!==(answer.type==='impossible'||answer.impossible===true) || min!==null && min!==planned || data.toll&&data.toll<min) failures.push({d,i,min,planned,data,answer});
 }
 console.log(JSON.stringify({independentBfs:id,count:120,failures}));
}
console.log(JSON.stringify({psychicCoinNoWinners:(1-1/256)**768}));
