const fs = require('node:fs');
const vm = require('node:vm');

function makeNode(selector, props = {}, children = []) {
  return {
    selector, props: props || {}, children: children.filter(Boolean), removed: false,
    appendChild(node) { this.children.push(node); },
    remove() { this.removed = true; },
  };
}
const overlay = makeNode('#overlay');
const context = {
  Rift: { el: makeNode, Audio: { sfx() {} } },
  document: { getElementById() { return overlay; } },
  setTimeout,
};
vm.createContext(context);
vm.runInContext(fs.readFileSync(__dirname + '/js_ui_ui.js', 'utf8'), context);

async function sample(dismissal) {
  let resolved = false;
  let walking = true;
  const promise = context.Rift.UI.confirm('Your Home', 'Watch this scene again?', 'Watch', 'Not now');
  promise.then(() => { resolved = true; walking = false; });
  const backdrop = overlay.children.at(-1);
  if (dismissal === 'backdrop') {
    backdrop.props.onclick({ target: backdrop });
  } else {
    const actions = backdrop.children[0].children.at(-1);
    actions.children[0].props.onclick();
  }
  await new Promise(setImmediate);
  return { dismissal, modalRemoved: backdrop.removed, promiseResolved: resolved, walking };
}

(async () => {
  console.log(JSON.stringify(await sample('cancel-button')));
  console.log(JSON.stringify(await sample('backdrop')));
})();
